import revxrsal.zapper.gradle.zapper

plugins {
    kotlin("jvm") version "2.1.10"
    kotlin("plugin.serialization") version "2.1.10"

    id("com.gradleup.shadow") version "8.3.2"
    id("io.github.revxrsal.zapper") version "1.0.3"
}

group = "com.bryanvalc"
version = "1.5-SNAPSHOT"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/") {
        name = "papermc-repo"
    }
    maven("https://oss.sonatype.org/content/groups/public/") {
        name = "sonatype"
    }

    // commands, nbtapi
    maven ("https://repo.codemc.org/repository/maven-public/") {
        name = "codemc"
    }

    // packetevents
    maven { url = uri("https://repo.codemc.io/repository/maven-releases/") }

    maven { url = uri("https://repo.codemc.io/repository/maven-snapshots/") }

    // licensing
    maven {
        name = "resparkReleases"
        url = uri("https://maven.respark.dev/releases")
    }

    //papi
    maven("https://repo.extendedclip.com/releases/") {
        name = "placeholderapi"
    }

    //protocollib
    maven( "https://repo.dmulloy2.net/repository/public/" ) {
        name = "dmulloy2-repo"
    }

    //fawe, plotsquared, worldguard
    maven { url = uri("https://maven.enginehub.org/repo/") }

    //Vault
    maven {
        url = uri("https://jitpack.io")
        name = "jitpack"
    }


    maven("https://repo.fancyplugins.de/releases") {
        name = "fancyplugins"
    }

    //GriefDefender
    maven("https://repo.glaremasters.me/repository/bloodshot") {
        name = "griefdefender"
    }

}

val paperVersion: String by project // PURE MINECRAFT
val bStatsVersion: String by project
val lampVersion: String by project
val papiVersion: String by project
val packetEventsVersion: String by project
val luckPermsVersion: String by project
val mcCoroutineVersion: String by project
val faweVersion: String by project
val worldGuardVersion: String by project
val griefDefenderVersion: String by project
val rTagVersion: String by project
val fancyHologramsVersion: String by project

val licenseGateVersion: String by project // LICENSING

val serializationVersion: String by project // SERIALIZATION AND CONFIGS
val hoconVersion: String by project

val exposedVersion: String by project
val sqliteVersion: String by project
val mariadbVersion: String by project
val hikariVersion: String by project
val postgresVersion: String by project
val h2Version: String by project


dependencies {
    compileOnly("io.papermc.paper:paper-api:$paperVersion")
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")

    zap("org.bstats:bstats-bukkit:$bStatsVersion")

    zap("io.github.revxrsal:lamp.common:$lampVersion")
    zap("io.github.revxrsal:lamp.bukkit:$lampVersion")
    zap("io.github.revxrsal:lamp.brigadier:$lampVersion")
    // PAPI
    compileOnly("me.clip:placeholderapi:$papiVersion")
    compileOnly("com.github.retrooper:packetevents-spigot:$packetEventsVersion")
    zap("net.kyori:adventure-platform-bukkit:4.4.0")
    zap("net.kyori:adventure-text-minimessage:4.23.0")
    zap("net.kyori:adventure-text-serializer-plain:4.23.0")
    zap("net.kyori:adventure-text-serializer-legacy:4.23.0")

    // LuckPerms
    compileOnly("net.luckperms:api:$luckPermsVersion")
    // coroutines
    implementation("com.github.shynixn.mccoroutine:mccoroutine-bukkit-api:$mcCoroutineVersion")
    implementation("com.github.shynixn.mccoroutine:mccoroutine-bukkit-core:$mcCoroutineVersion")
    // FAWE, WorldGuard, PlotSquared
    implementation(platform("com.intellectualsites.bom:bom-newest:$faweVersion")) // Ref: https://github.com/IntellectualSites/bom
    compileOnly("com.fastasyncworldedit:FastAsyncWorldEdit-Core")
    compileOnly("com.fastasyncworldedit:FastAsyncWorldEdit-Bukkit") { isTransitive = false }
    compileOnly("com.intellectualsites.plotsquared:plotsquared-core")
    compileOnly("com.intellectualsites.plotsquared:plotsquared-bukkit") { isTransitive = false }
    compileOnly("com.sk89q.worldguard:worldguard-bukkit:$worldGuardVersion")
    compileOnly("com.griefdefender:api:$griefDefenderVersion")
    // rTag
    zap("com.saicone.rtag:rtag:$rTagVersion")
    // Other modules
    zap("com.saicone.rtag:rtag-block:$rTagVersion")
    zap("com.saicone.rtag:rtag-entity:$rTagVersion")
    zap("com.saicone.rtag:rtag-item:$rTagVersion")

    // Holograms
    compileOnly("de.oliver:FancyHolograms:$fancyHologramsVersion")

    // license server
    zap("dev.respark.licensegate:license-gate:$licenseGateVersion")

//     sugar syntax for math utilities, I really love this
    zap("com.squidpony:squidlib-util:3.0.6")


    // serialization
    zap("org.jetbrains.kotlinx:kotlinx-serialization-core:$serializationVersion")
    zap("org.jetbrains.kotlinx:kotlinx-serialization-hocon:$serializationVersion")
    zap("org.jetbrains.kotlinx:kotlinx-serialization-json:$serializationVersion")
    // configurations
    zap("com.typesafe:config:$hoconVersion")


    // DI
    implementation("io.insert-koin:koin-core:4.0.2")
//    //caching
//    implementation("com.github.ben-manes.caffeine:caffeine:$caffeineVersion")

    //ORM
    zap("org.jetbrains.exposed:exposed-core:$exposedVersion")
    zap("org.jetbrains.exposed:exposed-dao:$exposedVersion")
    zap("org.jetbrains.exposed:exposed-jdbc:$exposedVersion")
    zap("org.jetbrains.exposed:exposed-kotlin-datetime:$exposedVersion")
    zap("org.jetbrains.exposed:exposed-json:$exposedVersion")
    zap("org.jetbrains.exposed:exposed-migration:$exposedVersion")
    // databases
    zap("org.xerial:sqlite-jdbc:$sqliteVersion")
    zap("org.mariadb.jdbc:mariadb-java-client:$mariadbVersion")
    zap("org.postgresql:postgresql:$postgresVersion")
    zap("com.zaxxer:HikariCP:$hikariVersion")
    zap("com.h2database:h2:$h2Version")

}

kotlin {
    compilerOptions {
        javaParameters = true
    }
}

zapper {
    libsFolder = "libs"
    relocationPrefix = "com.bryanvalc.magicwand.libs"

    repositories { includeProjectRepositories() }

//    relocate("net.kyori.adventure", "adventure")
    relocate("org.bstats", "bstats")
    relocate("com.saicone.rtag", "rtag")
}

buildscript {
    repositories {
        mavenCentral()
    }
    dependencies {
        classpath("com.guardsquare:proguard-gradle:7.6.1")
    }
}

val targetJavaVersion = 21
kotlin {
    jvmToolchain(targetJavaVersion)
}

tasks {
    shadowJar {
        // Existing relocations
        relocate("io.insert.koin", "com.bryanvalc.shadow.koin")

        relocate("com.github.shynixn.mccoroutine", "com.bryanvalc.shadow.mccoroutine")
    }
}

tasks.build {
    dependsOn("shadowJar")
}

tasks.processResources {
    val props = mapOf("version" to version)
    inputs.properties(props)
    filteringCharset = "UTF-8"
    filesMatching("plugin.yml") {
        expand(props)
    }
}

tasks.register<proguard.gradle.ProGuardTask>("proguard") {
    dependsOn("shadowJar")

    injars(tasks.shadowJar.get().archiveFile)
    outjars(layout.buildDirectory.file("libs/${project.name}-${project.version}.jar"))

    val javaHome = System.getProperty("java.home")
    libraryjars("$javaHome/jmods")

    // Add ALL dependencies as library jars
    val allDeps = (configurations.compileClasspath.get() + configurations.runtimeClasspath.get())
        .toSet()  // This removes duplicates

    allDeps.forEach { libraryjars(it) }

    // ProGuard configuration
    configuration("proguard.pro")

    // Obfuscation settings
    // REMOVE or COMMENT OUT THE FOLLOWING LINE:
    // overloadaggressively()
    useuniqueclassmembernames()
}

tasks.register<Copy>("deployObfuscated") {
    group = "deployment"
    description = "Copies the obfuscated JAR to the server's plugins directory"

    val targetDir = File("/home/ryan/Desktop/MagicSandbox/server/plugins")

    dependsOn("proguard") // Depend on ProGuard task
    from(tasks.named("proguard").get().outputs.files)
    into(targetDir)

    duplicatesStrategy = DuplicatesStrategy.INCLUDE
    onlyIf { targetDir.exists() }
}

tasks.register<Copy>("deployToServer") {
    group = "deployment"
    description = "Copies the original JAR to the server's plugins directory"

    val targetDir = File("/home/ryan/Desktop/Hotfix/plugins")

    dependsOn("shadowJar") // Depend on ProGuard task
    from(tasks.named("shadowJar").get().outputs.files)
    into(targetDir)

    duplicatesStrategy = DuplicatesStrategy.INCLUDE
    onlyIf { targetDir.exists() }
}

tasks.named("build") {
//    finalizedBy("deployObfuscated")
    finalizedBy("deployToServer")
}