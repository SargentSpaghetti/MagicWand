rootProject.name = "MagicWand"
