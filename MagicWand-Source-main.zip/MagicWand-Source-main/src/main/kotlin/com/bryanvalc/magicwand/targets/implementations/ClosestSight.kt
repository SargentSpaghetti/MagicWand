package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.closestToSolidInSight
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import java.util.Map


class ClosestSight : Target() {
    override fun isResolved(
        player: Player,
        playerData: PlayerData
    ): Boolean {
        return true
    }

    override fun predict(
        player: Player,
        playerData: PlayerData
    ): BlockVector3? {
        val clicks = playerData.clicks

        val lastClick= clicks.lastOrNull()
        val lastClickLocation: BlockVector3? = lastClick?.location


        val closest = closestToSolidInSight(player, playerData, lastClickLocation, 15, 10, 2)
        return closest ?: Block().predict(player, playerData) //delegate to block if null

    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>>? {
        return Map.of<Int, MutableSet<BlockVector3>>()
    }
}