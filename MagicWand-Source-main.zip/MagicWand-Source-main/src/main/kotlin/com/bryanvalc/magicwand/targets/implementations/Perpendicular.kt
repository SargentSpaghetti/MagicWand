package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.perpendicularExtend
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import java.lang.Double
import java.util.Map
import kotlin.math.pow
import kotlin.math.sqrt

class Perpendicular : Target() {
    override fun isResolved(player: Player, playerData: PlayerData): Boolean {
        return true
    }

    override fun predict(player: Player, playerData: PlayerData): BlockVector3? {
        val clicks = playerData.clicks
        if (clicks.isEmpty()) {
            return null
        }

        val previousClickLocation = clicks.lastOrNull()
        if(previousClickLocation==null) return null

        val lastClickLocation = previousClickLocation.location
        var offset = playerData.offset

        if (Double.isNaN(offset)) {
            val playerLocation = player.location

            offset = sqrt(
                (lastClickLocation.x() - playerLocation.x).pow(2.0) + (lastClickLocation.y() - (playerLocation.y + 1.62)).pow(
                    2.0
                ) + (lastClickLocation.z() - playerLocation.z).pow(2.0)
            )

            playerData.offset = offset
        }

        val previousClick = clicks.lastOrNull()
        if(previousClick==null) return null

        val previousBlock = previousClick.location
        return perpendicularExtend(player, playerData, previousBlock)
    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>> {
        return Map.of<Int, MutableSet<BlockVector3>>()
    }
}