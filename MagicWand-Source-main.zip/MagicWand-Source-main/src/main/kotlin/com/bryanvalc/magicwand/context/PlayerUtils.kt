package com.bryanvalc.magicwand.context

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.data.modifier.Modifier
import com.bryanvalc.magicwand.utils.ModifierParser
import org.bukkit.Axis
import org.bukkit.Material
import org.bukkit.block.BlockFace
import org.bukkit.block.ShulkerBox
import org.bukkit.block.data.*
import org.bukkit.block.data.type.*
import org.bukkit.entity.Player
import org.bukkit.event.block.Action
import org.bukkit.inventory.meta.BlockStateMeta
import org.bukkit.plugin.java.JavaPlugin
import org.bukkit.util.RayTraceResult
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.lang.IllegalArgumentException
import java.util.*

object PlayerUtils: KoinComponent {

    val plugin: JavaPlugin by inject()

    fun axisResolution(player: Player): Axis {
        val playerFacing = player.facing
        if (player.location.pitch < -45 || player.location.pitch > 45) {
            return Axis.Y
        } else if (playerFacing == BlockFace.EAST || playerFacing == BlockFace.WEST) {
            return Axis.X
        } else if (playerFacing == BlockFace.NORTH || playerFacing == BlockFace.SOUTH) {
            return Axis.Z
        }

        return Axis.Y
    }


    fun getFacing(player: Player): BlockFace? {
        val playerFacing = player.facing
        if (player.location.pitch < -45) {
            return BlockFace.UP
        } else if (player.location.pitch > 45) {
            return BlockFace.DOWN
        } else if (playerFacing == BlockFace.EAST || playerFacing == BlockFace.WEST || playerFacing == BlockFace.NORTH || playerFacing == BlockFace.SOUTH) {
            return playerFacing
        }
        return null
    }

    fun serveBlockData(player: Player, rayTraceResult: RayTraceResult?, playerData: PlayerData): BlockData? {
        val action = playerData.action

        if (action == null) {
            return null
        }

        val itemInOffHand = player.inventory.itemInOffHand
        if (itemInOffHand.type != Material.WRITABLE_BOOK && (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK)) { //can't avoid opening book as it is client side, so gotta do this
            val item = player.inventory.itemInMainHand
            val material = item.type
            if (material.isAir) {return Material.AIR.createBlockData()}
            val blockDataToEvaluate = try { //all this to avoid interference from the useless wooden axe
                material.createBlockData()
            } catch (_: NullPointerException) {
                null
            } catch (_: IllegalArgumentException) {
                return null
            }
            return if(blockDataToEvaluate != null) {
                Material.AIR.createBlockData()
            } else {
                null
            }
        }


        if (rayTraceResult == null) { //can't avoid opening book as it is client side, so gotta do this
            val item = player.inventory.itemInMainHand
            val material = item.type
            return try {
                material.createBlockData()
            } catch (_: NullPointerException) {
                null
            } catch (_: IllegalArgumentException) {
                return null
            }
        }

        val material = player.inventory.itemInMainHand.type

        if(playerData.brushMode && material == Material.NETHER_STAR) {
            return rayTraceResult.hitBlock?.blockData
        }

        if (material == Material.WATER_BUCKET) {
            return Material.WATER.createBlockData()
        }
        if (material == Material.LAVA_BUCKET) {
            return Material.LAVA.createBlockData()
        }

        var blockData: BlockData? = null

        try {
            blockData = material.createBlockData()
        } catch (_: NullPointerException) {
            return null
        } catch (_: IllegalArgumentException) {
            return null
        }
        if(blockData==null) return null


        val face = checkNotNull(rayTraceResult.hitBlockFace)
        val playerFacing = player.facing
        val hitPosition = rayTraceResult.hitPosition

        if (blockData is Slab) {
            val slab = blockData
            if (hitPosition.y % 1 > 0.5 || face == BlockFace.DOWN) {
                slab.type = Slab.Type.TOP
            } else {
                slab.type = Slab.Type.BOTTOM
            }
        }
        if (blockData is Stairs) {
            val stairs = blockData
            if (hitPosition.y % 1 > 0.5 || face == BlockFace.DOWN) {
                stairs.half = Bisected.Half.TOP
            } else {
                stairs.half = Bisected.Half.BOTTOM
            }
        }

        if (blockData is TrapDoor || blockData is Chest) {
            val directional = blockData as Directional
            directional.facing = playerFacing.oppositeFace
        } else if (blockData is Directional) {
            val directional = blockData
            directional.facing = playerFacing
        }
        if (blockData is Bisected) {
            val bisected = blockData
            if (hitPosition.y % 1 > 0.5 || face == BlockFace.DOWN) {
                bisected.half = Bisected.Half.TOP
            } else {
                bisected.half = Bisected.Half.BOTTOM
            }
        }
        if (blockData is Orientable) {
            val axis = axisResolution(player)
            val orientable = blockData
            orientable.axis = axis
        }
        if (blockData is Leaves) {
            val leaves = blockData
            leaves.isPersistent = true
        }
        if (blockData is Hangable && face == BlockFace.DOWN) {
            val hangable = blockData
            hangable.isHanging = true
        }

        if (material.name.contains("BANNER")) { // we don't want orientable to mess with this
            val bannerColor = material.name.lowercase(Locale.getDefault()).replace("_banner", "")
            when (face) {
                BlockFace.NORTH -> blockData =
                    plugin.server.createBlockData(bannerColor + "_wall_banner[facing=north]")

                BlockFace.SOUTH -> blockData =
                    plugin.server.createBlockData(bannerColor + "_wall_banner[facing=south]")

                BlockFace.EAST -> blockData =
                    plugin.server.createBlockData(bannerColor + "_wall_banner[facing=east]")

                BlockFace.WEST -> blockData =
                    plugin.server.createBlockData(bannerColor + "_wall_banner[facing=west]")

                BlockFace.UP -> {}
                BlockFace.DOWN -> {}
                BlockFace.NORTH_EAST -> {}
                BlockFace.NORTH_WEST -> {}
                BlockFace.SOUTH_EAST -> {}
                BlockFace.SOUTH_WEST -> {}
                BlockFace.WEST_NORTH_WEST -> {}
                BlockFace.NORTH_NORTH_WEST -> {}
                BlockFace.NORTH_NORTH_EAST -> {}
                BlockFace.EAST_NORTH_EAST -> {}
                BlockFace.EAST_SOUTH_EAST -> {}
                BlockFace.SOUTH_SOUTH_EAST -> {}
                BlockFace.SOUTH_SOUTH_WEST -> {}
                BlockFace.WEST_SOUTH_WEST -> {}
                BlockFace.SELF -> {}
            }
        }


        return blockData
    }

    fun modifiersFromShulker(player: Player): MutableList<Modifier>? {
        val modifiers: MutableList<Modifier> = ArrayList<Modifier>()
        val itemInHand = player.inventory.itemInOffHand

        if (itemInHand.type == Material.SHULKER_BOX) {
            //we get the blocks inside the shulker box

            var shulkerBox: ShulkerBox? = null
            if (itemInHand.type == Material.SHULKER_BOX) {
                val meta = itemInHand.itemMeta
                if (meta is BlockStateMeta) {
                    val blockStateMeta = meta
                    val blockState = blockStateMeta.blockState
                    if (blockState is ShulkerBox) {
                        shulkerBox = blockState
                    } else {
                        player.sendMessage("BlockState is not a ShulkerBox")
                    }
                } else {
                    player.sendMessage("ItemMeta is not a BlockStateMeta")
                }
            } else {
                player.sendMessage("Item in hand is not a ShulkerBox")
            }

            if (shulkerBox == null) {
                return null
            }
            if (shulkerBox.snapshotInventory.isEmpty) {
                return null
            }


            val blocks = shulkerBox.snapshotInventory.contents

            for (block in blocks) {
                if (block != null) {
                    val modifier: Modifier? = ModifierParser.loadFromItem(block)
                    if (modifier != null) {
                        modifiers.add(modifier)
                    }
                }
            }
        }
        return modifiers
    }
}