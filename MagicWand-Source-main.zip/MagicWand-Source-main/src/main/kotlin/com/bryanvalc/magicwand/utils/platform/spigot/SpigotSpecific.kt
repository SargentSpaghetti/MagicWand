package com.bryanvalc.magicwand.utils.platform.spigot

import com.bryanvalc.magicwand.utils.Messaging.getParsed
import com.bryanvalc.magicwand.utils.platform.PlatformImplementation
import com.github.retrooper.packetevents.PacketEvents
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
import net.md_5.bungee.api.ChatMessageType
import net.md_5.bungee.api.chat.TextComponent
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.Sound
import org.bukkit.block.Block
import org.bukkit.entity.Player
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.InventoryHolder
import org.bukkit.inventory.InventoryView
import org.bukkit.inventory.ItemStack
import org.bukkit.inventory.meta.ItemMeta
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

object SpigotSpecific: KoinComponent, PlatformImplementation {

    val plugin: JavaPlugin by inject()

    override fun getPluginVersion(): String {
        return plugin.description.version
    }

    override fun getLanguageForPlayer(player: Player): String {
        var locale = player.locale
        locale =  locale.split("_", limit = 2).let { parts ->
            if (parts.size == 2) "${parts[0]}_${parts[1].uppercase()}" else locale
        }
        return locale
    }

    override fun getProtocolVersionForPlayer(player: Player): Int {
        val version = PacketEvents.getAPI().playerManager.getClientVersion(player)
        return version.protocolVersion
    }

    override fun setResourcePack(
        player: Player,
        url: String,
        hash: String,
        required: Boolean,
        prompt: String
    ) {
        player.setResourcePack(
            url,
            hash.chunked(2)
                .map { it.toInt(16).toByte() }
                .toByteArray(),
            prompt,
            required
        )
    }

    override fun sendActionBar(player: Player, message: Component) {
        val messageStr = LegacyComponentSerializer.legacySection().serialize(message)
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent(messageStr))
    }

    override fun sendMessage(player: Player, message: Component) {
        val messageStr = LegacyComponentSerializer.legacySection().serialize(message)
        player.sendMessage(messageStr)
    }

    override fun displayName(itemMeta: ItemMeta, name: String) {
        val component = MiniMessage.miniMessage().deserialize(name)
        val nameStr = LegacyComponentSerializer.legacySection().serialize(component)
        itemMeta.setDisplayName(nameStr)
    }

    override fun displayName(itemMeta: ItemMeta, name: Component) {
        itemMeta.setDisplayName(LegacyComponentSerializer.legacySection().serialize(name))
    }

    override fun createInventory(
        owner: InventoryHolder?,
        size: Int,
        title: String
    ): Inventory {
        return Bukkit.createInventory(null, 54, title)
    }

    override fun lore(
        itemMeta: ItemMeta,
        lore: List<Component>
    ) {
        var loreStr = arrayListOf<String>()
        for (row in lore){
            loreStr.add(LegacyComponentSerializer.legacySection().serialize(row))
        }
        itemMeta.lore = loreStr
    }

    override fun getTitle(inventoryView: InventoryView): String {
        return inventoryView.title
    }

    override fun getDisplayName(itemStack: ItemStack): String? {
        return itemStack.itemMeta.displayName
    }

    override fun getLore(itemStack: ItemStack): List<String>? {
        return itemStack.itemMeta.lore
    }

    override fun playSound(player: Player, sound: Sound) {
        player.playSound(player.eyeLocation, sound, 1f, 1f)
    }

    override fun isEmpty(block: Block): Boolean {
        return block.type == Material.AIR
    }

    override fun isSolid(block: Block): Boolean {
        return block.type.isSolid
    }

    override fun isLiquid(block: Block): Boolean {
        return block.type == Material.WATER || block.type == Material.LAVA
    }

    override fun kick(player: Player) {
        player.kickPlayer("Server closed")
    }

}