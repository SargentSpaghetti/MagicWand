package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.isInsideCyl
import com.bryanvalc.magicwand.context.BlockVectorUtils
import com.bryanvalc.magicwand.context.effects.Hull
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.*
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Location
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*

class Cyl : Mode(), Configurable {
    init {
        name = "cylinder"
        permission = "mode.cyl"
        materialMenu = Material.CAKE
        premium = false
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/cylinder"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        if (clickLocations.size == 1 || clickLocations.size == 2) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocations.add(pivot)
            }
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val lastTarget = playerData.floatingTarget
        val axis = if (lastTarget is HitX || lastTarget is ExtendX) {
            'X'
        } else if (lastTarget is HitY || lastTarget is ExtendY) {
            'Y'
        } else if (lastTarget is HitZ || lastTarget is ExtendZ) {
            'Z'
        } else {
            'Y'
        }

        val menu = forPlayer(playerData)
        val origin = (menu?.propertyByName("origin") as EnumProperty?)?.value?:"corner"
        val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"

        when(origin) {
            "center" -> {
                val firstClick = clickLocations.firstOrNull()
                val lastClick = clickLocations.lastOrNull()
                if(firstClick!=null && lastClick!=null) {
                    val diff = lastClick.subtract(firstClick)
                    val otherCorner = firstClick.subtract(diff)
                    clickLocations.add(otherCorner)
                }
            }
            "wall" -> {
                val firstClick = clickLocations.firstOrNull()
                val lastClick = clickLocations.lastOrNull()
                if(firstClick!=null && lastClick!=null) {
                    var diff = lastClick.subtract(firstClick)

                    if(axis == 'X') {
                        diff = diff.withX(0)
                    } else if(axis == 'Y') {
                        diff = diff.withY(0)
                    }  else if(axis == 'Z') {
                        diff = diff.withZ(0)
                    }

                    val otherCorner = firstClick.subtract(diff)
                    clickLocations.add(otherCorner)
                }
            }
        }

        val newCubeMin: BlockVector3 = minBlockVector(*clickLocations.toTypedArray<BlockVector3>())
        val newCubeMax: BlockVector3 = maxBlockVector(*clickLocations.toTypedArray<BlockVector3>())

        val minX = newCubeMin.x()
        val minY = newCubeMin.y()
        val minZ = newCubeMin.z()
        val maxX = newCubeMax.x()
        val maxY = newCubeMax.y()
        val maxZ = newCubeMax.z()

        val locMin =
            Location(player.world, minX.toDouble(), minY.toDouble(), minZ.toDouble()).add(-0.5, -0.5, -0.5)
        val locMax = Location(player.world, maxX.toDouble(), maxY.toDouble(), maxZ.toDouble()).add(0.5, 0.5, 0.5)

        var shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList<Pair<BlockVector3, WrappedBlockState>>(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val center = Location(
            locMin.getWorld(),
            (locMin.x + locMax.x) / 2.0,
            (locMin.y + locMax.y) / 2.0,
            (locMin.z + locMax.z) / 2.0
        ) // Getting the midpoint without modifying original locations

        val radiusX = (locMax.x - locMin.x) / 2.0
        val radiusY = (locMax.y - locMin.y) / 2.0
        val radiusZ = (locMax.z - locMin.z) / 2.0

        val radius = BlockVectorUtils.DoubleVector(radiusX, radiusY, radiusZ)

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        for (x in minX..maxX) {
            for (y in minY..maxY) {
                for (z in minZ..maxZ) {
                    val evaluated = BlockVectorUtils.IntVector(x, y, z)

                    if (isInsideCyl(locMin, locMax, center, radius, evaluated, axis)) {
                        shape.add(Pair(BlockVector3.at(x,y,z), blockData))
                    }
                }
            }
        }

        when(filling) {
            "walls" -> {
                val directions = if (axis == 'X') {
                    listOf<BlockVector3>(
                        BlockVector3.at(0, 1, 0),
                        BlockVector3.at(0, -1, 0),
                        BlockVector3.at(0, 0, 1),
                        BlockVector3.at(0, 0, -1)
                    )
                } else if (axis == 'Z') {
                    listOf<BlockVector3>(
                        BlockVector3.at(1, 0, 0),
                        BlockVector3.at(-1, 0, 0),
                        BlockVector3.at(0, 1, 0),
                        BlockVector3.at(0, -1, 0)
                    )
                } else {
                    listOf<BlockVector3>(
                        BlockVector3.at(1, 0, 0),
                        BlockVector3.at(-1, 0, 0),
                        BlockVector3.at(0, 0, 1),
                        BlockVector3.at(0, 0, -1)
                    )
                }
                shape = Hull(4,4,directions).apply(shape)
            }
            "hollow" -> {
                shape = Hull(6,6).apply(shape)
            }
            "skeleton" -> {
                shape = Hull(5,6).apply(shape)
            }
            else -> {}
        }

        val shapeFinal: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList<Pair<BlockVector3, WrappedBlockState>>(shape.size)

        for(block in shape) {
            putBlock(
                shapeFinal,
                block.first,
                blockData,
                world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )
        }

        return shapeFinal
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "facing",
                    material = Material.QUARTZ,
                    lore = "facing.lore",
                    model = null,
                    value = "floor", options = listOf("any", "floor", "wall"),
                    models = mapOf(
                        "any" to 1,
                        "floor" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 3, name = "origin",
                    material = Material.NETHER_WART,
                    lore = "origin.lore",
                    model = null,
                    value = "corner", options = listOf("corner", "center", "wall"),
                    models = mapOf(
                        "corner" to 1,
                        "center" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 5, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = null,
                    value = "full", options = listOf("full", "walls", "hollow", "skeleton"),
                    models = mapOf(
                        "full" to 1,
                        "walls" to 2,
                        "hollow" to 3,
                        "skeleton" to 4
                    )
                )
            ),
            3
        )
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        val menu = forPlayer(playerData)
        val lock = (menu?.propertyByName("facing") as EnumProperty?)?.value?:"floor"

        val order = when(lock) {
            "floor" -> ArrayList(listOf(Block(), HitY(), Extend()))
            "wall" -> ArrayList(listOf(Block(), HitWall(), Extend()))
            else -> ArrayList(listOf(Block(), Hit(), Extend()))
        }

        return order
    }
}