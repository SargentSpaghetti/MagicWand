package com.bryanvalc.magicwand.noise.pattern.parser

import com.bryanvalc.magicwand.noise.pattern.impl.LumpNoiseGenerator
import com.fastasyncworldedit.core.extension.factory.parser.pattern.NoisePatternParser
import com.sk89q.worldedit.WorldEdit
import java.util.function.Supplier


class LumpPatternParser
    (worldEdit: WorldEdit?) : NoisePatternParser(
    worldEdit,
    "lump",
    Supplier { LumpNoiseGenerator() }) {
}