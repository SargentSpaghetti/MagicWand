package com.bryanvalc.magicwand.data

import com.bryanvalc.magicwand.context.PlayerUtils
import com.bryanvalc.magicwand.targets.Target
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import org.bukkit.FluidCollisionMode
import org.bukkit.Location
import org.bukkit.Material
import org.bukkit.block.data.BlockData
import org.bukkit.entity.Player


class ClickData {
    var interactionIndex: Int
    var interactionSubIndex: Int
    var location: BlockVector3
    var target: Target?
    var playerLocation: Location
    var brushSize: Int
    var blockData: WrappedBlockState

    constructor(
        interactionIndex: Int, interactionSubIndex: Int, location: BlockVector3, target: Target,
        playerLocation: Location, brushSize: Int, blockData: WrappedBlockState
    ) {
        this.interactionIndex = interactionIndex
        this.interactionSubIndex = interactionSubIndex
        this.location = location
        this.target = target
        this.playerLocation = playerLocation
        this.brushSize = brushSize
        this.blockData = blockData
    }

    constructor(player: Player, playerData: PlayerData) {
        val rayTraceResult = player.rayTraceBlocks(1000.0, FluidCollisionMode.NEVER)
        var blockData: BlockData? = PlayerUtils.serveBlockData(player, rayTraceResult, playerData)
        if (blockData == null) {
            blockData = Material.AIR.createBlockData()
        }
        var predict = playerData.floatingTarget?.predict(player, playerData)
        if( predict == null){
            playerLocation = player.location
            predict = BlockVector3.at(playerLocation.x, playerLocation.y, playerLocation.z)
        }
        val wrapped = SpigotConversionUtil.fromBukkitBlockData(blockData)
        this.interactionIndex = playerData.targetIndex
        this.interactionSubIndex = playerData.targetSubIndex
        this.location = predict
        this.target = playerData.floatingTarget
        this.playerLocation = player.location.clone()
        this.brushSize = playerData.brushSize
        this.blockData = wrapped
    }
}