package com.bryanvalc.magicwand.context.process.check

import com.bryanvalc.magicwand.module.PluginRepository
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.bukkit.BukkitAdapter
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.util.Location
import com.sk89q.worldguard.LocalPlayer
import com.sk89q.worldguard.WorldGuard
import com.sk89q.worldguard.protection.flags.Flags
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.entity.Player
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

object WorldGuardCheck: KoinComponent, Protect {

    val pluginRepository: PluginRepository by inject()

    override fun process(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        val query = WorldGuard.getInstance().platform.regionContainer.createQuery()
        val worldGuardPlugin = pluginRepository.worldGuardPlugin
        if(worldGuardPlugin == null) return originalMesh.toMutableList()

        val localPlayer: LocalPlayer = worldGuardPlugin.wrapPlayer(player)

        val bukkitWorld = player.world
        val weWorld = BukkitAdapter.adapt(bukkitWorld)


        val buffer: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList()
        for (row in originalMesh) {
            val loc: BlockVector3 = row.first
            val location = Location(
                weWorld,
                loc.x().toDouble(),
                loc.y().toDouble(),
                loc.z().toDouble()
            )

            val canBuild = query.testBuild(
                location,
                localPlayer,
                Flags.BUILD,
                Flags.BLOCK_BREAK,
                Flags.BLOCK_PLACE

            )

            if (canBuild) buffer.add(row)
        }

        return buffer
    }

}