package com.bryanvalc.magicwand.noise.pattern.parser

import com.bryanvalc.magicwand.noise.pattern.impl.FoamNoiseGenerator
import com.fastasyncworldedit.core.extension.factory.parser.pattern.NoisePatternParser
import com.sk89q.worldedit.WorldEdit
import java.util.function.Supplier


class FoamPatternParser
    (worldEdit: WorldEdit?) : NoisePatternParser(
    worldEdit,
    "foam",
    Supplier { FoamNoiseGenerator() }) {
}