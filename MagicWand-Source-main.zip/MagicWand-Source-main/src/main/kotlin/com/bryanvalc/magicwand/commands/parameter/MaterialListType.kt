package com.bryanvalc.magicwand.commands.parameter

import com.bryanvalc.magicwand.module.MaterialList
import com.bryanvalc.magicwand.module.MaterialRegistry
import revxrsal.commands.autocomplete.SuggestionProvider
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.exception.CommandErrorException
import revxrsal.commands.node.ExecutionContext
import revxrsal.commands.parameter.ParameterType
import revxrsal.commands.stream.MutableStringStream

class MaterialListType(private val materialRegistry: MaterialRegistry) : ParameterType<BukkitCommandActor, MaterialList> {

    override fun parse(input: MutableStringStream, context: ExecutionContext<BukkitCommandActor>): MaterialList {
        val name = input.readString()
        val materialList = materialRegistry.registries[name]
            ?: throw CommandErrorException("No such palette: $name")
        return materialList
    }

    override fun defaultSuggestions(): SuggestionProvider<BukkitCommandActor> {
        return SuggestionProvider { _ -> materialRegistry.registries.keys }
    }
}