package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.fill
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.Extend
import com.bryanvalc.magicwand.targets.implementations.ExtendX
import com.bryanvalc.magicwand.targets.implementations.ExtendY
import com.bryanvalc.magicwand.targets.implementations.ExtendZ
import com.bryanvalc.magicwand.targets.implementations.Hit
import com.bryanvalc.magicwand.targets.implementations.HitWall
import com.bryanvalc.magicwand.targets.implementations.HitX
import com.bryanvalc.magicwand.targets.implementations.HitY
import com.bryanvalc.magicwand.targets.implementations.HitZ
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*


class Cube : Mode(), Configurable {
    init {
        name = "cube"
        permission = "mode.cube"
        materialMenu = Material.SHULKER_SHELL
        premium = false
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/cube"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        if (clickLocations.size == 1 || clickLocations.size == 2) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocations.add(pivot)
            }
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val lastTarget = playerData.floatingTarget
        val axis = if (lastTarget is HitX || lastTarget is ExtendX) {
            'X'
        } else if (lastTarget is HitY || lastTarget is ExtendY) {
            'Y'
        } else if (lastTarget is HitZ || lastTarget is ExtendZ) {
            'Z'
        } else {
            'Y'
        }

        val menu = forPlayer(playerData)
        val origin = (menu?.propertyByName("origin") as EnumProperty?)?.value?:"corner"
        val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"

        when(origin) {
            "center" -> {
                val firstClick = clickLocations.firstOrNull()
                val lastClick = clickLocations.lastOrNull()
                if(firstClick!=null && lastClick!=null) {
                    val diff = lastClick.subtract(firstClick)
                    val otherCorner = firstClick.subtract(diff)
                    clickLocations.add(otherCorner)
                }
            }
            "wall" -> {
                val firstClick = clickLocations.firstOrNull()
                val lastClick = clickLocations.lastOrNull()
                if(firstClick!=null && lastClick!=null) {
                    var diff = lastClick.subtract(firstClick)

                    if(axis == 'X') {
                        diff = diff.withX(0)
                    } else if(axis == 'Y') {
                        diff = diff.withY(0)
                    }  else if(axis == 'Z') {
                        diff = diff.withZ(0)
                    }

                    val otherCorner = firstClick.subtract(diff)
                    clickLocations.add(otherCorner)
                }
            }
        }

        val newCubeMin: BlockVector3 = minBlockVector(*clickLocations.toTypedArray<BlockVector3>())
        val newCubeMax: BlockVector3 = maxBlockVector(*clickLocations.toTypedArray<BlockVector3>())

        val minX = newCubeMin.x()
        val minY = newCubeMin.y()
        val minZ = newCubeMin.z()
        val maxX = newCubeMax.x()
        val maxY = newCubeMax.y()
        val maxZ = newCubeMax.z()

        val wallsX = ObjectArrayList<BlockVector3>()
        val wallsY = ObjectArrayList<BlockVector3>()
        val wallsZ = ObjectArrayList<BlockVector3>()
        for (y in minY..maxY) {
            for (z in minZ..maxZ) {
                wallsX.add(BlockVector3.at(minX, y, z))
                wallsX.add(BlockVector3.at(maxX, y, z))
            }
        }
        for (x in minX..maxX) {
            for (z in minZ..maxZ) {
                wallsY.add(BlockVector3.at(x, minY, z))
                wallsY.add(BlockVector3.at(x, maxY, z))
            }
        }
        for (x in minX..maxX) {
            for (y in minY..maxY) {
                wallsZ.add(BlockVector3.at(x, y, minZ))
                wallsZ.add(BlockVector3.at(x, y, maxZ))
            }
        }

        when(filling) {
            "walls" -> {
                if(axis == 'X') {
                    for (block in wallsY) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
                    for (block in wallsZ) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
                } else if(axis == 'Y') {
                    for (block in wallsX) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
                    for (block in wallsZ) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
                }  else if(axis == 'Z') {
                    for (block in wallsX) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
                    for (block in wallsY) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
                }
            }
            "hollow" -> {
                for (block in wallsX) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
                for (block in wallsY) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
                for (block in wallsZ) { putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid) }
            }
            "skeleton" -> {
                val eightCorners = listOf<BlockVector3>(
                    BlockVector3.at(minX,minY,minZ),
                    BlockVector3.at(minX,minY,maxZ),
                    BlockVector3.at(minX,maxY,minZ),
                    BlockVector3.at(minX,maxY,maxZ),
                    BlockVector3.at(maxX,minY,minZ),
                    BlockVector3.at(maxX,minY,maxZ),
                    BlockVector3.at(maxX,maxY,minZ),
                    BlockVector3.at(maxX,maxY,maxZ)
                )

                for(corner in eightCorners) {
                    val neighbors = eightCorners.asSequence().filter {
                        (it.x()==corner.x() && it.y()==corner.y() && it.z()!=corner.z()) ||
                                (it.x()==corner.x() && it.y()!=corner.y() && it.z()==corner.z()) ||
                                (it.x()!=corner.x() && it.y()==corner.y() && it.z()==corner.z())
                    }

                    for(neighbor in neighbors) {
                        val line = fill(corner, neighbor)
                        for(block in line) {
                            putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
                        }
                    }
                }
            }
            else -> {
                for (x in minX..maxX) {
                    for (y in minY..maxY) {
                        for (z in minZ..maxZ) {
                            putBlock(
                                shape,
                                BlockVector3.at(x, y, z),
                                blockData,
                                world,
                                replaceAir,
                                replaceSolid,
                                replaceSoft,
                                replaceLiquid
                            )
                        }
                    }
                }
            }
        }

        return shape
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "facing",
                    material = Material.QUARTZ,
                    lore = "facing.lore",
                    model = 2,
                    value = "floor", options = listOf("any", "floor", "wall"),
                    models = mapOf(
                        "any" to 1,
                        "floor" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 3, name = "origin",
                    material = Material.NETHER_WART,
                    lore = "origin.lore",
                    model = 1,
                    value = "corner", options = listOf("corner", "center", "wall"),
                    models = mapOf(
                        "corner" to 1,
                        "center" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 5, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = null,
                    value = "full", options = listOf("full", "walls", "hollow", "skeleton"),
                    models = mapOf(
                        "full" to 1,
                        "walls" to 2,
                        "hollow" to 3,
                        "skeleton" to 4
                    )
                )
            ),
            3
        )
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        val menu = forPlayer(playerData)
        val lock = (menu?.propertyByName("facing") as EnumProperty?)?.value?:"floor"

        val order = when(lock) {
            "floor" -> ArrayList(listOf(Block(), HitY(), Extend()))
            "wall" -> ArrayList(listOf(Block(), HitWall(), Extend()))
            else -> ArrayList(listOf(Block(), Hit(), Extend()))
        }

        return order
    }
}