package com.bryanvalc.magicwand.context.overlay

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.PluginRepository
import com.github.shynixn.mccoroutine.bukkit.asyncDispatcher
import com.github.shynixn.mccoroutine.bukkit.launch
import com.sk89q.worldedit.math.BlockVector3
import kotlinx.coroutines.delay
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

object RenderTip: KoinComponent {

    val plugin: JavaPlugin by inject()
    val pluginRepository: PluginRepository by inject()

    fun forPlayer(hologramTip: MutableMap<Int, MutableSet<BlockVector3>>, player: Player, playerData: PlayerData) {
        if (hologramTip.isEmpty()) return
        if (!pluginRepository.packetEventsEnabled) return

        plugin.launch(context = plugin.asyncDispatcher) {
            var previousKey = 0
            for (entry in hologramTip.entries) {
                if (!player.isOnline) {
                    break
                }

                delay(40L * (entry.key - previousKey))
                previousKey = entry.key

                for (block in entry.value) {
                    GlowBlocks.glow(block, player, playerData)
                }
            }
            previousKey = 0
            for (entry in hologramTip.entries) {
                if (!player.isOnline) {
                    break
                }

                delay(40L * (entry.key - previousKey))

                previousKey = entry.key

                for (block in entry.value) {
                    GlowBlocks.unGlow(block, player, playerData)
                }
            }
        }

    }
}