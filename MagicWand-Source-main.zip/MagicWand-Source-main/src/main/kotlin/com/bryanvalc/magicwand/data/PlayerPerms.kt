package com.bryanvalc.magicwand.data

import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.module.License
import com.bryanvalc.magicwand.module.config.Configuration
import com.bryanvalc.magicwand.module.PluginRepository
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID
import kotlin.math.max

object PlayerPerms: KoinComponent {

    private val plugin: JavaPlugin by inject()
    private val config: Configuration by inject()
    private val pluginRepository: PluginRepository by inject()
    private val license: License by inject()

    fun premiumWall(mode: Mode?): Boolean {
        return if (mode == null) {
            true
        } else if (!mode.premium) { // not even a premium thing why bother
            true
        } else if (license.cachedResult) {
            true
        } else {
            false
        }
    }

    fun getLongPath(player: UUID, path: String): Long {
        var candidate1: Long = 1000
        if (path.contains("previewlimit")) {
            candidate1 = config.defaults.previewLimit
        } else if (path.contains("placinglimit")) {
            candidate1 = config.defaults.placingLimit
        } else if (path.contains("interval")) {
            candidate1 = config.defaults.interval.toLong()
        } else if (path.contains("bound")) {
            candidate1 = config.defaults.bound.toLong()
        } else if (path.contains("reach")) {
            candidate1 = config.defaults.reach.toLong()
        } else if (path.contains("brushsize")) {
            candidate1 = config.defaults.brushSize.toLong()
        }

        val luckPerms = pluginRepository.luckPermsInstance
        if (luckPerms == null) {
            return candidate1
        }

        var candidate2 = 0L

        val user = luckPerms.userManager.getUser(player)
        if(user == null) return candidate1

        val permission = "${plugin.name.lowercase()}.$path."
        val permissionMap = user.cachedData.permissionData.permissionMap
        for (entry in permissionMap.entries) {
            val key: String = entry.key
            val value: Boolean = entry.value
            if (!value) {
                continue
            }
            if (key.contains(permission)) {
                val splitValues: Array<String> =
                    key.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()

                if(splitValues.isEmpty()) continue

                var eval = splitValues[splitValues.size - 1].toLong()
                if(eval==-1L){
                    return -1L //-1 means unlimited
                }
                candidate2 = max(candidate2, eval)
            }
        }

        return if (candidate2 == 0L) { //this would imply that it hasn't been set in luckperms, so just use the default
            candidate1
        } else {
            candidate2
        }
    }

}