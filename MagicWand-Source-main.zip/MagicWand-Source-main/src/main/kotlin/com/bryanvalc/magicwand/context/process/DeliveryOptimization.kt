package com.bryanvalc.magicwand.context.process

import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import java.util.stream.Collectors

object DeliveryOptimization {
    fun shouldCancel(player: Player, playerData: PlayerData): Boolean {
        if ((System.currentTimeMillis() - playerData.lastInteraction) >= 100) {
            val clicks1 = playerData.clicks // delivery optimization
            if (clicks1.isEmpty()) return false
            val locations: MutableList<BlockVector3> = ArrayList<BlockVector3>(
                clicks1.stream().map<BlockVector3>(ClickData::location).collect(
                    Collectors.toList()
                )
            )
            val pivot = playerData.pivot
            if(pivot!=null) locations.add(pivot)
            var hashCode = locations.hashCode()
            val blockData = playerData.blockData
            var hashCode2 = 0
            if (blockData != null) {
                hashCode2 = blockData.hashCode()
            }
            val hashCode3 = playerData.brushSize
            val hashCode4 = player.inventory.itemInMainHand.hashCode()
            hashCode = hashCode + hashCode2 + hashCode3 + hashCode4

            // Retrieve the previous hash code
            val previousHashCode = playerData.previousClicksHash

            if ((previousHashCode) == hashCode) {
                return true
            }

            playerData.previousClicksHash = hashCode
        }
        return false
    }
}