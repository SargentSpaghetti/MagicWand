package com.bryanvalc.magicwand.context.process.check

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player

interface Protect {

    fun process(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>

}