package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.DynamicTarget
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.block.BlockFace
import org.bukkit.entity.Player
import java.util.Map

class Hit : DynamicTarget() {
    override fun isResolved(player: Player, playerData: PlayerData): Boolean {
        return true
    }

    override fun predict(player: Player, playerData: PlayerData): BlockVector3? {
        return null
    }

    override fun nextTarget(player: Player, playerData: PlayerData): Target {
        val playerFacing = player.facing

         return if (player.location.pitch < -45 || player.location.pitch > 45) {
            HitY()
        } else if (playerFacing == BlockFace.EAST || playerFacing == BlockFace.WEST) {
            HitX()
        } else if (playerFacing == BlockFace.NORTH || playerFacing == BlockFace.SOUTH) {
            HitZ()
        } else {
            HitY()
         }
    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>> {
        return Map.of<Int, MutableSet<BlockVector3>>()
    }
}