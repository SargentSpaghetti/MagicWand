package com.bryanvalc.magicwand.noise.pattern.impl

import com.sk89q.worldedit.math.Vector2
import com.sk89q.worldedit.math.Vector3
import com.sk89q.worldedit.math.noise.NoiseGenerator
import squidpony.squidmath.Noise

class LayeredNoiseGenerator: NoiseGenerator {
    override fun noise(position: Vector2): Float {
        return convert(Noise.Layered2D().getNoise(position.x(), position.z()))

    }

    override fun noise(position: Vector3): Float {
        return convert(Noise.Layered3D().getNoise(position.x(), position.z(), position.y()))
    }

    private fun convert(d: Double): Float {
        return ((d+1) * 0.5).toFloat()
    }
}