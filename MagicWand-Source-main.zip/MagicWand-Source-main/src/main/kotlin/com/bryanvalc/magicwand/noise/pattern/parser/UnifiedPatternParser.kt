package com.bryanvalc.magicwand.noise.pattern.parser

import com.bryanvalc.magicwand.noise.pattern.impl.UnifiedNoiseGenerator
import com.fastasyncworldedit.core.extension.factory.parser.pattern.NoisePatternParser
import com.sk89q.worldedit.WorldEdit
import java.util.function.Supplier

class UnifiedPatternParser
    (worldEdit: WorldEdit?) : NoisePatternParser(
    worldEdit,
    "unified",
    Supplier { UnifiedNoiseGenerator() }) {
}