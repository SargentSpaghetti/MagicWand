package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.context.Display.reset
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.ModeManager
import com.bryanvalc.magicwand.module.KtPlugin
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import com.bryanvalc.magicwand.utils.platform.Mediator
import net.kyori.adventure.text.Component
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission
import java.util.UUID

class MagicBrush: KoinComponent {

    val plugin: JavaPlugin by inject()
    val players: MutableMap<UUID, PlayerData> by inject()
    val modeManager: ModeManager by inject()
    val ktPlugin: KtPlugin by inject()


    @Command("magicbrush", "mb")
    @CommandPermission("magicwand.magicbrush")
    fun brush(
        actor: BukkitCommandActor,
        brush: Mode
    ){
        val sender = actor.sender()
        if (sender !is Player) {
            return
        }
        val player = sender as Player

        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        val currentMode = playerData.mode
        var nextMode = brush

        if(nextMode == null) return
        if(currentMode == nextMode) return

        reset(player, playerData)
        val message: Component? = playerData.setMode(nextMode)
        if(message==null){
            player.sendParsed(ktPlugin.premiumMessage)
            return
        } else {
            Mediator.sendActionBar(player, message)
            nextMode?.let {

                var optionsMessage = "${it.name}: <#8968d3><u><a:${it.wiki}><bold>wiki</bold></a></u> "
                if (nextMode is Configurable) {
                    optionsMessage+= "<hover:show_text:'Change ${it.name} options'><u><click:run_command:'/brushoptions ${(it.name).replace(" ", "_")}'><#8d4ca9><bold>options</bold>"
                }
                player.sendParsed(optionsMessage)
            }
        }

        val itemStack = player.inventory.itemInMainHand
        if(itemStack.type == Material.NETHER_STAR) {
            var model = 1
            val allModes = modeManager.modes
            val toAdd = allModes.indexOf(nextMode)+1
            model+=toAdd

            var meta = itemStack.itemMeta
            Mediator.displayName(meta, nextMode.name)
            meta.setCustomModelData(model)
            itemStack.itemMeta = meta
        }
        players[uuid] = playerData
        }
}