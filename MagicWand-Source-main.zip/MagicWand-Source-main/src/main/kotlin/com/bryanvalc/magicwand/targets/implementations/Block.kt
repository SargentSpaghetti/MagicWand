package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.ensureBoundLimit
import com.bryanvalc.magicwand.context.BlockVectorUtils.freePlace
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.block.Block
import org.bukkit.block.BlockFace
import org.bukkit.block.data.BlockData
import org.bukkit.entity.Player
import org.bukkit.event.block.Action
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.Map
import kotlin.getValue

class Block : Target(), KoinComponent {

    private val plugin: JavaPlugin by inject()

    override fun isResolved(player: Player, playerData: PlayerData): Boolean {
        return true
    }

    override fun predict(player: Player, playerData: PlayerData): BlockVector3? {
        val trace = player.rayTraceBlocks(playerData.reach.toDouble())

        var retBlock: BlockVector3? = null

        if (trace != null) {
            var hit: Block? = null

            val action = playerData.action

            if (action == null) {
                return null
            }
            val replaceAir: Boolean = playerData.replaceAir
            val centerOrigin: Boolean = playerData.centerOrigin

            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK || !replaceAir || centerOrigin) {
                hit = trace.hitBlock
            } else if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                val grassBlocks = listOf<BlockData>(
                    plugin.server.createBlockData("short_grass"),
                    plugin.server.createBlockData("fern"),
                    plugin.server.createBlockData("tall_grass[half=lower]"),
                    plugin.server.createBlockData("tall_grass[half=upper]"),
                    plugin.server.createBlockData("large_fern[half=lower]"),
                    plugin.server.createBlockData("large_fern[half=upper]")
                )

                val hitBlock = trace.hitBlock
                if(hitBlock == null) return null

                val hitBlockData = hitBlock.blockData

                val face = trace.hitBlockFace
                if(face==null) return null

                hit = if (grassBlocks.contains(hitBlockData)) {
                    hitBlock
                } else {
                    hitBlock.location.add(face.getDirection()).block
                }

                if (face == BlockFace.UP) {
                    if (hitBlockData == plugin.server.createBlockData("snow[layers=1]")) {
                        hit = trace.hitBlock
                    }
                }
            }

            if (hit == null) {
                return null
            }

            retBlock = BlockVector3.at(hit.x, hit.y, hit.z)
        } else {
            retBlock = freePlace(player, playerData)
        }

        val clicks = playerData.clicks
        if(clicks.isEmpty()){
            return retBlock
        } else {
            val boundLimit = playerData.boundLimit
            val lastClick = clicks.lastOrNull()
            if(lastClick==null) return retBlock
            if(retBlock==null) return retBlock
            return ensureBoundLimit(retBlock, lastClick.location, boundLimit)
        }


    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>>? {
        return Map.of<Int, MutableSet<BlockVector3>>()
    }
}