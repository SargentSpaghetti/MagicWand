package com.bryanvalc.magicwand.commands.regions

import com.bryanvalc.magicwand.controller.Flush
import com.bryanvalc.magicwand.data.PlayerData
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.github.shynixn.mccoroutine.bukkit.launch
import com.github.shynixn.mccoroutine.bukkit.minecraftDispatcher
import com.sk89q.worldedit.bukkit.BukkitAdapter
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.block.data.type.Leaves
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission
import java.util.UUID

class PersistLeaves: KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()
    val plugin: JavaPlugin by inject()

    @Command("persistleaves")
    @CommandPermission("magicwand.persistleaves")
    fun persist(
        actor: BukkitCommandActor
    ){
        val sender = actor.sender()
        if (sender !is Player) {
            return
        }
        val player = sender as Player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()


        val wePlayer = BukkitAdapter.adapt(player)
        val world = wePlayer.world

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList()

        val region = wePlayer.session.selection

        if(region == null) return
        for(block in region){
            val blockState = world.getBlock(block)
            val blockData = BukkitAdapter.adapt(blockState).clone()
            if (blockData is Leaves) {
                blockData.isPersistent = true
                val wrappedBlockState = SpigotConversionUtil.fromBukkitBlockData(blockData)
                shape.add(Pair(BlockVector3.at(block.x(), block.y(), block.z()), wrappedBlockState))
            }
        }
        plugin.launch(context = plugin.minecraftDispatcher) {
            Flush.placeBlocks(player, playerData, shape)
            player.sendMessage("Operation complete!.. ${shape.size} blocks changed.") //TODO change to localized
        }

    }


}