package com.bryanvalc.magicwand.utils

import com.bryanvalc.magicwand.module.KtPlugin
import com.bryanvalc.magicwand.module.config.Configuration
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import com.bryanvalc.magicwand.utils.platform.Mediator
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URI

object UpdateChecker: KoinComponent {

    private val plugin: JavaPlugin by inject()
    private val ktPlugin: KtPlugin by inject()
    private val configuration: Configuration by inject()

    private val channels = mapOf(
        "official" to "https://magicwand.voxeldart.com/download",
        "spigot" to "https://www.spigotmc.org/resources/magicwand-building-tool-24-brushes-gui-worldedit-fawe.125325",
        "discord" to "https://discord.com/channels/1055656048435920996/1362585114692817086",
        "github" to "https://github.com/BryanValc/MagicWand-Releases",
        "modrinth" to "https://modrinth.com/plugin/magicwand-building-plugin",
        "planetminecraft" to "https://www.planetminecraft.com/mod/magicwand",
        "gumroad" to "https://gumroad.com/d/8eb428e1322ce0d4da96694af8393ca7",
    )

    fun scheduleChecks() {
        plugin.server.scheduler.runTaskLater(plugin, Runnable {
            val updateConf = configuration.updateNotify
            if(updateConf.enabled && isOutDated()) {
                val players = plugin.server.onlinePlayers.asSequence().filter {
                    it.isOp || {
                        var notify = false
                        for (permission in updateConf.permissions) {
                            if (it.hasPermission(permission)) {notify = true}
                        }
                        notify
                    }.invoke()
                }
                for (player in players) {
                    val channel = channels[updateConf.channel] ?: "https://magicwand.voxeldart.com/download"
                    player.sendParsed("There's an update for MagicWand! <gradient:#3792d4:#8968d3:#8d4ca9><a:$channel>download here</a></gradient>")
                }
            }
        }, 3000L) // 2.5 min delay
    }

    fun isOutDated(): Boolean {
        val currentVersion = Mediator.getPluginVersion()

        try {
            val checkUrl = URI(ktPlugin.updateUrl).toURL()
            BufferedReader(InputStreamReader(checkUrl.openStream())).use { reader ->
                val latestVersion = reader.readLine().trim { it <= ' ' }

                return currentVersion != latestVersion
            }
        } catch(error: Exception) {
            plugin.logger.warning { "An error occurred while trying to check if there was an update." }
            plugin.logger.severe(error.message)
            return false
        }

    }

}