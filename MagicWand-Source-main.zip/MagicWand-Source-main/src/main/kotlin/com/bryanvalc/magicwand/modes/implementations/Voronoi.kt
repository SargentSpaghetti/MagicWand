package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.effects.Hull
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.BooleanProperty
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.IntProperty
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.ContinuousDistance
import com.bryanvalc.magicwand.utils.Coloring
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*
import java.util.function.Consumer
import kotlin.math.abs

class Voronoi : Mode(), Multicolor, Scrollable, Configurable {
    init {
        name = "voronoi"
        permission = "mode.voronoi"
        materialMenu = Material.GLOWSTONE_DUST
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/voronoi"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks = playerData.clicks

        val visibleCenters: MutableList<BlockVector3> = ArrayList<BlockVector3>(clicks.size + 1)
        clicks.forEach(Consumer { click: ClickData -> visibleCenters.add(click.location) })

        val pivot = playerData.pivot

        if(pivot!=null){
            visibleCenters.add(pivot)
        }

        if (visibleCenters.isEmpty()) {
            return null
        }

        var shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ObjectArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        // Calculate original bounding box
        var originalMin = visibleCenters[0]
        var originalMax = visibleCenters[0]
        for (center in visibleCenters) {
            originalMin = minBlockVector(originalMin, center)
            originalMax = maxBlockVector(originalMax, center)
        }

        // Expand bounding box
        val paddedMin = originalMin.subtract(BOUNDING_BOX_PADDING, BOUNDING_BOX_PADDING, BOUNDING_BOX_PADDING)
        val paddedMax = originalMax.add(BOUNDING_BOX_PADDING, BOUNDING_BOX_PADDING, BOUNDING_BOX_PADDING)

        // Add invisible surrounding points
        val allCenters: MutableList<BlockVector3> = ArrayList<BlockVector3>(visibleCenters)

        var chance = (50 * playerData.brushSize).toDouble()
        if (chance.isNaN() || chance <= 0) {
            chance = 1000.0
        }

        val menu = forPlayer(playerData)
        val randomize = (menu?.propertyByName("randomize.seed") as BooleanProperty?)?.value != false

        var seed = if (randomize) {
            player.location.x.toInt() + player.location.y.toInt() + player.location.z.toInt()
        } else {
            (menu?.propertyByName("seed") as IntProperty?)?.value?:1
        }
        seed = abs(seed%100)

        val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"

        addInvisibleCenters(allCenters, visibleCenters, originalMin, originalMax, paddedMin, paddedMax, chance, seed)

        // Generate Voronoi cells
        generateVoronoiDiagram(shape, allCenters, visibleCenters, paddedMin, paddedMax, blockData, player, playerData)


        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        when(filling) {
            "hollow" -> {
                shape = Hull(6,6).apply(shape)
            }
            else -> {}
        }

        val finalShape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ObjectArrayList(shape.size)

        for (row in shape) {
            putBlock(finalShape, row.first, row.second, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
        }


        return ReferenceArrayList(finalShape)
    }

    private fun addInvisibleCenters(
        allCenters: MutableList<BlockVector3>, visibleCenters: List<BlockVector3>,
        originalMin: BlockVector3, originalMax: BlockVector3,
        paddedMin: BlockVector3, paddedMax: BlockVector3, chance: Double, seed: Int
    ) {
        for (x in paddedMin.x()..paddedMax.x()) {
            for (y in paddedMin.y()..paddedMax.y()) {
                for (z in paddedMin.z()..paddedMax.z()) {
                    val point = BlockVector3.at(x, y, z)
                    if (isOutsideOriginalBoundingBox(point, originalMin, originalMax) &&
                        shouldBeInvisibleCenter(x, y, z, chance, seed) &&
                        isFarEnoughFromOriginalCells(point, visibleCenters)
                    ) {
                        allCenters.add(point)
                    }
                }
            }
        }
    }

    private fun isOutsideOriginalBoundingBox(
        point: BlockVector3,
        originalMin: BlockVector3,
        originalMax: BlockVector3
    ): Boolean {
        return point.x() < originalMin.x() || point.x() > originalMax.x() || point.y() < originalMin.y() || point.y() > originalMax.y() || point.z() < originalMin.z() || point.z() > originalMax.z()
    }

    private fun shouldBeInvisibleCenter(x: Int, y: Int, z: Int, chance: Double, seed: Int): Boolean {
        val hash = (x * 73855993 + seed) xor (y * 19349563 - seed) xor (z * 83492691 + seed)



        return abs((hash % (chance).toInt()).toDouble()) == 0.0 // 1 in 1000 chance
    }

    private fun isFarEnoughFromOriginalCells(point: BlockVector3, visibleCenters: List<BlockVector3>): Boolean {
        for (visibleCenter in visibleCenters) {
            if (point.distance(visibleCenter) < MIN_DISTANCE_TO_ORIGINAL) {
                return false
            }
        }
        return true
    }

    private fun generateVoronoiDiagram(
        shape: MutableList<Pair<BlockVector3, WrappedBlockState>>,
        allCenters: List<BlockVector3>,
        visibleCenters: List<BlockVector3>,
        min: BlockVector3,
        max: BlockVector3,
        blockData: WrappedBlockState,
        player: Player,
        playerData: PlayerData
    ) {


        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world


        for (x in min.x()..max.x()) {
            for (y in min.y()..max.y()) {
                for (z in min.z()..max.z()) {
                    val point = BlockVector3.at(x, y, z)
                    val closestCenter = findClosestCenter(point, allCenters)
                    if (visibleCenters.contains(closestCenter)) {
                        shape.add(Pair(point, blockData))
                    }
                }
            }
        }
    }

    private fun findClosestCenter(point: BlockVector3, centers: List<BlockVector3>): BlockVector3 {
        var closest = centers[0]
        var minDistance = point.distanceSq(closest).toDouble()
        for (i in 1..<centers.size) {
            val center = centers[i]
            val distance = point.distanceSq(center).toDouble()
            if (distance < minDistance) {
                minDistance = distance
                closest = center
            }
        }
        return closest
    }

    override fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        return Coloring.falloffGradient(originalMesh, player, playerData)
    }

    override fun handleScrollUp(player: Player, playerData: PlayerData) {
        val uuid = player.uniqueId
        val currentSize = playerData.brushSize + 1
        playerData.setBrushSize(uuid, currentSize)
    }

    override fun handleScrollDown(player: Player, playerData: PlayerData) {
        val uuid = player.uniqueId
        val currentSize = playerData.brushSize - 1
        playerData.setBrushSize(uuid, currentSize)
    }

    override fun getScrollTip(player: Player, playerData: PlayerData): Component? {
        val text =
            "<gray> size: <white>" + playerData.brushSize + "<gray>, <white>scroll ▲<gray> to increase size, <white>scroll ▼<gray> to decrease"
        return MiniMessage.miniMessage().deserialize(text)
    }


    companion object {
        private const val BOUNDING_BOX_PADDING = 15
        private const val MIN_DISTANCE_TO_ORIGINAL = 8 // Minimum distance from invisible to original cells
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        val menu = forPlayer(playerData)
        val connect = (menu?.propertyByName("connect") as BooleanProperty?)?.value != false

        val order = if(connect) {
            ArrayList(listOf(Block(), ContinuousDistance()))
        } else {
            ArrayList<Target>(listOf<Target>(Block()))
        }

        return order
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf(
                BooleanProperty(
                    row = 1, column = 1, name = "connect",
                    material = Material.REDSTONE,
                    lore = "connect.lore",
                    model = 1
                ),
                BooleanProperty(
                    row = 1, column = 3, name = "randomize.seed",
                    material = Material.CHORUS_FRUIT,
                    lore = "randomize.seed.lore",
                    model = 1
                ),
                IntProperty(
                    row = 1, column = 5, name = "seed",
                    material = Material.WHEAT_SEEDS,
                    lore = "seed.lore",
                    model = 1,
                    value = 1
                ),
                EnumProperty(
                    row = 1, column = 7, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = 1,
                    value = "full", options = listOf("full", "hollow"),
                    models = mapOf(
                        "full" to 1,
                        "hollow" to 3
                    )
                )
            ),
            3
        )
    }

}