package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.entity.Player

class Single : Mode() {
    init {
        name = "single"
        permission = "mode.single"
        materialMenu = Material.GOLD_NUGGET
        premium = false
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/single"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks = playerData.clicks
        if (clicks.isEmpty()) {
            return null
        }

        val click = clicks.firstOrNull()
        if(click==null) return null

        val clickLocation = click.location

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList()
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        putBlock(shape, clickLocation, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)

        return shape
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList<Target>(listOf<Block>(Block()))
    }
}