package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.DynamicTarget
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import java.util.Map

class Extend : DynamicTarget() {
    override fun isResolved(player: Player, playerData: PlayerData): Boolean {
        return true
    }

    override fun predict(player: Player, playerData: PlayerData): BlockVector3? {
        return null
    }

    override fun nextTarget(player: Player, playerData: PlayerData): Target {
        val clicks = playerData.clicks

        val previousClick = clicks.lastOrNull()
        if(previousClick==null) return ExtendY()

        val previousTarget = previousClick.target

        return if (previousTarget == null) {
            ExtendY()
        } else if (previousTarget is HitX) {
            ExtendX()
        } else if (previousTarget is HitZ) {
            ExtendZ()
        } else if (previousTarget is HitY) {
            ExtendY()
        } else {
            ExtendY()
        }
    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>> {
        return Map.of<Int, MutableSet<BlockVector3>>()
    }
}