package com.bryanvalc.magicwand.context.overlay

import com.bryanvalc.magicwand.data.PlayerData
import com.github.retrooper.packetevents.PacketEvents
import com.github.retrooper.packetevents.event.PacketListener
import com.github.retrooper.packetevents.protocol.entity.data.EntityData
import com.github.retrooper.packetevents.protocol.entity.data.EntityDataTypes
import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes
import com.github.retrooper.packetevents.protocol.world.Location
import com.github.retrooper.packetevents.wrapper.PacketWrapper
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDestroyEntities
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnEntity
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotReflectionUtil
import org.bukkit.entity.Player
import java.util.UUID

object GlowBlocks : PacketListener {
    fun glow(block: BlockVector3, player: Player, playerData: PlayerData) {
        val glowingBlocks = playerData.glowingBlocks

        if (!glowingBlocks.containsKey(block)) {
            val packets = getGlowPackets(block)
            glowingBlocks.put(block, packets.second)

            for (packet in packets.first) {
                PacketEvents.getAPI().playerManager.sendPacket(player, packet)
            }
        }
    }

    fun unGlow(block: BlockVector3, player: Player, playerData: PlayerData) {
        val glowingBlocks = playerData.glowingBlocks

        val entityId = glowingBlocks[block]

        if(entityId==null){
            return
        }

        val packet = getUnGlowPackets(entityId)
        PacketEvents.getAPI().playerManager.sendPacket(player, packet)
        glowingBlocks.remove(block)
    }

    fun unGlow(entityId: Int, player: Player) {
        val packet = getUnGlowPackets(entityId)
        PacketEvents.getAPI().playerManager.sendPacket(player, packet)
    }

    //returns a list of packets to be delivered to the player, and the id of the virtual entity
    fun getGlowPackets(block: BlockVector3): Pair<MutableList<PacketWrapper<*>>, Int> {
        val retList: MutableList<PacketWrapper<*>> = ArrayList<PacketWrapper<*>>()
        val location = Location(block.x() + 0.5, block.y().toDouble(), block.z() + 0.5, 0.0f, 0.0f)

        // Generate a random UUID
        val uuid = UUID.randomUUID()
        // Generate an Entity ID
        val entityId = SpigotReflectionUtil.generateEntityId()

        val packet = WrapperPlayServerSpawnEntity(
            entityId,
            uuid,
            EntityTypes.MAGMA_CUBE,
            location,
            0.0f,  // Head yaw
            0,  // No additional data
            null // We won't specify any initial velocity
        )
        retList.add(packet)


        val entityFlags = 0x60.toByte() // 0x20 (invisible) + 0x40 (glowing) = 0x60
        // Configure metadata for invisibility + glowing
        val metadata = listOf(
            EntityData( // effects
                0,
                EntityDataTypes.BYTE,
                entityFlags
            ),
            EntityData( // size
                16,
                EntityDataTypes.INT,
                2
            )
        )

        val metaPacket = WrapperPlayServerEntityMetadata(
            entityId,
            metadata
        )

        retList.add(metaPacket)
        return Pair(retList, entityId)
    }

    fun getUnGlowPackets(entityId: Int): PacketWrapper<*> {
        return WrapperPlayServerDestroyEntities(entityId)
    }
}