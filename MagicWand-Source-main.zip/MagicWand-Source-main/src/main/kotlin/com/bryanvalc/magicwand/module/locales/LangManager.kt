package com.bryanvalc.magicwand.module.locales

import com.bryanvalc.magicwand.module.config.Configuration
import com.bryanvalc.magicwand.utils.ConfLoader

import org.bukkit.plugin.java.JavaPlugin
import java.io.File
import java.util.Locale

class LangManager (
    val localesFolder: File,
    val config: Configuration,
    val plugin: JavaPlugin
) {

    var languages = mutableMapOf<String, Any>()

    inline fun <reified T> getForLang(language: String): T? {
        return loadLanguage(language)
    }


    inline fun <reified T> loadLanguage(language: String): T? {

        val lang = languages[language]
        if(lang!=null) return lang as T?

        var langFile = File(localesFolder, "${language}_messages.conf")
        if(!langFile.exists()){

            val defaultLang = languages[config.language.fallback] as T? // Use fallback language

            if(defaultLang == null) {
                langFile = File(localesFolder, "en_US_messages.conf")
            } else {
                return defaultLang
            }

        }

        val defaultFile = plugin.getResource("locales/en_US_messages.conf")

        val languagePackage = if (langFile.exists()) {
            ConfLoader.loadAndOrUpdate<T>(langFile, "locales/en_US_messages.conf")!!
        } else if (defaultFile!=null) {
            ConfLoader.load<T>(defaultFile, ".conf")!!
        } else {
            null
        }

        languagePackage?.let {
            languages.put(language, it)
        }

        return languagePackage
    }


}