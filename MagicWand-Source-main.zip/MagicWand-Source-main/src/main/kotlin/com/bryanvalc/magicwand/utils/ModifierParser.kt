package com.bryanvalc.magicwand.utils

import com.bryanvalc.magicwand.data.modifier.ArrayModifier
import com.bryanvalc.magicwand.data.modifier.Modifier
import com.bryanvalc.magicwand.data.modifier.RadialArrayModifier
import com.bryanvalc.magicwand.utils.platform.Mediator
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
import org.bukkit.enchantments.Enchantment
import org.bukkit.inventory.ItemFlag
import org.bukkit.inventory.ItemStack

object ModifierParser {
    fun loadFromItem(itemStack: ItemStack): Modifier? {
        val meta = itemStack.itemMeta
        if (meta == null) {
            return null
        }

        val lore = Mediator.getLore(itemStack)
        if (lore.isNullOrEmpty()) {
            return null
        }

        val loreFirst = lore.firstOrNull()
        if(loreFirst==null) return null

        var typeString = loreFirst

        if (!typeString.contains("type=")) {
            return null
        }
        typeString = typeString.replace("type=", "")

        return when (typeString) {
            "array" -> ArrayModifier(
                lore[1]!!.replace("offsetX=", "").toInt(),
                lore[2]!!.replace("offsetY=", "").toInt(),
                lore[3]!!.replace("offsetZ=", "").toInt(),
                lore[4]!!.replace("count=", "").toInt()
            )

            "radialArray" -> RadialArrayModifier(
                lore[1]!!.replace("centerX=", "").toInt(),
                lore[2]!!.replace("centerY=", "").toInt(),
                lore[3]!!.replace("centerZ=", "").toInt(),
                lore[4]!!.replace("count=", "").toInt(),
                (lore[4]!!
                    .replace("alternate=", "")).equals("yes", ignoreCase = true)
            )

            else -> null
        }
    }

    fun saveToItem(itemStack: ItemStack, modifier: Modifier) {
        val meta = itemStack.itemMeta
        if (modifier is ArrayModifier) {
            val arrayModifier = modifier

            val components = listOf<Component>(
                Component.text("type=array"),
                Component.text("offsetX=" + arrayModifier.offsetX),
                Component.text("offsetY=" + arrayModifier.offsetY),
                Component.text("offsetZ=" + arrayModifier.offsetZ),
                Component.text("count=" + arrayModifier.count)
            )

            Mediator.lore(meta, components)
            meta.addEnchant(Enchantment.DURABILITY, 1, true)
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS)
        } else if (modifier is RadialArrayModifier) {
            val arrayModifier = modifier

            val components = listOf<Component>(
                Component.text("type=radialArray"),
                Component.text("centerX=" + arrayModifier.centerX),
                Component.text("centerY=" + arrayModifier.centerY),
                Component.text("centerZ=" + arrayModifier.centerZ),
                Component.text("count=" + arrayModifier.count),
                Component.text("alternate=" + (if (arrayModifier.isAlternate) "yes" else "no"))
            )

            Mediator.lore(meta, components)
            meta.addEnchant(Enchantment.DURABILITY, 1, true)
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS)
        }

        itemStack.setItemMeta(meta)
    }
}