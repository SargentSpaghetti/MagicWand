package com.bryanvalc.magicwand.events

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.platform.Mediator
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.inventory.InventoryClickEvent
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID

class MenuInteract: Listener, KoinComponent {

    val players: MutableMap<UUID, PlayerData> by inject()


    @EventHandler
    fun onClickEvent(event: InventoryClickEvent) {
        if (event.whoClicked !is Player) return
        val player = event.whoClicked as Player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        val inventory = event.inventory

        // get persistent menu from player menus, with title of the current inventory


        val languagePack = player.getLanguagePack()


        val menu = playerData.menus.asSequence().firstOrNull {
            {
                var titleStr = "No translation found for ${it.title}"
                languagePack?.let { lp ->
                    titleStr = lp.subMenus[it.title] ?: titleStr
                }
                titleStr
            }.invoke() == Mediator.getTitle(event.view)
        }

        if (!inventory.viewers.contains(player) || menu==null) return
        event.isCancelled = true

        val slot = event.slot
        val button = menu.options.asSequence().firstOrNull { it.position() == slot} // get the item for that slot
        if (button==null) return

        if (event.isLeftClick) { // do the stuff
            val leftClickSound = button.leftClickSound
            if(leftClickSound!=null) {
                Mediator.playSound(player, leftClickSound)
            }
            button.handleLeftClick(event)
        } else if (event.isRightClick) {
            val rightClickSound = button.rightClickSound
            if(rightClickSound!=null) {
                Mediator.playSound(player, rightClickSound)
            }
            button.handleRightClick(event)
        }

        val newItem = button.getItem(player) // refresh item
        inventory.setItem(slot, newItem)

    }


}