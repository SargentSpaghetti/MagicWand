package com.bryanvalc.magicwand.context

import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.utils.platform.Mediator
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.Vector3
import com.sk89q.worldedit.math.interpolation.KochanekBartelsInterpolation
import com.sk89q.worldedit.math.interpolation.Node
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet
import org.bukkit.Location
import org.bukkit.World
import org.bukkit.block.Block
import org.bukkit.block.BlockFace
import org.bukkit.block.data.BlockData
import org.bukkit.entity.Player
import org.bukkit.event.block.Action
import org.bukkit.plugin.java.JavaPlugin
import org.bukkit.util.BlockIterator
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.*
import java.util.function.ToDoubleFunction
import java.util.stream.Collectors
import kotlin.getValue
import kotlin.math.*
import kotlin.math.pow

object BlockVectorUtils: KoinComponent {

    private val plugin: JavaPlugin by inject()

    var defaultDirections = listOf<BlockVector3>(
        BlockVector3.at(1, 0, 0),
        BlockVector3.at(-1, 0, 0),
        BlockVector3.at(0, 1, 0),
        BlockVector3.at(0, -1, 0),
        BlockVector3.at(0, 0, 1),
        BlockVector3.at(0, 0, -1)
    )

    var sphereCacheVector: MutableMap<Int, MutableList<Vector3>> =
        HashMap<Int, MutableList<Vector3>>()
    var sphereCacheBlock: MutableMap<Int, MutableList<BlockVector3>> =
        HashMap<Int, MutableList<BlockVector3>>()
    var influencesCache: MutableMap<Int, MutableMap<BlockVector3, Double>> =
        HashMap<Int, MutableMap<BlockVector3, Double>>()


    fun equalsByTolerance(first: BlockVector3, second: BlockVector3, tolerance: Double): Boolean {
        return first.distance(second) <= tolerance || first.fakeEquals(second)
    }


    fun hit(player: Player, playerData: PlayerData, firstBlock: BlockVector3, axis: Char): BlockVector3 {

        val playerLocation = player.eyeLocation
        val boundLimit = playerData.boundLimit

        val firstX = firstBlock.x()
        val firstY = firstBlock.y()
        val firstZ = firstBlock.z()

        var x = firstBlock.x()
        var y = firstBlock.y()
        var z = firstBlock.z()

        val iterator = BlockIterator(
            playerLocation,
            0.0,
            playerData.reach * 3
        )

        when (axis) {
            'X' -> {
                while (iterator.hasNext()) {
                    val block = iterator.next()
                    if (block.x == firstX) {
                        y = block.y
                        z = block.z
                        break // to avoid further iterating
                    }
                }

                y = ensureBoundLimit(y.toDouble(), firstY, boundLimit).toInt()
                z = ensureBoundLimit(z.toDouble(), firstZ, boundLimit).toInt()

                return BlockVector3.at(firstX, y, z)
            }

            'Y' -> {
                while (iterator.hasNext()) {
                    val block = iterator.next()
                    if (block.y == firstY) {
                        x = block.x
                        z = block.z
                        break // to avoid further iterating
                    }
                }

                x = ensureBoundLimit(x.toDouble(), firstX, boundLimit).toInt()
                z = ensureBoundLimit(z.toDouble(), firstZ, boundLimit).toInt()

                return BlockVector3.at(x, firstY, z)
            }

            'Z' -> {
                while (iterator.hasNext()) {
                    val block = iterator.next()
                    if (block.z == firstZ) {
                        x = block.x
                        y = block.y
                        break // to avoid further iterating
                    }
                }

                x = ensureBoundLimit(x.toDouble(), firstX, boundLimit).toInt()
                y = ensureBoundLimit(y.toDouble(), firstY, boundLimit).toInt()

                return BlockVector3.at(x, y, firstZ)
            }

            else -> throw IllegalArgumentException("Invalid axis: $axis")
        }
    }

    fun extend(player: Player, playerData: PlayerData, firstBlock: BlockVector3, axis: Char): BlockVector3 {
        val playerLocation = player.eyeLocation

        val firstX = firstBlock.x().toDouble()
        val firstY = firstBlock.y().toDouble()
        val firstZ = firstBlock.z().toDouble()


        val boundLimit = playerData.boundLimit


        val iteratorX = BlockIterator(
            playerLocation,
            0.0,
            playerData.reach * 3
        )
        var hitYPlaneX = Int.Companion.MAX_VALUE
        var hitZPlaneX = Int.Companion.MAX_VALUE
        while (iteratorX.hasNext()) {
            val block = iteratorX.next()
            if (block.x.toDouble() == firstX) {
                hitYPlaneX = block.y
                hitZPlaneX = block.z
                break // to avoid further iterating
            }
        }
        val iteratorY = BlockIterator(
            playerLocation,
            0.0,
            playerData.reach * 3
        )
        var hitXPlaneY = Int.Companion.MAX_VALUE
        var hitZPlaneY = Int.Companion.MAX_VALUE
        while (iteratorY.hasNext()) {
            val block = iteratorY.next()
            if (block.y.toDouble() == firstY) {
                hitXPlaneY = block.x
                hitZPlaneY = block.z
                break // to avoid further iterating
            }
        }
        val iteratorZ = BlockIterator(
            playerLocation,
            0.0,
            playerData.reach * 3
        )
        var hitXPlaneZ = Int.Companion.MAX_VALUE
        var hitYPlaneZ = Int.Companion.MAX_VALUE
        while (iteratorZ.hasNext()) {
            val block = iteratorZ.next()
            if (block.z.toDouble() == firstZ) {
                hitXPlaneZ = block.x
                hitYPlaneZ = block.y
                break // to avoid further iterating
            }
        }

        when (axis) {
            'X' -> {
                var extendX = if (abs(hitYPlaneZ - firstY) < abs(hitZPlaneY - firstZ)) {
                    hitXPlaneZ
                } else {
                    hitXPlaneY
                }
                extendX = ensureBoundLimit(extendX.toDouble(), firstX.toInt(), boundLimit).toInt()
                return BlockVector3.at(extendX.toDouble(), firstY, firstZ)
            }

            'Y' -> {
                var extendY= if (abs(hitXPlaneZ - firstX) < abs(hitZPlaneX - firstZ)) {
                    hitYPlaneZ
                } else {
                    hitYPlaneX
                }
                extendY = ensureBoundLimit(extendY.toDouble(), firstY.toInt(), boundLimit).toInt()
                return BlockVector3.at(firstX, extendY.toDouble(), firstZ)
            }

            'Z' -> {
                var extendZ = if (abs(hitXPlaneY - firstX) < abs(hitYPlaneX - firstY)) {
                    hitZPlaneY
                } else {
                    hitZPlaneX
                }

                extendZ = ensureBoundLimit(extendZ.toDouble(), firstZ.toInt(), boundLimit).toInt()
                return BlockVector3.at(firstX, firstY, extendZ.toDouble())
            }

            else -> throw IllegalArgumentException("Invalid axis: $axis")
        }
    }

    fun extend(player: Player, playerData: PlayerData, firstBlock: BlockVector3): BlockVector3 {
        val playerLocation = player.eyeLocation

        val firstX = firstBlock.x()
        val firstY = firstBlock.y()
        val firstZ = firstBlock.z()

        val limit = playerData.boundLimit

        val iteratorX = BlockIterator(
            playerLocation,
            0.0,
            playerData.reach * 3
        )
        var hitYPlaneX = Int.Companion.MAX_VALUE
        var hitZPlaneX = Int.Companion.MAX_VALUE
        while (iteratorX.hasNext()) {
            val block = iteratorX.next()
            if (block.x == firstX) {
                hitYPlaneX = block.y
                hitZPlaneX = block.z
                break // to avoid further iterating
            }
        }
        val iteratorY = BlockIterator(
            playerLocation,
            0.0,
            playerData.reach * 3
        )
        var hitXPlaneY = Int.Companion.MAX_VALUE
        var hitZPlaneY = Int.Companion.MAX_VALUE
        while (iteratorY.hasNext()) {
            val block = iteratorY.next()
            if (block.y == firstY) {
                hitXPlaneY = block.x
                hitZPlaneY = block.z
                break // to avoid further iterating
            }
        }
        val iteratorZ = BlockIterator(
            playerLocation,
            0.0,
            playerData.reach * 3
        )
        var hitXPlaneZ = Int.Companion.MAX_VALUE
        var hitYPlaneZ = Int.Companion.MAX_VALUE
        while (iteratorZ.hasNext()) {
            val block = iteratorZ.next()
            if (block.z == firstZ) {
                hitXPlaneZ = block.x
                hitYPlaneZ = block.y
                break // to avoid further iterating
            }
        }

        val diffXHitXPlaneZ = abs((hitXPlaneZ - firstX).toDouble())
        val diffZHitZPlaneX = abs((hitZPlaneX - firstZ).toDouble())
        val diffYHitYPlaneX = abs((hitYPlaneX - firstY).toDouble())
        val diffXHitXPlaneY = abs((hitXPlaneY - firstX).toDouble())
        val diffZHitZPlaneY = abs((hitZPlaneY - firstZ).toDouble())
        val diffYHitYPlaneZ = abs((hitYPlaneZ - firstY).toDouble())

        val minDiff = min(
            min(min(min(min(diffXHitXPlaneZ, diffZHitZPlaneX), diffYHitYPlaneX), diffXHitXPlaneY), diffZHitZPlaneY),
            diffYHitYPlaneZ
        )

        val candidates: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        if (diffXHitXPlaneZ == minDiff) { //we use the Y axis
            hitYPlaneZ = ensureBoundLimit(hitYPlaneZ.toDouble(), firstY, limit).toInt()
            candidates.add(BlockVector3.at(firstX, hitYPlaneZ, firstZ))
        }
        if (diffZHitZPlaneX == minDiff) { //we use the Y axis
            hitYPlaneX = ensureBoundLimit(hitYPlaneX.toDouble(), firstY, limit).toInt()
            candidates.add(BlockVector3.at(firstX, hitYPlaneX, firstZ))
        }
        if (diffYHitYPlaneX == minDiff) { //we use the Z axis
            hitZPlaneX = ensureBoundLimit(hitZPlaneX.toDouble(), firstZ, limit).toInt()
            candidates.add(BlockVector3.at(firstX, firstY, hitZPlaneX))
        }
        if (diffXHitXPlaneY == minDiff) { //we use the Z axis
            hitZPlaneY = ensureBoundLimit(hitZPlaneY.toDouble(), firstZ, limit).toInt()
            candidates.add(BlockVector3.at(firstX, firstY, hitZPlaneY))
        }

        if (diffZHitZPlaneY == minDiff) { //we use the X axis
            hitXPlaneY = ensureBoundLimit(hitXPlaneY.toDouble(), firstX, limit).toInt()
            candidates.add(BlockVector3.at(hitXPlaneY, firstY, firstZ))
        }
        if (diffYHitYPlaneZ == minDiff) { //we use the X axis
            hitXPlaneZ = ensureBoundLimit(hitXPlaneZ.toDouble(), firstX, limit).toInt()
            candidates.add(BlockVector3.at(hitXPlaneZ, firstY, firstZ))
        }

        if (candidates.isEmpty()) {
            return firstBlock
        }

        val winner = candidates.stream()
            .sorted(Comparator.comparingDouble<BlockVector3>(ToDoubleFunction { c: BlockVector3 ->
                c.distance(
                    firstBlock
                )
            }))
            .collect(Collectors.toList())
            .firstOrNull()

        return winner ?: firstBlock

    }

    fun trace(player:Player, playerData: PlayerData): BlockVector3? {
        val offset = playerData.offset

        if(offset.isNaN()) return null

        val traceResult = player.rayTraceBlocks(offset*2)
        if(traceResult==null) return null

        var hit: Block? = null
        val action = playerData.action

        if (action == null) {
            return null
        }
        val replaceAir: Boolean = playerData.replaceAir
        val centerOrigin: Boolean = playerData.centerOrigin

        if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK || !replaceAir || centerOrigin) {
            hit = traceResult.hitBlock
        } else if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            val grassBlocks = listOf<BlockData>(
                plugin.server.createBlockData("short_grass"),
                plugin.server.createBlockData("fern"),
                plugin.server.createBlockData("tall_grass[half=lower]"),
                plugin.server.createBlockData("tall_grass[half=upper]"),
                plugin.server.createBlockData("large_fern[half=lower]"),
                plugin.server.createBlockData("large_fern[half=upper]")
            )

            val hitBlock = traceResult.hitBlock
            if(hitBlock == null) return null

            val hitBlockData = hitBlock.blockData

            val face = traceResult.hitBlockFace
            if(face==null) return null

            hit = if (grassBlocks.contains(hitBlockData)) {
                hitBlock
            } else {
                hitBlock.location.add(face.getDirection()).block
            }

            if (face == BlockFace.UP) {
                if (hitBlockData == plugin.server.createBlockData("snow[layers=1]")) {
                    hit = traceResult.hitBlock
                }
            }
        }

        if (hit == null) {
            return null
        }

        return BlockVector3.at(hit.x, hit.y, hit.z)
    }

    fun freePlace(player: Player, playerData: PlayerData): BlockVector3 {
        val traced = if(playerData.snap){
            trace(player, playerData)
        } else { null }
        if(traced!=null) return traced

        val playerLocation = player.eyeLocation

        val direction = getDirection(playerLocation)
        val reach = playerData.reach.toDouble()

        val extendX: Double = playerLocation.x + direction.dx * reach
        val extendY: Double = playerLocation.y + direction.dy * reach
        val extendZ: Double = playerLocation.z + direction.dz * reach

        return BlockVector3.at(extendX, extendY, extendZ)
    }

    fun freeExtend(player: Player, playerData: PlayerData, firstBlock: BlockVector3): BlockVector3 {
        val traced = if(playerData.snap){
            trace(player, playerData)
        } else { null }

        val boundLimit = playerData.boundLimit

        if (traced!==null) {
            return BlockVector3.at(
                ensureBoundLimit(traced.x().toDouble(), firstBlock.x(), boundLimit),
                ensureBoundLimit(traced.y().toDouble(), firstBlock.y(), boundLimit),
                ensureBoundLimit(traced.z().toDouble(), firstBlock.z(), boundLimit))
        }

        val playerLocation = player.eyeLocation

        val direction = getDirection(playerLocation)
        var offset = playerData.offset
        if(playerData.snap) {
            offset*=2
        }


        var extendX: Double = playerLocation.x + direction.dx * offset
        var extendY: Double = playerLocation.y + direction.dy * offset
        var extendZ: Double = playerLocation.z + direction.dz * offset

        extendX = ensureBoundLimit(extendX, firstBlock.x(), boundLimit)
        extendY = ensureBoundLimit(extendY, firstBlock.y(), boundLimit)
        extendZ = ensureBoundLimit(extendZ, firstBlock.z(), boundLimit)

        return BlockVector3.at(extendX, extendY, extendZ)
    }

    fun centerExtend(player: Player, playerData: PlayerData): BlockVector3 {
        val clicks: MutableList<ClickData> = playerData.clicks.toMutableList()

        var sumX = 0
        var sumY = 0
        var sumZ = 0
        if (clicks.isEmpty()) {
            sumX = player.x.toInt()
            sumY = player.y.toInt()
            sumZ = player.z.toInt()
        } else {
            for (click in clicks) {
                val location = click.location
                sumX += location.x()
                sumY += location.y()
                sumZ += location.z()
            }
        }

        val center = BlockVector3.at(sumX / clicks.size, sumY / clicks.size, sumZ / clicks.size)
        val boundLimit = playerData.boundLimit

        val traced = if(playerData.snap){
            trace(player, playerData)
        } else { null }
        if (traced!==null) {
            return BlockVector3.at(
                ensureBoundLimit(traced.x().toDouble(), center.x(), boundLimit),
                ensureBoundLimit(traced.y().toDouble(), center.y(), boundLimit),
                ensureBoundLimit(traced.z().toDouble(), center.z(), boundLimit))
        }

        val playerLocation = player.eyeLocation

        val direction = getDirection(playerLocation)
        var offset = playerData.offset
        if(playerData.snap) {
            offset*=2
        }

        var extendX: Double = playerLocation.x + direction.dx * offset
        var extendY: Double = playerLocation.y + direction.dy * offset
        var extendZ: Double = playerLocation.z + direction.dz * offset

        extendX = ensureBoundLimit(extendX, center.x(), boundLimit)
        extendY = ensureBoundLimit(extendY, center.y(), boundLimit)
        extendZ = ensureBoundLimit(extendZ, center.z(), boundLimit)

        return BlockVector3.at(extendX, extendY, extendZ)
    }

    fun closestToSight(
        player: Player, playerData: PlayerData, firstBlock: BlockVector3, sightLimit: Int): BlockVector3? {
        val playerLocation = player.eyeLocation
        val boundLimit = playerData.boundLimit
        val originLines = genLines(boundLimit)

        val lines = ReferenceArrayList<BlockVector3>(originLines.size)
        for(block in originLines) {
            lines.add(block.add(firstBlock))
        }

        val iterator = BlockIterator(
            playerLocation,
            0.0,
            min(playerData.reach * 3,sightLimit)
        )

        val sight = ReferenceOpenHashSet<BlockVector3>(sightLimit)

        while (iterator.hasNext()) {
            val block = iterator.next()
            val blockVector = BlockVector3.at(block.x, block.y, block.z)
            sight.add(blockVector)
        }
        val closest = lines.asSequence().sortedWith(compareBy {
            squareDistanceToClosest(it, sight)
        }).first()

        return closest

    }

    fun closestToSolidInSight(
        player: Player, playerData: PlayerData, firstBlock: BlockVector3?=null,
        sightLimit: Int, checkDistance: Int, acceptableDistance: Int): BlockVector3? {

        val playerLocation = player.eyeLocation
        val playerBlockVector = BlockVector3.at(playerLocation.x, playerLocation.y, playerLocation.z)
        val boundLimit = playerData.boundLimit
        val world = player.world

        val iterator = BlockIterator(
            playerLocation,
            0.0,
            min(playerData.reach * 3,sightLimit)
        )

        var blockToReturn: BlockVector3? = null

        val candidates = Object2ObjectOpenHashMap<BlockVector3, Set<BlockVector3>>(min(playerData.reach * 3,sightLimit))
        val startFrom = 5
        var currentNum = 0
        while (iterator.hasNext()) {
            val block = iterator.next()

            if(currentNum<=startFrom) {
                currentNum+=1
                continue
            }

            if(!block.isEmpty){
                val toReturn = BlockVector3.at(block.x,block.y,block.z)
                if(toReturn.distance(playerBlockVector)<=15) return null // so Block() can handle it
            }

            val neighbors = ObjectOpenHashSet<BlockVector3>((checkDistance*2.0+1).toDouble().pow(3.0).toInt())
            for(x in (block.x-checkDistance)..(block.x+checkDistance)) {
                for(y in (block.y-checkDistance)..(block.y+checkDistance)) {
                    for(z in (block.z-checkDistance)..(block.z+checkDistance)) {
                        if(!world.getBlockAt(x,y,z).isEmpty){
                            neighbors.add(BlockVector3.at(x,y,z))
                        }
                    }
                }
            }
            if(neighbors.isNotEmpty()){
                candidates[BlockVector3.at(block.x, block.y, block.z)] = neighbors
            }
        }

        val finalCandidates = Object2ObjectOpenHashMap<BlockVector3, Double>()
        var minDistance = Double.MAX_VALUE
        for(candidate in candidates.entries) {
            val distance = distanceToClosest(candidate.key, candidate.value)
            if(distance <= acceptableDistance) {
                blockToReturn =  candidate.key //avoid further processing in this point
                break
            }
            if(distance<=minDistance) {
                minDistance = distance
            }
            finalCandidates[candidate.key] = distance
        }

        if(blockToReturn!=null){
            return if(firstBlock==null) {
                blockToReturn
            } else {
                ensureBoundLimit(blockToReturn, firstBlock, boundLimit)
            }
        }

        for(candidate in finalCandidates.entries) {
            if(candidate.value == minDistance) {
                blockToReturn = candidate.key
            }
        }
        return if(blockToReturn!=null){
            if(firstBlock==null) {
                blockToReturn
            } else {
                ensureBoundLimit(blockToReturn, firstBlock, boundLimit)
            }
        } else {
            firstBlock
        }

    }

    fun distanceToClosest(block: BlockVector3, blocks: Set<BlockVector3>): Double {
        if(blocks.isEmpty()) return Double.MAX_VALUE
        val closestBlock = blocks.asSequence().sortedWith(compareBy{it.distance(block)}).firstOrNull()
        if(closestBlock == null) return Double.MAX_VALUE

        return block.distance(closestBlock)

    }

    fun squareDistanceToClosest(block: BlockVector3, blocks: Set<BlockVector3>): Int {
        if(blocks.isEmpty()) return Int.MAX_VALUE
        val closestBlock = blocks.asSequence().sortedWith(compareBy{it.distanceSq(block)}).firstOrNull()
        if(closestBlock == null) return Int.MAX_VALUE

        return block.distanceSq(closestBlock)

    }

    fun perpendicularExtend(player: Player, playerData: PlayerData, firstBlock: BlockVector3): BlockVector3 {
        val playerLocation = player.eyeLocation
        val boundLimit = playerData.boundLimit

        val iterator = BlockIterator(
            playerLocation,
            0.0,
            playerData.reach * 3
        )


        val candidates: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        while (iterator.hasNext()) {
            val block = iterator.next()
            candidates.add(BlockVector3.at(block.x, block.y, block.z))
        }

        val winner = candidates
            .stream()
            .sorted(Comparator.comparingDouble<BlockVector3>(ToDoubleFunction { c: BlockVector3 ->
                c.distance(
                    firstBlock
                )
            }))
            .collect(Collectors.toList())
            .firstOrNull()




        var extendX: Double = (winner ?: firstBlock).x().toDouble()
        var extendY: Double = (winner ?: firstBlock).y().toDouble()
        var extendZ: Double = (winner ?: firstBlock).z().toDouble()

        extendX = ensureBoundLimit(extendX, firstBlock.x(), boundLimit)
        extendY = ensureBoundLimit(extendY, firstBlock.y(), boundLimit)
        extendZ = ensureBoundLimit(extendZ, firstBlock.z(), boundLimit)

        return BlockVector3.at(extendX, extendY, extendZ)
    }

    fun ensureBoundLimit(hit: Double, firstBlock: Int, limit: Int): Double {
        return if (firstBlock - hit >= limit) {
            (firstBlock - limit + 1).toDouble()
        } else if (hit - firstBlock >= limit) {
            (firstBlock + limit - 1).toDouble()
        } else {
            hit
        }
    }

    fun ensureBoundLimit(hit: BlockVector3, firstBlock: BlockVector3, limit: Int): BlockVector3 {
        return BlockVector3.at(
            ensureBoundLimit(hit.x().toDouble(), firstBlock.x(), limit),
            ensureBoundLimit(hit.y().toDouble(), firstBlock.y(), limit),
            ensureBoundLimit(hit.z().toDouble(), firstBlock.z(), limit)
        )
    }

    private fun getDirection(playerLocation: Location): DoubleVector {
        val yaw = Math.toRadians((playerLocation.yaw + 90).toDouble())
        val pitch = Math.toRadians(playerLocation.pitch.toDouble())

        val dx = cos(yaw) * cos(pitch)
        val dy = -sin(pitch)
        val dz = sin(yaw) * cos(pitch)

        return DoubleVector(dx, dy, dz)
    }

    fun minBlockVector(vararg blocks: BlockVector3): BlockVector3 {
        var minX = Int.Companion.MAX_VALUE
        var minY = Int.Companion.MAX_VALUE
        var minZ = Int.Companion.MAX_VALUE

        for (blockVector in blocks) {
            minX = min(minX, blockVector.x())
            minY = min(minY, blockVector.y())
            minZ = min(minZ, blockVector.z())
        }

        return BlockVector3.at(minX, minY, minZ)
    }

    fun maxBlockVector(vararg blocks: BlockVector3): BlockVector3 {
        var maxX = Int.Companion.MIN_VALUE
        var maxY = Int.Companion.MIN_VALUE
        var maxZ = Int.Companion.MIN_VALUE

        for (blockVector in blocks) {
            maxX = max(maxX, blockVector.x())
            maxY = max(maxY, blockVector.y())
            maxZ = max(maxZ, blockVector.z())
        }

        return BlockVector3.at(maxX, maxY, maxZ)
    }

    fun boundingBox(vararg blocks: BlockVector3): List<BlockVector3> {
        val min = minBlockVector(*blocks)
        val max = maxBlockVector(*blocks)

        val minX = min.x()
        val minY = min.y()
        val minZ = min.z()
        val maxX = max.x()
        val maxY = max.y()
        val maxZ = max.z()

        return listOf(
            BlockVector3.at(minX, minY, minZ),
            BlockVector3.at(minX, minY, maxZ),
            BlockVector3.at(minX, maxY, minZ),
            BlockVector3.at(minX, maxY, maxZ),
            BlockVector3.at(maxX, minY, minZ),
            BlockVector3.at(maxX, minY, maxZ),
            BlockVector3.at(maxX, maxY, minZ),
            BlockVector3.at(maxX, maxY, maxZ)
        )
    }

    fun anyWithinBounds(first: BlockVector3, last: BlockVector3, blocks: List<BlockVector3>): Boolean {
        for(block in blocks) {
            if(isInsideCube(first, last, block)){
                return true
            }
        }
        return false
    }

    fun isInsideCyl(
        min: Location,
        max: Location,
        center: Location,
        radius: DoubleVector,
        evaluated: IntVector,
        axis: Char
    ): Boolean {
        val x = evaluated.dx
        val y = evaluated.dy
        val z = evaluated.dz

        val radiusX = radius.dx
        val radiusY = radius.dy
        val radiusZ = radius.dz

        val termX = (x - center.x).pow(2.0) / radiusX.pow(2.0)
        val termY = (y - center.y).pow(2.0) / radiusY.pow(2.0)
        val termZ = (z - center.z).pow(2.0) / radiusZ.pow(2.0)

        when (axis) {
            'X' -> return termY + termZ <= 1 && (x >= min.x && x <= max.x)
            'Y' -> return termX + termZ <= 1 && (y >= min.y && y <= max.y)
            'Z' -> return termX + termY <= 1 && (z >= min.z && z <= max.z)
        }
        return false
    }

    fun isInsideSphere(min: Location, max: Location, evaluated: BlockVector3): Boolean {
        val center = Location(
            min.getWorld(),
            (min.x + max.x) / 2.0,
            (min.y + max.y) / 2.0,
            (min.z + max.z) / 2.0
        ) // Getting the midpoint without modifying original locations

        val x = evaluated.x()
        val y = evaluated.y()
        val z = evaluated.z()

        val radiusX = (max.x - min.x) / 2.0
        val radiusY = (max.y - min.y) / 2.0
        val radiusZ = (max.z - min.z) / 2.0

        val termX = (x - center.x).pow(2.0) / radiusX.pow(2.0)
        val termY = (y - center.y).pow(2.0) / radiusY.pow(2.0)
        val termZ = (z - center.z).pow(2.0) / radiusZ.pow(2.0)

        return termX + termY + termZ <= 1
    }

    fun isInsideCube(first: BlockVector3, last: BlockVector3, eval: BlockVector3): Boolean {
        var newCubeMin: BlockVector3 = minBlockVector(first, last)
        var newCubeMax: BlockVector3 = maxBlockVector(first, last)

        val minX = newCubeMin.x()
        val minY = newCubeMin.y()
        val minZ = newCubeMin.z()
        val maxX = newCubeMax.x()
        val maxY = newCubeMax.y()
        val maxZ = newCubeMax.z()

        val x = eval.x()
        val y = eval.y()
        val z = eval.z()

        return (minX <= x && x <= maxX && minY <= y && y <=maxY && minZ <= z && z <= maxZ)

    }

    fun bresenham3D(start: Vector3, end: Vector3): MutableList<Vector3> {

        val nodeGroup: MutableList<Node> = ObjectArrayList<Node>()
        val node1 = Node(start)
        val node2 = Node(end)
        nodeGroup.add(node1)
        nodeGroup.add(node2)

        val curvesResolution = 1/(start.distance(end)*2)

        val interpolation = KochanekBartelsInterpolation()
        interpolation.setNodes(nodeGroup)
        val retList: MutableList<Vector3> = ObjectArrayList<Vector3>(max(1,(1/curvesResolution).toInt()))

        var i = 0.0
        while (i < 1) {
            val floatingPoint = interpolation.getPosition(i)
            retList.add(floatingPoint)
            i += curvesResolution
        }

        return retList

    }

    fun stacker(blocks: List<Vector3>, start: Vector3, end: Vector3): MutableList<Vector3> {

        val scatteredAcross = bresenham3D(start, end)

        val blocksOffset = ArrayList<Vector3>(blocks.size)
        blocks.forEach { blocksOffset.add(it.subtract(start)) }

        val retList: MutableList<Vector3> = ObjectArrayList<Vector3>(max(1,(scatteredAcross.size*blocksOffset.size)))

        for(placement in scatteredAcross) {
            for(block in blocksOffset) {
                retList.add(block.add(placement))
            }
        }

        return retList

    }

    fun bresenham3D(start: BlockVector3, end: BlockVector3): MutableList<BlockVector3> {
        val points: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        val x1 = start.x()
        val y1 = start.y()
        val z1 = start.z()
        val x2 = end.x()
        val y2 = end.y()
        val z2 = end.z()

        val dx = x2 - x1
        val dy = y2 - y1
        val dz = z2 - z1

        var x = x1
        var y = y1
        var z = z1
        val ax = abs(dx.toDouble()).toInt() shl 1
        val ay = abs(dy.toDouble()).toInt() shl 1
        val az = abs(dz.toDouble()).toInt() shl 1

        val sx = if (dx > 0) 1 else -1
        val sy = if (dy > 0) 1 else -1
        val sz = if (dz > 0) 1 else -1

        if (ax >= max(ay.toDouble(), az.toDouble())) {
            var yd = ay - (ax shr 1)
            var zd = az - (ax shr 1)
            while (true) {
                points.add(BlockVector3.at(x, y, z))
                if (x == x2) {
                    return points
                }
                if (yd >= 0) {
                    y += sy
                    yd -= ax
                }
                if (zd >= 0) {
                    z += sz
                    zd -= ax
                }
                x += sx
                yd += ay
                zd += az
            }
        } else if (ay >= max(ax.toDouble(), az.toDouble())) {
            var xd = ax - (ay shr 1)
            var zd = az - (ay shr 1)
            while (true) {
                points.add(BlockVector3.at(x, y, z))
                if (y == y2) {
                    return points
                }
                if (xd >= 0) {
                    x += sx
                    xd -= ay
                }
                if (zd >= 0) {
                    z += sz
                    zd -= ay
                }
                y += sy
                xd += ax
                zd += az
            }
        } else if (az >= max(ax.toDouble(), ay.toDouble())) {
            var xd = ax - (az shr 1)
            var yd = ay - (az shr 1)
            while (true) {
                points.add(BlockVector3.at(x, y, z))
                if (z == z2) {
                    return points
                }
                if (xd >= 0) {
                    x += sx
                    xd -= az
                }
                if (yd >= 0) {
                    y += sy
                    yd -= az
                }
                z += sz
                xd += ax
                yd += ay
            }
        }
        return points
    }

    fun stacker(blocks: List<BlockVector3>, start: BlockVector3, end: BlockVector3): MutableList<BlockVector3> {
        //convert the input list of blocks to a list of offsets relative to the start block

        val offsets: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (block in blocks) {
            offsets.add(block.subtract(start))
        }

        val points: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        val x1 = start.x()
        val y1 = start.y()
        val z1 = start.z()
        val x2 = end.x()
        val y2 = end.y()
        val z2 = end.z()

        val dx = x2 - x1
        val dy = y2 - y1
        val dz = z2 - z1

        var x = x1
        var y = y1
        var z = z1
        val ax = abs(dx.toDouble()).toInt() shl 1
        val ay = abs(dy.toDouble()).toInt() shl 1
        val az = abs(dz.toDouble()).toInt() shl 1

        val sx = if (dx > 0) 1 else -1
        val sy = if (dy > 0) 1 else -1
        val sz = if (dz > 0) 1 else -1

        if (ax >= max(ay.toDouble(), az.toDouble())) {
            var yd = ay - (ax shr 1)
            var zd = az - (ax shr 1)
            while (true) {
                for (offset in offsets) {
                    points.add(BlockVector3.at(x, y, z).add(offset))
                }
                if (x == x2) {
                    return points
                }
                if (yd >= 0) {
                    y += sy
                    yd -= ax
                }
                if (zd >= 0) {
                    z += sz
                    zd -= ax
                }
                x += sx
                yd += ay
                zd += az
            }
        } else if (ay >= max(ax.toDouble(), az.toDouble())) {
            var xd = ax - (ay shr 1)
            var zd = az - (ay shr 1)
            while (true) {
                for (offset in offsets) {
                    points.add(BlockVector3.at(x, y, z).add(offset))
                }
                if (y == y2) {
                    return points
                }
                if (xd >= 0) {
                    x += sx
                    xd -= ay
                }
                if (zd >= 0) {
                    z += sz
                    zd -= ay
                }
                y += sy
                xd += ax
                zd += az
            }
        } else if (az >= max(ax.toDouble(), ay.toDouble())) {
            var xd = ax - (az shr 1)
            var yd = ay - (az shr 1)
            while (true) {
                for (offset in offsets) {
                    points.add(BlockVector3.at(x, y, z).add(offset))
                }
                if (z == z2) {
                    return points
                }
                if (xd >= 0) {
                    x += sx
                    xd -= az
                }
                if (yd >= 0) {
                    y += sy
                    yd -= az
                }
                z += sz
                xd += ax
                yd += ay
            }
        }
        return points
    }

    fun removeTailingLoc(originalClicks: List<BlockVector3>, compareLast: Int): MutableList<BlockVector3> {
        if (originalClicks.isEmpty() || originalClicks.size <= compareLast) {
            return originalClicks.toMutableList()
        }

        val copy: MutableList<BlockVector3> = ArrayList<BlockVector3>(originalClicks)
        val buffer: MutableList<BlockVector3> = ArrayList<BlockVector3>(originalClicks)

        val last = copy.lastOrNull()
        if(last==null) return originalClicks.toMutableList()

        var willRemove = true
        var i = 0
        while (i < compareLast) {
            val eval = buffer.removeLast()
            if (!equalsByTolerance(eval, last, 3.0)) {
                willRemove = false
            }

            i += 1
        }

        if (willRemove) {
            copy.removeLast()
            return copy
        }

        return copy
    }

    fun removeTailingClick(originalClicks: List<ClickData>, compareLast: Int): MutableList<ClickData> {
        if (originalClicks.isEmpty() || originalClicks.size <= compareLast) {
            return originalClicks.toMutableList()
        }

        val copy: MutableList<ClickData> = ArrayList<ClickData>(originalClicks)
        val buffer: MutableList<ClickData> = ArrayList<ClickData>(originalClicks)

        val last = copy.lastOrNull()
        if(last==null) return originalClicks.toMutableList()

        var willRemove = true
        for (i in 0..<compareLast) { // Check only 'compareLast' elements
            val eval = buffer.removeLast()
            if (!equalsByTolerance(eval.location, last.location, 3.0)) {
                willRemove = false
            }
        }

        if (willRemove) {
            copy.removeLast()
            return copy
        }

        return copy
    }

    fun fill(pos1: BlockVector3,pos2: BlockVector3): List<BlockVector3> {
        val newCubeMin: BlockVector3 = minBlockVector(pos1, pos2)
        val newCubeMax: BlockVector3 = maxBlockVector(pos1, pos2)

        val minX = newCubeMin.x()
        val minY = newCubeMin.y()
        val minZ = newCubeMin.z()
        val maxX = newCubeMax.x()
        val maxY = newCubeMax.y()
        val maxZ = newCubeMax.z()

        val retList = ObjectArrayList<BlockVector3>((maxX-minX+1)*(maxY-minY+1)*(maxZ-minZ+1))

        for (x in minX..maxX) {
            for (y in minY..maxY) {
                for (z in minZ..maxZ) {
                    retList.add(BlockVector3.at(x,y,z))
                }
            }
        }

        return retList
    }

//    listOf<BlockVector3>(
//    BlockVector3.at(-1,-1,-1),
//    BlockVector3.at(-1,-1,0),
//    BlockVector3.at(-1,-1,1),
//    BlockVector3.at(-1,0,-1),
//    BlockVector3.at(-1,0,0),
//    BlockVector3.at(-1,0,1),
//    BlockVector3.at(-1,1,-1),
//    BlockVector3.at(-1,1,0),
//    BlockVector3.at(-1,1,1),
//    BlockVector3.at(0,-1,-1),
//    BlockVector3.at(0,-1,0),
//    BlockVector3.at(0,-1,1),
//    BlockVector3.at(0,0,-1),
//    BlockVector3.at(0,0,0),
//    BlockVector3.at(0,0,1),
//    BlockVector3.at(0,1,-1),
//    BlockVector3.at(0,1,0),
//    BlockVector3.at(0,1,1),
//    BlockVector3.at(1,-1,-1),
//    BlockVector3.at(1,-1,0),
//    BlockVector3.at(1,-1,1),
//    BlockVector3.at(1,0,-1),
//    BlockVector3.at(1,0,0),
//    BlockVector3.at(1,0,1),
//    BlockVector3.at(1,1,-1),
//    BlockVector3.at(1,1,0),
//    BlockVector3.at(1,1,1)
//    )

    fun genLines(length: Int, directions: List<BlockVector3> =
        listOf<BlockVector3>(
            BlockVector3.at(-1,-1,0),
            BlockVector3.at(-1,0,-1),
            BlockVector3.at(-1,0,0),
            BlockVector3.at(-1,0,1),
            BlockVector3.at(-1,1,0),
            BlockVector3.at(0,-1,-1),
            BlockVector3.at(0,-1,0),
            BlockVector3.at(0,-1,1),
            BlockVector3.at(0,0,-1),
            BlockVector3.at(0,0,1),
            BlockVector3.at(0,1,-1),
            BlockVector3.at(0,1,0),
            BlockVector3.at(0,1,1),
            BlockVector3.at(1,-1,0),
            BlockVector3.at(1,0,-1),
            BlockVector3.at(1,0,0),
            BlockVector3.at(1,0,1),
            BlockVector3.at(1,1,0)
        )
    ): List<BlockVector3> {
        val retList = ReferenceArrayList<BlockVector3>(length*directions.size)

        for (multiplier in 1..length) {
            for (direction in directions) {
                retList.add(direction.multiply(multiplier))
            }
        }

        return retList
    }

    fun getCleanSphereVector(world: World, gridSize: Int): MutableList<Vector3> {
        if (gridSize <= 0) {
            return listOf(Vector3.at(0.0, 0.0, 0.0)).toMutableList()
        }

        val cached = sphereCacheVector[gridSize]
        if(cached!=null) return cached

        val ret: MutableList<Vector3> = ArrayList<Vector3>()
        val locMin = Location(world, -gridSize - 0.5, -gridSize - 0.5, -gridSize - 0.5)
        val locMax = Location(world, gridSize + 0.5, gridSize + 0.5, gridSize + 0.5)

        val part: MutableList<Vector3> = ArrayList<Vector3>()
        for (x in -gridSize..0) {
            for (y in -gridSize..0) {
                for (z in -gridSize..0) {
                    val evaluated = BlockVector3.at(x, y, z)

                    if (isInsideSphere(locMin, locMax, evaluated)) {
                        part.add(
                            Vector3.at(
                                evaluated.x().toDouble(),
                                evaluated.y().toDouble(),
                                evaluated.z().toDouble()
                            )
                        )
                    }
                }
            }
        }

        for (x in -1..1) {
            for (y in -1..1) {
                for (z in -1..1) {
                    if (x == 0 || y == 0 || z == 0) {
                        continue
                    }

                    if (x == 1 && y == 1 && z == 1) {
                        ret.addAll(part)
                    } else {
                        val multiplier = Vector3.at(x.toDouble(), y.toDouble(), z.toDouble())
                        for (eval in part) {
                            ret.add(eval.multiply(multiplier))
                        }
                    }
                }
            }
        }

        sphereCacheVector[gridSize] = ret

        return ret
    }

    fun getCleanSphereBlock(world: World, gridSize: Int): MutableList<BlockVector3> {
        if (gridSize <= 0) {
            return listOf(BlockVector3.at(0, 0, 0)).toMutableList()
        }

        val cached = sphereCacheBlock[gridSize]
        if(cached!=null) return cached

        val ret: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        val locMin = Location(world, -gridSize - 0.5, -gridSize - 0.5, -gridSize - 0.5)
        val locMax = Location(world, gridSize + 0.5, gridSize + 0.5, gridSize + 0.5)

        val part: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (x in -gridSize..0) {
            for (y in -gridSize..0) {
                for (z in -gridSize..0) {
                    val evaluated = BlockVector3.at(x, y, z)

                    if (isInsideSphere(locMin, locMax, evaluated)) {
                        part.add(evaluated)
                    }
                }
            }
        }

        for (x in -1..1) {
            for (y in -1..1) {
                for (z in -1..1) {
                    if (x == 0 || y == 0 || z == 0) {
                        continue
                    }

                    if (x == 1 && y == 1 && z == 1) {
                        ret.addAll(part)
                    } else {
                        val multiplier = BlockVector3.at(x, y, z)
                        for (eval in part) {
                            ret.add(eval.multiply(multiplier))
                        }
                    }
                }
            }
        }

        sphereCacheBlock[gridSize] = ret

        return ret.toMutableList()
    }

    fun preCalculateInfluence(radius: Double): MutableMap<BlockVector3, Double> {
        val intRadius = (2 * radius).toInt()

        val cached = influencesCache[intRadius]
        if (cached!=null) return cached

        val influenceCache: MutableMap<BlockVector3, Double> = HashMap<BlockVector3, Double>()
        val r2 = radius * radius
        for (dx in -intRadius..intRadius) {
            for (dy in -intRadius..intRadius) {
                for (dz in -intRadius..intRadius) {
                    val offset = BlockVector3.at(dx, dy, dz)
                    val distanceSquared = offset.lengthSq().toDouble()
                    val influence = max(0.0, r2 / distanceSquared - 1 / 4.0)
                    if (influence > 0) {
                        influenceCache.put(offset, influence)
                    }
                }
            }
        }

        influencesCache[intRadius] = influenceCache

        return influenceCache
    }

    fun breadthFirstSearch(
        domain: List<BlockVector3>,
        directions: List<BlockVector3>,
        origin: BlockVector3,
        depth: Int
    ): MutableList<BlockVector3> {
        val visited: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        val queue: Queue<BlockVector3> = LinkedList<BlockVector3>()
        val depthMap: MutableMap<BlockVector3, Int> = HashMap<BlockVector3, Int>()

        // Initialize the queue and depth map with the origin
        queue.add(origin)
        depthMap.put(origin, 0)

        while (queue.isNotEmpty()) {
            val current = queue.poll()
            val currentDepth: Int = depthMap.computeIfAbsent(current) { 0 }

            // If the current depth exceeds the specified depth, stop exploring further
            if (currentDepth >= depth) {
                continue
            }


            // Explore all directions from the current position
            for (direction in directions) {
                val neighbor = current.add(direction)

                // Check if the neighbor is within the domain and hasn't been visited
                if (domain.contains(neighbor) && !depthMap.containsKey(neighbor)) {
                    visited.add(neighbor)
                    queue.add(neighbor)
                    depthMap.put(neighbor, currentDepth + 1)
                }
            }
        }

        return visited
    }

    fun depthFirstSearch(
        domain: List<BlockVector3>,
        directions: List<BlockVector3>,
        origin: BlockVector3,
        depth: Int
    ): MutableList<BlockVector3> {
        val visited: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        val stack = Stack<BlockVector3>()
        val depthMap: MutableMap<BlockVector3, Int> = HashMap<BlockVector3, Int>()

        // Initialize the stack and depth map with the origin
        stack.push(origin)
        depthMap.put(origin, 0)

        while (stack.isNotEmpty()) {
            val current = stack.pop()
            val currentDepth: Int = depthMap.computeIfAbsent(current) { 0 }

            // If the current depth exceeds the specified depth, stop exploring further
            if (currentDepth >= depth) {
                continue
            }

            // Explore all directions from the current position
            for (direction in directions) {
                val neighbor = current.add(direction)

                // Check if the neighbor is within the domain and hasn't been visited
                if (domain.contains(neighbor) && !depthMap.containsKey(neighbor)) {
                    visited.add(neighbor)
                    stack.push(neighbor)
                    depthMap.put(neighbor, currentDepth + 1)
                }
            }
        }

        return visited
    }


    fun hasAllNeighbors(possibleNeighbors: Set<BlockVector3>, eval: BlockVector3): Boolean {
        var hasAll = true
        for (neighbour in defaultDirections) {
            if (!possibleNeighbors.contains(eval.add(neighbour))) {
                hasAll = false
            }
        }
        return hasAll
    }

    fun allBlocksAroundAreSolid(eval: BlockVector3, world: World): Boolean {
        var hasAll = true
        for (neighbour in defaultDirections) {
            val offsetBlock = eval.add(neighbour)

            val block = world.getBlockAt(offsetBlock.x(), offsetBlock.y(), offsetBlock.z())
            if (!Mediator.isSolid(block)) {
                hasAll = false
            }
        }
        return hasAll
    }


    fun nearestSolidInY(eval: BlockVector3, world: World, maxDist: Int): BlockVector3? {
        val candidates: MutableList<Block> = ReferenceArrayList<Block>()

        var x = eval.x() - maxDist
        while (x <= eval.x() + maxDist) {
            var z = eval.z() - maxDist
            while (z <= eval.z() + maxDist) {
                val block = world.getBlockAt(x, eval.y(), z)
                if (Mediator.isSolid(block)) {
                    candidates.add(block)
                }
                z += 1
            }
            x += 1
        }
        if (candidates.isEmpty()) {
            return null
        }

        val evalLoc = Location(world, eval.x().toDouble(), eval.y().toDouble(), eval.z().toDouble())

        val winnerLoc = candidates.stream()
            .sorted(Comparator.comparingDouble<Block>(ToDoubleFunction { c: Block ->
                c.location.distance(evalLoc)
            }))
            .collect(Collectors.toList())
            .firstOrNull()

        if(winnerLoc==null) return null

        return BlockVector3.at(winnerLoc.x, winnerLoc.y, winnerLoc.z)
    }

    class DoubleVector(var dx: Double, var dy: Double, var dz: Double)

    class IntVector(var dx: Int, var dy: Int, var dz: Int)
}

fun BlockVector3.fakeEquals(other: BlockVector3): Boolean {
    if (other == null) {
        return false
    }
    return other.x() == this.x() && other.y() == this.y() && other.z() == this.z()
}


fun Vector3.fakeToBlockPoint(): BlockVector3 {
    return BlockVector3.at(this.x(), this.y(), this.z())
}