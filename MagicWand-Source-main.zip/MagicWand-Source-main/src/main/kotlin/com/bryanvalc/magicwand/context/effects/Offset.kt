package com.bryanvalc.magicwand.context.effects

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ObjectArrayList

class Offset(
    val offset: BlockVector3 = BlockVector3.at(0, 0, 0)
): Effect {

    override fun apply(original: List<Pair<BlockVector3, WrappedBlockState>>): MutableList<Pair<BlockVector3, WrappedBlockState>> {

        var retList = ObjectArrayList<Pair<BlockVector3, WrappedBlockState>>(original.size)
        for(row in original) {
            retList.add(Pair(row.first.add(offset), row.second))
        }

        return retList
    }
}