package com.bryanvalc.magicwand.modes

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu

interface Configurable {

    fun defaultMenu(): Menu

    fun forPlayer(playerData: PlayerData): Menu? {
        val defaultMenu = defaultMenu()
        if(!playerData.menus.contains(defaultMenu)) {
            playerData.menus.add(defaultMenu)
        }
        val menu = playerData.menus.asSequence().firstOrNull {
            it.title ==
                    defaultMenu.title}
        return menu
    }

}