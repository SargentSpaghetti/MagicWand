package com.bryanvalc.magicwand.module


import org.bukkit.Bukkit
import org.bukkit.plugin.java.JavaPlugin
import java.io.File

class Loader(
    val plugin: JavaPlugin
) {

    fun createInitialConfig() {
        if(!plugin.dataFolder.exists()){
            val couldCreate = plugin.dataFolder.mkdir()
            if(!couldCreate) plugin.logger.warning("Couldn't create plugin folder")
        }

        var configFile = File(plugin.dataFolder, "config.conf")
        if(!configFile.exists()){
            plugin.saveResource("config.conf", false)
        }

        var textureLegacy = File(plugin.dataFolder, "MagicWand-LegacyRP.zip")
        if(!textureLegacy.exists()){
            plugin.saveResource("MagicWand-LegacyRP.zip", false)
        }

        var textureModern = File(plugin.dataFolder, "MagicWand-ModernRP.zip")
        if(!textureModern.exists()){
            plugin.saveResource("MagicWand-ModernRP.zip", false)
        }

        try {
            var textureFileBedrock = File(plugin.dataFolder, "MagicWand.mcpack")
            if(!textureFileBedrock.exists()){
                plugin.saveResource("MagicWand.mcpack", false)

                val textureBedrockNew  = File(plugin.dataFolder, "MagicWand.mcpack")
                val geyser = Bukkit.getPluginManager().getPlugin("Geyser-Spigot")
                if (geyser != null && textureBedrockNew.exists()) {
                    plugin.logger.info { "Geyser detected, saving mcpack in the packs folder, this is a one-time process" }
                    textureBedrockNew.copyTo(File(geyser.dataFolder, "packs/MagicWand.mcpack"))
                }

            }
        } catch (_: Exception) {

        }


        var defaultLocale = File(plugin.dataFolder, "locales/en_US_messages.conf")
        if(!defaultLocale.exists()){
            plugin.saveResource("locales/en_US_messages.conf", false)
        }
        var mxLocale = File(plugin.dataFolder, "locales/es_MX_messages.conf")
        if(!mxLocale.exists()){
            plugin.saveResource("locales/es_MX_messages.conf", false)
        }

        val defaultRegistries = listOf("1_8_8.conf", "1_13_2.conf","1_14_4.conf","1_15_2.conf","1_16_5.conf","1_17_1.conf","1_18_2.conf",
            "1_19_4.conf", "1_20_4.conf", "1_21.conf")

        for(registry in defaultRegistries) {
            val registryFile = File(plugin.dataFolder, "material_registry/$registry")
            if(!registryFile.exists()){
                plugin.saveResource("material_registry/$registry", false)
            }
        }

    }

}