package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.data.modifier.ArrayModifier
import com.bryanvalc.magicwand.data.modifier.Modifier
import com.bryanvalc.magicwand.data.modifier.RadialArrayModifier
import com.bryanvalc.magicwand.utils.ModifierParser
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.annotation.Suggest
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission

class ModifierCommand: KoinComponent {

    val plugin: JavaPlugin by inject()

    @Command("modifier")
    @CommandPermission("magicwand.modifier")
    fun modifier(
        actor: BukkitCommandActor,
        @Suggest("array", "radialArray") modifierType: String){

        val sender = actor.sender()
        if (sender !is Player) {
            return
        }
        val player = sender as Player

        var modifier: Modifier = when (modifierType) {
            "array" -> ArrayModifier(0, 4, 0, 3)
            "radialArray" -> RadialArrayModifier(player.location.x.toInt(), player.location.y.toInt(), player.location.z.toInt(), 4, true)
            else -> {ArrayModifier(0, 4, 0, 3)}
        }

        val itemStack = player.inventory.itemInMainHand
        ModifierParser.saveToItem(itemStack, modifier)
    }

}