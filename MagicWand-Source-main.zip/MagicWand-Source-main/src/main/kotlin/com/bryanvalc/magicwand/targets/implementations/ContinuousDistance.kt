package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.centerExtend
import com.bryanvalc.magicwand.context.BlockVectorUtils.equalsByTolerance
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import java.lang.Double
import java.util.Map
import kotlin.math.pow
import kotlin.math.sqrt

class ContinuousDistance : Target() {
    override fun isResolved(player: Player, playerData: PlayerData): Boolean {
        val clicks = playerData.clicks
        if (clicks.isEmpty()) {
            return false
        }
        if (clicks.size >= 2) {
            val lastClickLocation = clicks[clicks.size - 2].location
            val prediction = predict(player, playerData)
            if(prediction!=null){
                return equalsByTolerance(lastClickLocation, prediction, 3.0)
            }
            return false
        } else {
            return false
        }
    }

    override fun predict(player: Player, playerData: PlayerData): BlockVector3? {
        val clicks = playerData.clicks
        if (clicks.isEmpty()) {
            return null
        }

        val lastClick= clicks.lastOrNull()
        if(lastClick==null) return null

        val lastClickLocation = lastClick.location
        var offset = playerData.offset

        if (Double.isNaN(offset)) {
            val playerLocation = player.location

            offset = sqrt(
                (lastClickLocation.x() - playerLocation.x).pow(2.0) + (lastClickLocation.y() - (playerLocation.y + 1.62)).pow(
                    2.0
                ) + (lastClickLocation.z() - playerLocation.z).pow(2.0)
            )

            playerData.offset = offset
        }

        return centerExtend(player, playerData)
    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>> {
        return Map.of<Int, MutableSet<BlockVector3>>()
    }
}