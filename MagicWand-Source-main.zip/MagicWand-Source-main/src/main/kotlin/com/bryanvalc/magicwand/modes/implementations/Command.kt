package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.VirtualTransform.getShape
import com.bryanvalc.magicwand.context.effects.Hull
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.Extend
import com.bryanvalc.magicwand.targets.implementations.ExtendX
import com.bryanvalc.magicwand.targets.implementations.ExtendY
import com.bryanvalc.magicwand.targets.implementations.ExtendZ
import com.bryanvalc.magicwand.targets.implementations.Hit
import com.bryanvalc.magicwand.targets.implementations.HitWall
import com.bryanvalc.magicwand.targets.implementations.HitX
import com.bryanvalc.magicwand.targets.implementations.HitY
import com.bryanvalc.magicwand.targets.implementations.HitZ
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.bukkit.BukkitAdapter
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.inventory.meta.BookMeta
import java.util.*

class Command : Mode(), Configurable {
    init {
        name = "command"
        permission = "mode.command"
        materialMenu = Material.matchMaterial("CHAIN") ?: Material.IRON_BARS
        premium = false
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/command"
    }

    val presets = mapOf<String, String>(
        "NONE" to "",
        "pyramid" to "abs(x) < -y && abs(z) < -y",
        "fade" to "y=(y+1)/2; y > random()",
        "perlin" to "perlin(32,x,y,z,0.03,1,0) > 0.5",
        "perlinPersist" to "perlin(4653,x,y,z,0.02,8,0.5) > 0.5",
        "perlin2DTerra" to "perlin(1,x,0,z,3,1,0) > (y+1)*(2)",
        "voronoi2DTerra" to "voronoi(1,x,0,z,3) > (y+1)*(2)",
        "ridged2DTerra" to "ridgedmulti(1,x,0,z,3,1) > (y+1)*(2)",
        "perlin3DTerra" to "perlin(1,x,y,z,3,1,0) > (y+1)*(2)",
        "voronoi3DTerra" to "voronoi(1,x,y,z,3) > (y+1)*(2)",
        "ridged3DTerra" to "ridgedmulti(1,x,y,z,3,1) > (y+1)*(2)",
        "perlinLayers" to "perlin(1,x,y*3,z,2,1,1)>0.5",
        "floatingLand" to "thresh=abs(x)+abs(y)+abs(z)-1; perlin(1,x,y*3,z,2,1,1)>thresh",
        "floatingLands" to "thresh=max(abs(x),abs(y),abs(z)); perlin(1,x,y*3,z,2,1,1)>thresh",
        "terrainPillar" to "thresh=x*x+z*z; perlin(1,x,y*3,z,2,1,1)>thresh",
        "baseWithLands" to "thresh=(y+1)/2; perl=perlin(1,x,y*3,z,2,1,1); data=perl*6.99; perl>thresh",
        "blobSphere" to "thresh=(x*x+y*y+z*z); perlin(1,x,y,z,6,1,1)>thresh",
        "torus" to "torus=((0.7-sqrt(x*x+y*y))^2+z*z)/0.2^2; torus<1",
        "torus2" to "major_r=0.7; minor_r=0.3; (major_r-sqrt(x*x+z*z))^2+y^2 < minor_r^2",
        "octahedron" to "(abs(x)+abs(y)+abs(z) <= 1)",
        "fluffyBall" to "radius=0.75; return ((x*x + y*y + z*z) + random()/8 < radius^2)",
        "doubleCone" to "x*x+z*z-y*y<0",
        "hourglass" to "x*x+z*z-y*y + abs(y)^20 < 0.01",
        "cone" to "x*x+z*z-(y/2-.5)^2<0",
        "flippedCone" to "x*x+z*z-(y/2+.5)^2<0",
        "wave2D" to "sin(2*pi*x) > y",
        "wave3D" to "sin(2*pi*x) + sin(2*pi*z) > 2*y",
        "spiral" to "x+=sin(2*pi*y)/2; z+=cos(2*pi*y)/2; r=0.3; return (x*x+z*z < r^2)",
        "drill" to "r=sqrt(x*x+z*z); r>y+1",
        "theta" to "theta=(atan2(x,z)/2/pi+0.5); 2*theta>y+1",
        "curveTerrain" to "theta=(atan2(x,z)/2/pi+0.5); r=sqrt(x*x+z*z); 1-abs(r-theta)>y+1;",
        "polygon" to "N=5; a=atan2(x,z); r=(cos(pi/N))/cos(a-((2*pi)/N)*floor((N*a+pi)/(2*pi))); (x^2+z^2)<r^2",
        "tunnels" to "((x^4+y^4+z^4-x*x-y*y-z*z)^2-0.2)^2 < 0.001",
        "fancyTower" to "((x*x+y*y*y*5+z*z-2.3)*(x*x+z*z-0.5))^2 < 0.02",
        "bridge" to "(y> -(x^2)+0.85)*(z*z<0.95)*(y<0.95)+(z*z>0.85)*(y>0.9)",
        "fancyBridge" to "(((x^4-0.6+y)^2<0.05*x^2)+((x^2/5-y+0.75)^2<0.02))*(z*z*9<8)*(y*9<8)+(z*z*7>6)*(y*9>8)",
        "6spike" to "((x^2+y^2+(z/9)^2-0.01)*((x/9)^2+y^2+z^2-0.01)*(x^2+(y/9)^2+z^2-0.01))^2 <9^-6",
        "vase" to "(((x*x-y^5+z*z-1))^2<0.005)+((x^2+z^2+(y+0.99)^2*1500-0.4)^2 <0.3)",
        "tornado" to "(((atan2(x,z)+(y-1)*20+1/(x*x+z*z))*(atan2(x,z)+6.2832+(y-1)*20+1/(x*x+z*z)))^2<2)",
        "hollowSpiral" to "(((x-0.4*sin(y*5))^2+(z-0.4*cos(y*5))^2-0.04))^2 <0.00007",
        "pumpkin" to "(((x^2+1.5*y^2+z^2-(0.7+0.05*cos(16*atan2(x,z)))))^2 <0.01)",
        "pumpkin2" to "n=9;t=12;u=0.8;y^2<=(((t+cos(n*atan2(z,x)))/(t+1))^2-x^2-z^2)*(1-u*e^(-8*(x^2+z^2)))",
        "santaHat" to "t=0.1;h=0.15;w=y+((x-1)/2)^4;v=(x+((w+1)/2)^4)^2+z^2-((1.25-w)/2.5)^3-(y<(2*h-1)?t:0);data=(v?0:(y<(2*h-1)?0:14));v<0||(x+0.8)^2+(y-0.05)^2+z^2-0.2^2<0.01",
        "tetraHedron" to "sqrt(x^2+z^2)<=(1-y)/1.41*cos(pi/3)/cos(2/3*asin(cos(3/2*atan2(z,x))))&&y>=-1/3",
        "dodecahedron" to "sqrt(x^2+z^2)<=(1+y/1.619)*cos(pi/5)/cos(2/5*asin(cos(5/2*atan2(z,x))))/0.85&&sqrt(x^2+z^2)<=(1-y/1.619)*cos(pi/5)/cos(2/5*asin(cos(5/2*(atan2(z,x)-pi))))/0.85&&abs(y)<=0.8",
        "heart" to "a=0.5;b=sqrt(1-abs(z)^2);(y<a*b)?y>=b*((1+a)*(-4*sqrt(1-abs(x/b))/5-(1-abs(x/b))^5/5)+a):y<=b*((1-a)*sqrt(1-(1-2*abs(x/b))^2)+a)",
        "colosseum" to "a=0.6;b=0.8;c=0.8;n=12;m=3;t=0.25;u=3*b/n;v=abs(1-sqrt(x^2+z^2)-t/2);w=(abs(atan2(z,x)+pi/n)%(2*pi/n)-pi/n);(((y+1)/2)%(1/m)*m<=a)?abs(w)>=u&&v<=t/2:w^2+(u*((y+1)/2%(1/m)*m-a)/c/(1-a))^2>=u^2&&v<=t/2",
        "stem" to "h=0.5;u=0;v=0;sqrt((x+u*((y+1)/2)^1.5)^2+(z+v*((y+1)/2)^1.5)^2)<=1.8*sqrt(1-y)/(y+2)/(2*h+e^(-40*(y-1+2*h)))+0.1",
        "onion" to "x^2+z^2<=4*(y+1)*e^-((1.5*(y+1))^2)",
        "perlinSpiral" to "perlin(1,x,3*sqrt(x^2+z^2),z,10,1,1)<0.5",
        "perlinCircles" to "perlin(1,1,3*sqrt(x^2+z^2),1,10,1,1)<0.5",
        "squares" to "perlin(1,1,3*max(abs(x),abs(z)),1,10,1,1)<0.5",
        "squareSpiral" to "p=perlin(1,x,20*(abs(x)+abs(z)),z,1,1,1);data=p*10%4;p<0.4",
        "godRays" to "perlin(1,1,atan2(x,z),1,5,1,1)<0.4",
        "spiralTerrain" to "rotate(x,z,2*y);p=perlin(1,x,3*sqrt(x^2+z^2),z,3,1,1);data=p*5%5;y+1<p*(1/(1+e^(5*(sqrt(x^2+z^2)-0.5))))",
        "hill" to "y+1<1/(1+e^(5*(sqrt(x^2+z^2)-0.5)))",
        "waveTerrain" to "y+1<2*perlin(23,x*2,1,z,3,1,1)*(perlin(2,x,1,z,2,1,1)-0.2)*(1-sqrt(x^2+z^2)^8)",
        "brushStroke" to "rotate(x,z,pi/4);m=0.6;n=0.4;p1=perlin(1,x,50*sqrt(x^2+z^2),z,2.5,1,1);p2=perlin(1,x,20*sqrt(x^2+z^2),z,1.5,1,1);rotate(x,z,p2/10);t=atan2(z,x)/pi+1;data=(t*p1+p1*0.2)*5%15+5;abs((sqrt(x^2+z^2)-(m+n/2)))<(n/2)&&(p1-t/2)",
        "caveSpikes" to "p=perlin(1,x,1,z,5,1,1);L=(p+1)/2-sqrt(x^2+z^2);1-y^2<2*p*L",
        "marble" to "p2=perlin(1,x,y,z,1,1,1);p1=perlin(1,x,y*8+p2*5,z,3,1,1);data=p1*4%4;x^2+z^2+y^2<0.85+0.15*p1",
        "floatingFlatLand" to "n = perlin(435, x, 0, z, 2, 2, 0.75); r = 1 - (x^2 + z^2); -y < 2*n*r - 1",
        "sand" to "n = ridgedmulti(0, x, 0, z, 1, 1); y < n - 1",
        "hill2" to "n = perlin(100, x, 0, z, 1, 2, 0.5); r = 1 - sqrt(x^2 + z^2); y < n*r - 1",
        "hill3" to "n = perlin(100, x, 0, z, 1, 2, 0.5); r = 1 - (x^2 + z^2); y < n*r - 1",
        "hill4" to "n = perlin(100, x, 0, z, 1, 2, 0.5); r = 1 - (abs(x)^3 + abs(z)^3) ^ (1 / 3); y < n*r - 1",
        "hill5" to "n = perlin(100, x, 0, z, 1, 2, 0.5); r = (x^2 + z^2 < 1 ? sin(sqrt(pi * x^2 + pi * z^2)) : 1); y < n*r - 1",
        "perlinTerrain" to "n = perlin(100, x, 0, z, 1, 2, 0.5); r = (x^2 + z^2 < 1 ? sin(sqrt(pi * x^2 + pi * z^2)) : 1); y < n*r - 1",
        "conePillar" to "r=sqrt(x^2+z^2);10*(r-0.06)<(y+1)^3",
        "rockyFloatingIsland" to "r=sqrt(x^2+z^2);10*(r-0.06)+2.5*voronoi(1,x,y,z,5)<(y+1)^3",
        "worlyFloatingIsland" to "r=sqrt(x^2+z^2);rotate(x,z,10*(1+y));10*(r-0.06)+2.5*voronoi(1,x,y,z,5)<(y+1)^3",
        "roundDome" to "i=sqrt(x^2+z^2);k=0.9;a=6.5;b=0.9;m=0.6;i<k*a^(-b*(y+m)^2)",
        "texturedDome" to "G=min(sin(18*atan2(x,z)+20*(y+1)),sin(18*atan2(x,z)-20*(y+1)));data=(G>(-0.7))?4:13;i=sqrt(x^2+z^2);k=0.9;a=6.5;b=0.9;m=0.6;i<k*a^(-b*(y+m)^2)+0.02*G",
        "curlyDome" to "G=sin(18*atan2(x,z)+10*(y+1));i=sqrt(x^2+z^2);k=0.9;a=6.5;b=0.9;m=0.6;i<k*a^(-b*(y+m)^2)+0.05*G",
        "octaDome" to "r=1-(y+1)^2/4;n=8;sqrt(x^2+z^2)/cos(pi/n)*cos(pi/n-((atan2(x,z)+pi)%(2*pi/n)))<r",
        "bumpedOctaDome" to "r=1-(y+1)^2/4;sqrt(x^2+z^2)/(0.8-0.1*abs(sin(5*atan2(x,z))))<r",
        "driller" to "rotate(x,z,(1+y));r=1-(y+1)^2/4;sqrt(x^2+z^2)/(0.8-0.1*abs(sin(5*atan2(x,z))))<r",
        "spiralSphere" to "A=(atan2(x,z)+pi)/pi;type=(((A+(1+y))*40)%8<2)?35:0;x^2+z^2+y^2<1",
        "twistedCables" to "a=atan2(x,z)*2;x1=sqrt(x^2+z^2)-0.7;X=x1*cos(a)-y*sin(a);Y=x1*sin(a)+y*cos(a);data=(X<0)?(Y>0?1:2):(Y<0?3:4);(abs(X)-0.1)^2+(abs(Y)-0.1)^2<0.1^2",
        "twistedCable" to "a=atan2(x,z)/2;x1=sqrt(x^2+(z)^2)-0.7;X=x1*cos(a)-y*sin(a);Y=x1*sin(a)+y*cos(a);(X)^2+15*Y^2<0.2^2",
        "twistedPlane" to "a=(1+z)*pi/2;X=x*cos(a)-y*sin(a);Y=x*sin(a)+y*cos(a);X^2+15*Y^2<0.2^2"
    )

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        if (clickLocations.size == 1 || clickLocations.size == 2) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocations.add(pivot)
            }
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val lastTarget = playerData.floatingTarget
        val axis = if (lastTarget is HitX || lastTarget is ExtendX) {
            'X'
        } else if (lastTarget is HitY || lastTarget is ExtendY) {
            'Y'
        } else if (lastTarget is HitZ || lastTarget is ExtendZ) {
            'Z'
        } else {
            'Y'
        }

        val menu = forPlayer(playerData)
        val origin = (menu?.propertyByName("origin") as EnumProperty?)?.value?:"corner"
        val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"
        val preset = (menu?.propertyByName("preset") as EnumProperty?)?.value?:"NONE"


        when(origin) {
            "center" -> {
                val firstClick = clickLocations.firstOrNull()
                val lastClick = clickLocations.lastOrNull()
                if(firstClick!=null && lastClick!=null) {
                    val diff = lastClick.subtract(firstClick)
                    val otherCorner = firstClick.subtract(diff)
                    clickLocations.add(otherCorner)
                }
            }
            "wall" -> {
                val firstClick = clickLocations.firstOrNull()
                val lastClick = clickLocations.lastOrNull()
                if(firstClick!=null && lastClick!=null) {
                    var diff = lastClick.subtract(firstClick)

                    if(axis == 'X') {
                        diff = diff.withX(0)
                    } else if(axis == 'Y') {
                        diff = diff.withY(0)
                    }  else if(axis == 'Z') {
                        diff = diff.withZ(0)
                    }

                    val otherCorner = firstClick.subtract(diff)
                    clickLocations.add(otherCorner)
                }
            }
        }

        val newCubeMin: BlockVector3 = minBlockVector(*clickLocations.toTypedArray<BlockVector3>())
        val newCubeMax: BlockVector3 = maxBlockVector(*clickLocations.toTypedArray<BlockVector3>())

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null


        val weWorld = BukkitAdapter.adapt(world)
        val wePlayer: com.sk89q.worldedit.entity.Player? = BukkitAdapter.adapt(player)
        if(wePlayer==null) return null

        val expression = if (preset == "NONE") {
            val commands = getCommands(player)
            if (commands.isNullOrEmpty()) return null
            commands.firstOrNull()
        } else {
            val chosenPreset = presets[preset]
            if (chosenPreset == null) return null
            chosenPreset
        }

        if(expression==null) return null
        val eval = getShape(newCubeMin, newCubeMax, weWorld, expression)
        var evalWithBlockData: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((eval.size * 1.25).toInt()))
        for(block in eval) {
            evalWithBlockData.add(Pair(block, blockData))
        }
        when(filling) {
            "hollow" -> {
                evalWithBlockData = Hull(6,6).apply(evalWithBlockData)
            }
            else -> {}
        }

        for (block in evalWithBlockData) {
            putBlock(shape, block.first, block.second, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
        }

        return shape
    }

    fun getCommands(player: Player): MutableList<String>? {
        val itemInHand = player.inventory.itemInOffHand

        if (itemInHand.type != Material.WRITABLE_BOOK) {
            return null
        }

        val bookMeta = itemInHand.itemMeta as BookMeta

        val pages = bookMeta.pages()

        if (pages.isEmpty()) {
            return null
        }

        val commands: MutableList<String> = ArrayList<String>()

        for (page in pages) {
            val pageText = PlainTextComponentSerializer.plainText().serialize(page)
            val lines: Array<String> = pageText.split("\n".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            commands.addAll(listOf(*lines))
        }

        return commands
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        val menu = forPlayer(playerData)
        val lock = (menu?.propertyByName("facing") as EnumProperty?)?.value?:"floor"

        val order = when(lock) {
            "floor" -> ArrayList(listOf(Block(), HitY(), Extend()))
            "wall" -> ArrayList(listOf(Block(), HitWall(), Extend()))
            else -> ArrayList(listOf(Block(), Hit(), Extend()))
        }

        return order
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "preset",
                    material = Material.WRITABLE_BOOK,
                    lore = "preset.lore",
                    model = 1,
                    value = "NONE", options = presets.keys.toList()
                ),
                EnumProperty(
                    row = 1, column = 3, name = "facing",
                    material = Material.QUARTZ,
                    lore = "facing.lore",
                    model = null,
                    value = "floor", options = listOf("any", "floor", "wall"),
                    models = mapOf(
                        "any" to 1,
                        "floor" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 5, name = "origin",
                    material = Material.NETHER_WART,
                    lore = "origin.lore",
                    model = null,
                    value = "corner", options = listOf("corner", "center", "wall"),
                    models = mapOf(
                        "corner" to 1,
                        "center" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 7, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = null,
                    value = "full", options = listOf("full", "hollow"),
                    models = mapOf(
                        "full" to 1,
                        "hollow" to 3
                    )
                )
            ),
            3
        )
    }

}