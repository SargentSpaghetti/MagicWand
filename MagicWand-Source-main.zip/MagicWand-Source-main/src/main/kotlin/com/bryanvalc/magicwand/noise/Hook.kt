package com.bryanvalc.magicwand.noise

import com.bryanvalc.magicwand.module.PluginRepository
import com.bryanvalc.magicwand.noise.mask.parser.ClassicMaskParser
import com.bryanvalc.magicwand.noise.pattern.parser.*
import com.bryanvalc.magicwand.noise.mask.parser.*
import com.sk89q.worldedit.WorldEdit
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

class Hook: KoinComponent {

    val pluginRepository: PluginRepository by inject()
    val plugin: JavaPlugin by inject()

    fun register() {

        if (!pluginRepository.faweEnabled) {
            plugin.logger.warning { "FAWE not detected, couldn't add 30 extra noise patterns" }
            return
        }

        val we = WorldEdit.getInstance()

        val patterns = WorldEdit.getInstance().patternFactory
        patterns.register(ClassicPatternParser(we))
        patterns.register(FoamPatternParser(we))
        patterns.register(GlitchPatternParser(we))
        patterns.register(JitterPatternParser(we))
        patterns.register(MerlinPatternParser(we))
        patterns.register(VinyPatternParser(we))
        patterns.register(SeededPatternParser(we))
        patterns.register(ExponentialPatternParser(we))
        patterns.register(LayeredPatternParser(we))
        patterns.register(WhitePatternParser(we))
        patterns.register(LayeredSpiralPatternParser(we))
        patterns.register(SlickPatternParser(we))
        patterns.register(TurbulentPatternParser(we))
        patterns.register(RidgedPatternParser(we))
        patterns.register(MaelstromPatternParser(we))
        patterns.register(WarpedPatternParser(we))
        patterns.register(JackPatternParser(we))
        patterns.register(LumpPatternParser(we))
        patterns.register(MasonPatternParser(we))
        patterns.register(OctopusPatternParser(we))
        patterns.register(PhantomPatternParser(we))
        patterns.register(PyrlinPatternParser(we))
        patterns.register(PyrPatternParser(we))
        patterns.register(UnifiedPatternParser(we))
        patterns.register(ValuePatternParser(we))
        patterns.register(VastPatternParser(we))
        patterns.register(WarblePatternParser(we))
        patterns.register(WavePatternParser(we))
        patterns.register(WeavingPatternParser(we))
        patterns.register(FastPatternParser(we))

        val masks = WorldEdit.getInstance().maskFactory
        masks.register(ClassicMaskParser(we))
        masks.register(ExponentialMaskParser(we))
        masks.register(FastMaskParser(we))
        masks.register(FoamMaskParser(we))
        masks.register(GlitchMaskParser(we))
        masks.register(JackMaskParser(we))
        masks.register(JitterMaskParser(we))
        masks.register(LayeredMaskParser(we))
        masks.register(LayeredSpiralMaskParser(we))
        masks.register(LumpMaskParser(we))
        masks.register(MaelstromMaskParser(we))
        masks.register(MasonMaskParser(we))
        masks.register(MerlinMaskParser(we))
        masks.register(OctopusMaskParser(we))
        masks.register(PhantomMaskParser(we))
        masks.register(PyrlinMaskParser(we))
        masks.register(PyrMaskParser(we))
        masks.register(RidgedMaskParser(we))
        masks.register(SeededMaskParser(we))
        masks.register(SlickMaskParser(we))
        masks.register(TurbulentMaskParser(we))
        masks.register(UnifiedMaskParser(we))
        masks.register(ValueMaskParser(we))
        masks.register(VastMaskParser(we))
        masks.register(VinyMaskParser(we))
        masks.register(WarbleMaskParser(we))
        masks.register(WarpedMaskParser(we))
        masks.register(WaveMaskParser(we))
        masks.register(WeavingMaskParser(we))
        masks.register(WhiteMaskParser(we))
    }

}