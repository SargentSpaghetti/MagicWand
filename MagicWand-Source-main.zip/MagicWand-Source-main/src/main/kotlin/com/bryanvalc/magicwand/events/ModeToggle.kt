package com.bryanvalc.magicwand.events

import com.bryanvalc.magicwand.context.Display.reset
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.ModeManager
import com.bryanvalc.magicwand.module.KtPlugin
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import com.bryanvalc.magicwand.utils.platform.Mediator
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
import org.bukkit.Material
import org.bukkit.event.EventHandler
import org.bukkit.event.EventPriority
import org.bukkit.event.Listener
import org.bukkit.event.block.Action
import org.bukkit.event.player.PlayerInteractEvent
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID

class ModeToggle : Listener, KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()
    private val modeManager: ModeManager by inject()
    private val ktPlugin: KtPlugin by inject()

    @EventHandler(priority = EventPriority.LOW)
    fun onPlayerSwap(event: PlayerInteractEvent) {
        if(!(event.action == Action.RIGHT_CLICK_AIR || event.action == Action.RIGHT_CLICK_BLOCK)) return

        val player = event.player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        val currentMode = playerData.mode

        val itemStack = player.inventory.itemInMainHand
        if(itemStack.type!= Material.NETHER_STAR) return

        val plainText = Mediator.getDisplayName(itemStack)
        if(plainText == null) return


        var nextMode = modeManager.getFromName(plainText)

        if(nextMode == null) return
        if(currentMode == nextMode) return

        reset(player, playerData)
        val message: Component? = playerData.setMode(nextMode)

        if(message==null){
            player.sendParsed(ktPlugin.premiumMessage)
        } else {
            var model = 1
            val allModes = modeManager.modes
            val toAdd = allModes.indexOf(nextMode)+1
            model+=toAdd

            var meta = itemStack.itemMeta
            Mediator.displayName(meta, nextMode.name)
            meta.setCustomModelData(model)
            itemStack.itemMeta = meta

            player.sendActionBar(message)
        }
//        playerData.lastInteraction = System.currentTimeMillis()
        players[uuid] = playerData
        event.isCancelled = true
    }
}