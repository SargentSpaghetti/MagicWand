package com.bryanvalc.magicwand.module

import kotlinx.serialization.Serializable

@Serializable
data class MaterialList(
    val name: String,
    val materialList: Set<String>
)