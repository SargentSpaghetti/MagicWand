package com.bryanvalc.magicwand.modes


import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.utils.platform.Mediator
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.Material
import org.bukkit.World
import org.bukkit.entity.Player

abstract class Mode {
    var name: String = ""
    var permission: String = ""
    var materialMenu: Material? = null
    var premium: Boolean = true
    var wiki: String = ""

    abstract fun draw(player: Player, playerData: PlayerData): MutableList<Pair<BlockVector3, WrappedBlockState>>?

    abstract fun getInteractionOrder(player: Player, playerData: PlayerData): MutableList<Target>?

    fun getOrigin(player: Player, playerData: PlayerData): BlockVector3? {
        val clicks: MutableList<ClickData> = playerData.clicks
        if (clicks.isEmpty()) {
            return null
        }
        return clicks.first().location
    }

    fun putBlock(
        clientPackage: MutableList<Pair<BlockVector3, WrappedBlockState>>,
        location: BlockVector3,
        blockData: WrappedBlockState,
        world: World,
        replaceAir: Boolean,
        replaceSolid: Boolean,
        replaceSoft: Boolean,
        replaceLiquid: Boolean
    ) {
        if (replaceAir && replaceSolid && replaceSoft && replaceLiquid) { //just put the thing in there
            val row = Pair(location, blockData)
            clientPackage.add(row)
            return
        }
        val block = world.getBlockAt(location.x(), location.y(), location.z())
        if (Mediator.isEmpty(block)) {
            if (replaceAir) {
                val row = Pair(location, blockData)
                clientPackage.add(row)
            }
        } else if (Mediator.isSolid(block)) {
            if (replaceSolid) {
                val row = Pair(location, blockData)
                clientPackage.add(row)
            }
        } else if (Mediator.isLiquid(block)) {
            if (replaceLiquid) {
                val row = Pair(location, blockData)
                clientPackage.add(row)
            }
        } else {
            if (replaceSoft) {
                val row = Pair(location, blockData)
                clientPackage.add(row)
            }
        }
    }

    fun putBlock(
        clientPackage: MutableSet<Pair<BlockVector3, WrappedBlockState>>,
        location: BlockVector3,
        blockData: WrappedBlockState,
        world: World,
        replaceAir: Boolean,
        replaceSolid: Boolean,
        replaceSoft: Boolean,
        replaceLiquid: Boolean
    ) {
        if (replaceAir && replaceSolid && replaceSoft && replaceLiquid) { //just put the thing in there
            val row = Pair(location, blockData)
            clientPackage.add(row)
            return
        }
        val block = world.getBlockAt(location.x(), location.y(), location.z())
        if (Mediator.isEmpty(block)) {
            if (replaceAir) {
                val row = Pair(location, blockData)
                clientPackage.add(row)
            }
        } else if (Mediator.isSolid(block)) {
            if (replaceSolid) {
                val row = Pair(location, blockData)
                clientPackage.add(row)
            }
        } else if (Mediator.isLiquid(block)) {
            if (replaceLiquid) {
                val row = Pair(location, blockData)
                clientPackage.add(row)
            }
        } else {
            if (replaceSoft) {
                val row = Pair(location, blockData)
                clientPackage.add(row)
            }
        }
    }

    companion object {

        fun getOrigin(player: Player, playerData: PlayerData): BlockVector3? {
            val clicks: MutableList<ClickData> = playerData.clicks
            if (clicks.isEmpty()) {
                return null
            }
            return clicks.firstOrNull()?.location
        }

        fun putBlock(
            clientPackage: MutableList<Pair<BlockVector3, WrappedBlockState>>,
            location: BlockVector3,
            blockData: WrappedBlockState,
            world: World,
            replaceAir: Boolean,
            replaceSolid: Boolean,
            replaceSoft: Boolean,
            replaceLiquid: Boolean
        ) {
            if (replaceAir && replaceSolid && replaceSoft && replaceLiquid) { //just put the thing in there
                val row = Pair(location, blockData)
                clientPackage.add(row)
                return
            }
            val block = world.getBlockAt(location.x(), location.y(), location.z())
            if (Mediator.isEmpty(block)) {
                if (replaceAir) {
                    val row = Pair(location, blockData)
                    clientPackage.add(row)
                }
            } else if (Mediator.isSolid(block)) {
                if (replaceSolid) {
                    val row = Pair(location, blockData)
                    clientPackage.add(row)
                }
            } else if (Mediator.isLiquid(block)) {
                if (replaceLiquid) {
                    val row = Pair(location, blockData)
                    clientPackage.add(row)
                }
            } else {
                if (replaceSoft) {
                    val row = Pair(location, blockData)
                    clientPackage.add(row)
                }
            }
        }

    }

}