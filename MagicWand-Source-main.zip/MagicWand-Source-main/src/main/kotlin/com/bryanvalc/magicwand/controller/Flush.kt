package com.bryanvalc.magicwand.controller

import com.bryanvalc.magicwand.controller.ItemRemover.removeItems
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.PluginRepository
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.GameMode
import org.bukkit.entity.Player
import org.bukkit.event.block.Action
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

object Flush: KoinComponent {

    private val plugin: JavaPlugin by inject()
    private val pluginRepository: PluginRepository by inject()

    fun placeBlocks(
        player: Player,
        playerData: PlayerData,
        newBlocks: List<Pair<BlockVector3, WrappedBlockState>>
    ) {


        if (player.gameMode == GameMode.SURVIVAL) {
            val action = playerData.action
            if(action==null) return
            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
                if (player.hasPermission("${plugin.name.lowercase()}.survival.break")) {
                    // maybe give items?? kinda broken though but who cares if they want to monetize this
                } else {
                    return
                }
            } else {
                if (player.hasPermission("${plugin.name.lowercase()}.survival.place")) {
                    if (!removeItems(player, newBlocks)) {
                        return
                    }
                } else {
                    return
                }
            }
        }

        //        List<Pair<BlockVector3, WrappedBlockState>> newBlocks = dataManager.getNewBlocks(uuid);
        playerData.placedNow = playerData.placedNow + newBlocks.size // rate limit

        if(pluginRepository.faweEnabled) {
            FAWEPlace.place(player,newBlocks)
        } else {
            WEPlace.place(player,newBlocks)
        }


    }

}