package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.fakeToBlockPoint
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.Distance
import com.bryanvalc.magicwand.utils.Coloring
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.Vector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*
import java.util.function.Consumer
import kotlin.collections.MutableList
import kotlin.math.ceil
import kotlin.math.sqrt

class FreeCircle : Mode(), Multicolor, Scrollable {
    init {
        name = "freeCircle"
        permission = "mode.freecircle"
        materialMenu = Material.ENDER_PEARL
        premium = false
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/free-circle"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocationsTemp: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocationsTemp.add(click.location)
        }

        if (clickLocationsTemp.size == 1 || clickLocationsTemp.size == 2) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocationsTemp.add(pivot)
            }
        }

        if (clickLocationsTemp.isEmpty()) {
            return null
        }


        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>(clickLocationsTemp)
        clickLocations.forEach(Consumer { blockVector3: BlockVector3 ->
            blockVector3.add(
                BlockVector3.at(
                    0.5,
                    0.5,
                    0.5
                )
            )
        })


        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        if (clickLocations.size == 1) {
            val location = clickLocations[0]
            putBlock(shape, location, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
        } else if (clickLocations.size >= 2) {
            drawFilledCircle(player, shape, clickLocations, blockData, playerData)
        }

        return shape
    }

    private fun drawFilledCircle(
        player: Player,
        shape: MutableList<Pair<BlockVector3, WrappedBlockState>>,
        points: List<BlockVector3>,
        blockData: WrappedBlockState,
        playerData: PlayerData
    ) {
        val center: Vector3
        val radius: Double

        if (points.size == 2) {
            center = calculateMidpoint(points[0], points[1])
            radius = calculateRadius(center, points[0])
        } else {
            center = calculateCircumcenter(points[0], points[1], points[2])
            radius = calculateRadius(center, points[0])
        }

        val normal = calculateNormal(points)
        val u = normal.cross(Vector3.at(0.0, 1.0, 0.0)).normalize()
        val v = normal.cross(u)

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        val intRadius = ceil(radius).toInt()
        for (x in -intRadius..intRadius) {
            val maxY = sqrt(radius * radius - x * x).toInt()
            var y = -maxY.toDouble()
            while (y <= maxY) {
                val point = center.add(u.multiply(x.toDouble())).add(v.multiply(y))
                val blockPoint = point.fakeToBlockPoint()
                putBlock(shape, blockPoint, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
                y += 0.5
            }
        }
    }

    private fun calculateMidpoint(p1: BlockVector3, p2: BlockVector3): Vector3 {
        return Vector3.at(
            (p1.x() + p2.x()) / 2.0,
            (p1.y() + p2.y()) / 2.0,
            (p1.z() + p2.z()) / 2.0
        )
    }

    private fun calculateCircumcenter(p1: BlockVector3, p2: BlockVector3, p3: BlockVector3): Vector3 {
        val v1 = toVector3(p2).subtract(toVector3(p1))
        val v2 = toVector3(p3).subtract(toVector3(p1))

        val normalVector = v1.cross(v2).normalize()

        val midpoint1 = calculateMidpoint(p1, p2)
        val midpoint2 = calculateMidpoint(p1, p3)

        val perpendicular1 = normalVector.cross(v1)
        val perpendicular2 = normalVector.cross(v2)

        val tNumerator = midpoint2.subtract(midpoint1).cross(perpendicular2)
        val tDenominator = perpendicular1.cross(perpendicular2)

        val t = tNumerator.length() / tDenominator.length()

        return midpoint1.add(perpendicular1.multiply(t))
    }

    private fun toVector3(blockVector: BlockVector3): Vector3 {
        return Vector3.at(blockVector.x().toDouble(), blockVector.y().toDouble(), blockVector.z().toDouble())
    }

    private fun calculateRadius(center: Vector3, point: BlockVector3): Double {
        return center.distance(toVector3(point))
    }

    private fun calculateNormal(points: List<BlockVector3>): Vector3 {
        return if (points.size < 3) {
            val v1 = toVector3(points[1]).subtract(toVector3(points[0]))
            var v2 = v1.cross(Vector3.at(0.0, 1.0, 0.0))
            if (v2.lengthSq() == 0.0) {
                v2 = v1.cross(Vector3.at(1.0, 0.0, 0.0))
            }
            v1.cross(v2).normalize()
        } else {
            val v1 = toVector3(points[1]).subtract(toVector3(points[0]))
            val v2 = toVector3(points[2]).subtract(toVector3(points[0]))
            v1.cross(v2).normalize()
        }
    }

    override fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        return Coloring.falloffGradient(originalMesh, player, playerData)
    }

    override fun handleScrollUp(player: Player, playerData: PlayerData) {

        var currentOffset = playerData.offset
        if (currentOffset.isNaN()) return
        currentOffset += 2.0
        playerData.offset = currentOffset
    }

    override fun handleScrollDown(player: Player, playerData: PlayerData) {

        var currentOffset = playerData.offset
        if (currentOffset.isNaN()) return
        currentOffset -= 2.0
        playerData.offset = currentOffset
    }

    override fun getScrollTip(player: Player, playerData: PlayerData): Component? {
        val text =
            "<gray> distance: <white>" + playerData.offset + "<gray>, <white>scroll ▲<gray> to push, <white>scroll ▼<gray> to pull"
        return MiniMessage.miniMessage().deserialize(text)
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList(listOf(Block(), Distance(), Distance()))
    }

}