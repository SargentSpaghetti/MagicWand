package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.commands.ModesCommand.Companion.favorite
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.ModeManager
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission
import java.util.UUID

class BrushOptions: KoinComponent {

    val plugin: JavaPlugin by inject()
    val players: MutableMap<UUID, PlayerData> by inject()
    val modeManager: ModeManager by inject()

    @Command("brushoptions", "bo")
    @CommandPermission("magicwand.brushoptions")
    fun options(
        actor: BukkitCommandActor,
        brush: Configurable
    ){
        val sender = actor.sender()
        if (sender !is Player) {
            return
        }
        val player = sender as Player

        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()


        var nextMode = brush

        if(nextMode == null) return

        if(nextMode is Configurable) {
            player.playSound(player.eyeLocation, favorite, 1f, 1f)

            val menu = nextMode.forPlayer(playerData)
            menu?.render(player)
        }

    }
}