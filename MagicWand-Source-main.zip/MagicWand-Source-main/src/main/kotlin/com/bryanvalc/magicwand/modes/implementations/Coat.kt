package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.removeTailingClick
import com.bryanvalc.magicwand.context.BlockVectorUtils.equalsByTolerance
import com.bryanvalc.magicwand.context.fakeToBlockPoint
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.MultiLines
import com.bryanvalc.magicwand.utils.Coloring
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.Vector3
import com.sk89q.worldedit.math.interpolation.KochanekBartelsInterpolation
import com.sk89q.worldedit.math.interpolation.Node
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.entity.Player
import java.lang.Double
import java.util.*
import java.util.stream.Collectors

class Coat : Mode(), Multicolor, Scrollable{

    init {
        name = "coat"
        permission = "mode.coat"
        materialMenu = Material.KELP
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/coat"
    }

    //something veri IMPORTANT to notice, first gotta work with objects to avoid duplicity, then with reference
    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {
        var clicks: MutableList<ClickData> = playerData.clicks

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val pivot = playerData.pivot
        if(pivot!=null){
            clickLocations.add(pivot)
        }

        val shape: MutableSet<Pair<BlockVector3, WrappedBlockState>> =
            ObjectOpenHashSet<Pair<BlockVector3, WrappedBlockState>>(16 + ((playerData.newBlocks.size * 1.25).toInt()))

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        val blockData = playerData.blockData
        if(blockData == null) return null
        if (clickLocations.size == 1) {
            val location = clickLocations.firstOrNull()
            if(location==null) return null
            //            shape.add(new Pair<>(location, blockData));
            putBlock(
                shape,
                location,
                blockData,
                player.world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )
        } else if (clickLocations.size >= 2) {
            clicks = removeTailingClick(clicks, 3)

            val clicksPerIndex = clicks.stream().collect(Collectors.groupingBy(ClickData::interactionSubIndex))
            val locationsPerIndex: MutableMap<Int, MutableList<BlockVector3>> =
                HashMap<Int, MutableList<BlockVector3>>()

            val subIndex = playerData.targetSubIndex

            for (entry in clicksPerIndex.entries) {
                if (entry.key != subIndex) {
                    entry.value.removeLast()
                }

                val temporalList: MutableList<BlockVector3> = ArrayList<BlockVector3>()
                for (clickData in entry.value) {
                    temporalList.add(clickData.location)
                }
                if(entry.key%2!=0){
                    temporalList.reverse()
                }
                locationsPerIndex.put(entry.key, temporalList)
            }
            val lastClick = clicks.lastOrNull()
            if(lastClick ==null) return null
            try { // I don't know what the actual fuck is going on here
                if (pivot!=null && !equalsByTolerance(pivot, lastClick.location, 3.0)) {

                    if(playerData.targetSubIndex%2!=0) {
                        locationsPerIndex[playerData.targetSubIndex]!!.addFirst(pivot)
                    } else {
                        locationsPerIndex[playerData.targetSubIndex]!!.add(pivot)
                    }

                }
            } catch (_: Exception) {
                if (pivot!=null && !equalsByTolerance(pivot, lastClick.location, 3.0)) {
                    val pivotLocation: MutableList<BlockVector3> = ArrayList<BlockVector3>()
                    pivotLocation.add(pivot)
                    locationsPerIndex.put(playerData.targetSubIndex, pivotLocation)
                }
            }

            var curvesResolution = 50.0 //cannot be zero, gotta make sure it isn't zero so below it doesn't infinite loop
            var previousLoc: BlockVector3? = null

            val firstLine = locationsPerIndex[0]
            if(firstLine!=null){
                for (clickData in firstLine) {
                    if (previousLoc == null) {
                        previousLoc = clickData
                        curvesResolution += previousLoc.distance(pivot)
                    } else {
                        curvesResolution += clickData.distance(previousLoc)
                    }
                }
            }
            curvesResolution = 0.75 / curvesResolution // give some more allowance

            val pointLists: MutableList<MutableList<Vector3>> = ObjectArrayList<MutableList<Vector3>>()


            for (entry in locationsPerIndex.entries) {
                val nodeGroup: MutableList<Node> = ObjectArrayList<Node>()

                for (block in entry.value) {
                    val vector = Vector3.at(block.x() + 0.5, block.y() + 0.5, block.z() + 0.5)
                    val newNode = Node(vector)
                    newNode.tension = -1.0
                    nodeGroup.add(newNode)
                }
                if (nodeGroup.isEmpty()) { //maybe not
                    return null
                }

                nodeGroup.firstOrNull()?.tension = 0.0
                nodeGroup.lastOrNull()?.tension = 0.0
                val interpolation = KochanekBartelsInterpolation()
                interpolation.setNodes(nodeGroup)

                val temporalList: MutableList<Vector3> = ObjectArrayList<Vector3>()
                var i = 0.0
                while (i < 1) {
                    val floatingPoint = interpolation.getPosition(i)
                    temporalList.add(floatingPoint)
                    i += curvesResolution
                }
                pointLists.add(temporalList)
            }

            val finalPrediction: MutableList<BlockVector3> = ObjectArrayList<BlockVector3>()
            var j = 0
            val pointListFirst = pointLists.firstOrNull()
            if(pointListFirst==null) return null

            while (j < pointListFirst.size) {
                val nodeGroup: MutableList<Node> = ObjectArrayList<Node>()
                var i = 0
                while (i < pointLists.size) {
                    val point = pointLists[i][j]
                    val node = Node(point)
                    node.tension = -1.0
                    nodeGroup.add(node)
                    i += 1
                }
                nodeGroup.firstOrNull()?.tension = 0.0
                nodeGroup.lastOrNull()?.tension = 0.0

                val interpolation = KochanekBartelsInterpolation()
                interpolation.setNodes(nodeGroup)
                var k = 0.0
                while (k < 1) {
                    val floatingPoint = interpolation.getPosition(k)
//                    finalPrediction.add(floatingPoint.toBlockPoint())
                    putBlock(shape, floatingPoint.fakeToBlockPoint(), blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
                    k += (curvesResolution/2)
                }

                j += 1
            }

//            for (block in finalPrediction) {
//                putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
//            }
        }

        return ReferenceArrayList<Pair<BlockVector3, WrappedBlockState>>(shape)
    }

    override fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        return Coloring.falloffGradient(originalMesh, player, playerData)
    }

    override fun handleScrollUp(player: Player, playerData: PlayerData) {
        var currentOffset = playerData.offset
        if (Double.isNaN(currentOffset)) return
        currentOffset += 2.0
        playerData.offset = currentOffset
    }

    override fun handleScrollDown(player: Player, playerData: PlayerData) {
        var currentOffset = playerData.offset
        if (Double.isNaN(currentOffset)) return
        currentOffset -= 2.0
        playerData.offset = currentOffset
    }

    override fun getScrollTip(player: Player, playerData: PlayerData): Component? {
        val text =
            "<gray> distance: <white>" + playerData.offset + "<gray>, <white>scroll ▲<gray> to push, <white>scroll ▼<gray> to pull"
        return MiniMessage.miniMessage().deserialize(text)
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList<Target>(listOf<Target>(Block(), MultiLines()))
    }
}