package com.bryanvalc.magicwand.events

import com.bryanvalc.magicwand.context.Display.draw
import com.bryanvalc.magicwand.context.Display.reset
import com.bryanvalc.magicwand.context.Display.sendRealBlocks
import com.bryanvalc.magicwand.context.PlayerUtils.serveBlockData
import com.bryanvalc.magicwand.context.overlay.RenderTip
import com.bryanvalc.magicwand.controller.Flush
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.data.modifier.Modifier
import com.bryanvalc.magicwand.modes.AutoSwitch
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.ModeManager
import com.bryanvalc.magicwand.module.locales.LangManager
import com.bryanvalc.magicwand.modes.PreOperation
import com.bryanvalc.magicwand.module.KtPlugin
import com.bryanvalc.magicwand.targets.DynamicTarget
import com.bryanvalc.magicwand.targets.DynamicTarget.Companion.recursivelySolveTarget
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import com.bryanvalc.magicwand.utils.ModifierParser
import com.bryanvalc.magicwand.utils.platform.Mediator
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.github.shynixn.mccoroutine.bukkit.asyncDispatcher
import com.github.shynixn.mccoroutine.bukkit.launch
import com.github.shynixn.mccoroutine.bukkit.minecraftDispatcher
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import kotlinx.coroutines.delay
import net.kyori.adventure.text.Component
import org.bukkit.FluidCollisionMode
import org.bukkit.Material
import org.bukkit.Sound
import org.bukkit.event.EventHandler
import org.bukkit.event.EventPriority
import org.bukkit.event.Listener
import org.bukkit.event.block.Action
import org.bukkit.event.player.PlayerInteractEvent
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

class PlayerInteract : Listener, KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()
    private val plugin: JavaPlugin by inject()
    private val langManager: LangManager by inject()
    private val modeManager: ModeManager by inject()
    private val ktPlugin: KtPlugin by inject()

    @EventHandler(priority = EventPriority.HIGH)
    fun onPlayerInteract(event: PlayerInteractEvent) {
        // updates clicks based on pivot, index, and current target, resolves next target,
        // updates target index if solved, flush blocks when on final target and solved
        val action = event.action
        if (!((action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) || (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK))) return

        val player = event.player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return

        val playerData =
            playerDataOriginal.clone() //avoid concurrentModification, work with local snapshot, then replace in hashmap

        // faulty mouses fix
        if (System.currentTimeMillis() - playerData.lastInteraction < 100) return
        playerData.lastInteraction = System.currentTimeMillis()

        val mode = playerData.mode
        if (mode == null) { return }

        val itemStack = player.inventory.itemInMainHand //Change modifier and flush it

        if(playerData.brushMode&&(action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK)) return // for brush mode
        if(playerData.brushMode&&itemStack.type!= Material.NETHER_STAR) { return }

        val languagePack = player.getLanguagePack()

        if (playerData.placingLimit!=-1L && playerData.hasReachedPlacingLimit()) {
            player.sendMessage(languagePack?.quota ?: "Your quota has been exceeded")
            reset(player, playerData)
            val message: Component? = playerData.setMode(null)
            if(message!=null){
                Mediator.sendActionBar(player, message)
            }
            return  // rate limit
        }

        val clicks = playerData.clicks

        //tryUndoClick
        if (clicks.isNotEmpty()) { //only if clicks is null or are empty, we don't want to lock the type of clicks forever
            var clickDataToRestore: ClickData? = null
            when (playerData.action) {
                Action.LEFT_CLICK_BLOCK, Action.LEFT_CLICK_AIR -> if ((action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK)) {
                    clickDataToRestore = clicks.removeLast()
                }

                Action.RIGHT_CLICK_BLOCK, Action.RIGHT_CLICK_AIR -> if ((action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK)) {
                    clickDataToRestore = clicks.removeLast()
                }

                Action.PHYSICAL -> {}
                null -> {}
            }

            if (clickDataToRestore != null) {

                if (playerData.chatFeedback) {
                    player.sendParsed((languagePack?.positionRemoved ?: "Pos #<position> removed.")
                        .replace("<position>", ""+(clicks.size+1))
                    )
                }

                sendRealBlocks(player, playerData)
                playerData.targetIndex = clickDataToRestore.interactionIndex
                playerData.targetSubIndex = clickDataToRestore.interactionSubIndex
                playerData.floatingTarget = clickDataToRestore.target
                playerData.originalBlocks.clear()
                playerData.newBlocks.clear()
                playerData
                players[uuid] = playerData
                return  //stop doing more stuff, so no other clicks are added neither targets resolved
            }
        } else {
            playerData.action = action //first click
            val rayTraceResult = player.rayTraceBlocks(500.0, FluidCollisionMode.NEVER)
            val blockData = serveBlockData(player, rayTraceResult, playerData)

            if (blockData==null) return

            val sound = blockData.soundGroup.placeSound
            playerData.sound = sound
            val wrapped = SpigotConversionUtil.fromBukkitBlockData(blockData)
            playerData.blockData = wrapped
        }

        if ((action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK)) {
            val rt = player.rayTraceBlocks(playerData.reach.toDouble(), FluidCollisionMode.NEVER)
            if (rt != null) {
                val hitBlock = rt.hitBlock
                if(hitBlock!=null){
                    val sound = hitBlock.blockData.soundGroup.breakSound
                    playerData.sound = sound
                }

            }
        }

        val modifier: Modifier? = ModifierParser.loadFromItem(itemStack)
        if (modifier != null) {
            val preChange = modifier.display()
            modifier.handleInteraction(event, playerData)
            val postChange = modifier.display()

            if(preChange!=null){
                Mediator.sendActionBar(player, preChange)
            }
            Mediator.playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP)
            if(postChange!=null){
                plugin.launch(context = plugin.asyncDispatcher) {
                    delay(500L)

                    Mediator.sendActionBar(player, postChange)

                }
            }

            ModifierParser.saveToItem(itemStack, modifier)
            return
        }

        val interactionOrder = mode.getInteractionOrder(player, playerData)
        if(interactionOrder==null) return

        var floatingTarget = playerData.floatingTarget
        if (floatingTarget == null) {
            playerData.targetIndex = 0

            val initialTarget = interactionOrder.firstOrNull()
            if(initialTarget==null) return

            var newFloatingTarget = if (initialTarget is DynamicTarget) {
                recursivelySolveTarget(initialTarget, player, playerData)
            } else {
                initialTarget
            }
            playerData.floatingTarget = newFloatingTarget
            floatingTarget = newFloatingTarget
        }

        val newClick = ClickData(player, playerData)


        if (playerData.chatFeedback && interactionOrder.size != 1) {
            player.sendParsed((languagePack?.positionSet ?: "Pos #<position>: <location>.")
                .replace("<position>", "${clicks.size+1}")
                .replace("<location>", "(${newClick.location.x()}, ${newClick.location.y()}, ${newClick.location.z()})")
            )
        }

        clicks.add(newClick)

        //play sound
        val sound = playerData.sound
        if(sound!=null){
            val rt5 = player.rayTraceBlocks(5.0, FluidCollisionMode.NEVER)

            if(rt5==null || rt5.hitBlock==null || itemStack.type== Material.NETHER_STAR){
                Mediator.playSound(player, sound)
            }
        }


        if (floatingTarget.isResolved(player, playerData)) {
            var targetIndex = playerData.targetIndex

            if (targetIndex >= interactionOrder.size - 1) { //flushes blocks and sets index to 0

                val finalTargetIndex = AtomicInteger(targetIndex)
                plugin.launch(context = plugin.minecraftDispatcher) {
                    val mode1 = playerData.mode
                    try {
                        val newBlocks: List<Pair<BlockVector3, WrappedBlockState>>? =
                            draw(player, playerData) //MAKE ABSOLUTE
                        if (mode1 is PreOperation) {
                            (mode1 as PreOperation).exec(player, playerData)
                        }
                        if (newBlocks != null) {
                            Flush.placeBlocks(player, playerData, newBlocks)
                        }
                    } catch (t: Throwable) {
                        // If a mode throws (e.g., reflection/NBT incompatibilities), it can leave the
                        // preview state half-updated. Always hard-reset so the player doesn't get stuck
                        // with invisible previews until relog.
                        plugin.logger.severe("[MagicWand] Mode execution failed (${mode1?.name ?: "unknown"}) for ${player.name}: ${t.message}")
                        t.printStackTrace()

                        playerData.clicks = mutableListOf()
                        playerData.offset = Double.NaN
                        playerData.clearTargetSubIndex()
                        playerData.targetIndex = 0
                        playerData.floatingTarget = null
                        reset(player, playerData)
                        return@launch
                    }

                    val newClicks: List<ClickData> = ArrayList<ClickData>() // has to be synchronized
                    playerData.clicks = newClicks.toMutableList()

                    // want to do it in a synchronized manner to avoid weird stuff from happening
                    finalTargetIndex.set(0)
                    playerData.offset = Double.Companion.NaN // only after placing
                    playerData.clearTargetSubIndex()
                    playerData.targetIndex = finalTargetIndex.get() // solves or appends the target for the new index
                    val nextTarget = interactionOrder[finalTargetIndex.get()]
                    var newNextTarget = if (nextTarget is DynamicTarget) {
                        recursivelySolveTarget(nextTarget, player, playerData)
                    } else {
                        nextTarget
                    }
                    playerData.floatingTarget = newNextTarget
                    reset(player, playerData)

                    if(mode1 is AutoSwitch) {
                        val nextModeName = mode1.switch()
                        val nextMode =  modeManager.getFromName(nextModeName)
                        val message = playerData.setMode(nextMode)
                        if(message==null){
                            player.sendParsed(ktPlugin.premiumMessage)
                        } else {
                            Mediator.sendActionBar(player, message)
                            nextMode?.let {

                                var optionsMessage = "${it.name}: <#8968d3><u><a:${it.wiki}><bold>wiki</bold></a></u> "
                                if (nextMode is Configurable) {
                                    optionsMessage+= "<hover:show_text:'Change ${it.name} options'><u><click:run_command:'/brushoptions ${(it.name).replace(" ", "_")}'><#8d4ca9><bold>options</bold>"
                                }
                                player.sendParsed(optionsMessage)
                            }

                            if(nextMode != null) {
                                var model = 1
                                val modes = modeManager.modes
                                val toAdd = modes.indexOf(nextMode)+1
                                model+=toAdd

                                val item = player.inventory.itemInMainHand
                                if(item.type == Material.NETHER_STAR) {
                                    var meta = item.itemMeta
                                    Mediator.displayName(meta, nextMode.name)
                                    meta.setCustomModelData(model)
                                    item.itemMeta = meta
                                }
                            }

                        }
                    }

                    players[uuid] = playerData // thread safe hashmap, put local snapshot in global space
                }

                //                targetIndex = 0; //not setting it to null might break stuff, not sure
//                dataManager.setPivot(uuid, null);
            } else { // or just increments index
                targetIndex += 1

                playerData.targetIndex = targetIndex // solves or appends the target for the new index
                val nextTarget = interactionOrder[targetIndex]
                var newNextTarget = if (nextTarget is DynamicTarget) {
                    recursivelySolveTarget(nextTarget, player, playerData)
                } else {
                    nextTarget
                }
                playerData.floatingTarget = newNextTarget

                if(playerData.tutorial){
                    val hologramTip = newNextTarget.hologramTip(player, playerData)
                    if(hologramTip!=null){
                        RenderTip.forPlayer(hologramTip, player, playerData)
                    }
                }
                players[uuid] = playerData
            }
        } else {
            players[uuid] = playerData
        }
    }
}