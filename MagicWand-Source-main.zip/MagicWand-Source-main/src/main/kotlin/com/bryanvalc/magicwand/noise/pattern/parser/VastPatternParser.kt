package com.bryanvalc.magicwand.noise.pattern.parser

import com.bryanvalc.magicwand.noise.pattern.impl.VastNoiseGenerator
import com.fastasyncworldedit.core.extension.factory.parser.pattern.NoisePatternParser
import com.sk89q.worldedit.WorldEdit
import java.util.function.Supplier

class VastPatternParser
    (worldEdit: WorldEdit?) : NoisePatternParser(
    worldEdit,
    "vast",
    Supplier { VastNoiseGenerator() }) {
}