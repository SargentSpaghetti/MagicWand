package com.bryanvalc.magicwand.targets

import com.bryanvalc.magicwand.data.PlayerData
import org.bukkit.entity.Player

abstract class DynamicTarget : Target() {
    abstract fun nextTarget(player: Player, playerData: PlayerData): Target

    companion object {
        fun recursivelySolveTarget(target: DynamicTarget, player: Player, playerData: PlayerData): Target {
            val nextTarget = target.nextTarget(player, playerData)

            return if (nextTarget is DynamicTarget) {
                recursivelySolveTarget(nextTarget, player, playerData)
            } else {
                nextTarget
            }
        }
    }
}