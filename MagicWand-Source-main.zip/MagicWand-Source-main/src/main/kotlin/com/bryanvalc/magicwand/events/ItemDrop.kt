package com.bryanvalc.magicwand.events

import com.bryanvalc.magicwand.context.Display.reset
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import org.bukkit.Material
import org.bukkit.event.EventHandler
import org.bukkit.event.EventPriority
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerDropItemEvent
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID


class ItemDrop : Listener, KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()

    @EventHandler(priority = EventPriority.LOWEST)
    fun onItemDrop(event: PlayerDropItemEvent) {
        val player = event.player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        val mode = playerData.mode
        if (mode == null) {
            return
        }

        if(playerData.brushMode){
            val itemStack = event.itemDrop.itemStack

            if(itemStack.type!= Material.NETHER_STAR) return
        }
        playerData.lastInteraction = System.currentTimeMillis()

        if(playerData.clicks.isNotEmpty()){
            event.isCancelled = true

            val languagePack = player.getLanguagePack()

            if (playerData.chatFeedback) {
                player.sendParsed(languagePack?.positionsCleared ?: "Positions cleared.")
            }
        }

        reset(player, playerData)
        players[uuid] = playerData

    }
}