package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.Distance
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.entity.Player
import java.lang.Double
import java.util.*
import java.util.function.ToDoubleFunction
import java.util.stream.Collectors
import com.bryanvalc.magicwand.context.BlockVectorUtils
import com.bryanvalc.magicwand.context.effects.Hull
import com.bryanvalc.magicwand.context.fakeEquals
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable

class Bucketfill : Mode(), Scrollable, Configurable {
    init {
        name = "bucketFill"
        permission = "mode.bucketfill"
        materialMenu = Material.MELON_SLICE
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/bucketfill"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {
        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return mutableListOf<Pair<BlockVector3, WrappedBlockState>>()

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        if (clickLocations.size == 1) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocations.add(pivot)
            }
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        var shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData

        if(blockData==null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        if (clickLocations.size == 1) {
            val location: BlockVector3 = clickLocations[0]
            putBlock(shape, location, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
            return shape
        } else {
            val firstBlock = clickLocations.firstOrNull()
            val lastBlock = clickLocations.lastOrNull()
            if(firstBlock==null || lastBlock==null) return null

            val middlePoint = firstBlock.add(lastBlock).divide(2)

            val radius = firstBlock.distance(middlePoint).toInt()
            val cleanSphere: MutableList<BlockVector3> = ObjectArrayList(BlockVectorUtils.getCleanSphereBlock(world, radius))

            val eyeLocation = player.eyeLocation
            val playerPos = BlockVector3.at(eyeLocation.x, eyeLocation.y, eyeLocation.z)
            val otherPivot = middlePoint.subtract(playerPos.subtract(middlePoint))

            val buffer: MutableList<BlockVector3> = ObjectArrayList(cleanSphere.size)
            for (block in cleanSphere) {
                buffer.add(block.add(middlePoint))
            }

            val eval = listOf<BlockVector3>(playerPos, otherPivot)

            for (block in buffer) { //assign to nearest click
                val chosen: BlockVector3 = eval.stream()
                    .sorted(
                        Comparator.comparingDouble(
                            ToDoubleFunction { c: BlockVector3 -> c.distance(block) }
                        ))
                    .collect(Collectors.toList())
                    .first()
                if (chosen.fakeEquals(otherPivot)) {
                    shape.add(Pair(block, blockData))
                }
            }

            val menu = forPlayer(playerData)
            val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"

            when(filling) {
                "hollow" -> {
                    shape = Hull(6,6).apply(shape)
                }
                else -> {}
            }

            val shapeFinal: MutableList<Pair<BlockVector3, WrappedBlockState>> =
                ReferenceArrayList(shape.size)

            for(block in shape) {
                putBlock(
                    shapeFinal,
                    block.first,
                    blockData,
                    world,
                    replaceAir,
                    replaceSolid,
                    replaceSoft,
                    replaceLiquid
                )
            }
            return shapeFinal
        }
    }

    override fun handleScrollUp(player: Player, playerData: PlayerData) {
        var currentOffset = playerData.offset
        if (Double.isNaN(currentOffset)) return
        currentOffset += 2.0
        playerData.offset = currentOffset
    }

    override fun handleScrollDown(player: Player, playerData: PlayerData) {
        var currentOffset = playerData.offset
        if (Double.isNaN(currentOffset)) return
        currentOffset -= 2.0
        playerData.offset = currentOffset
    }

    override fun getScrollTip(player: Player, playerData: PlayerData): Component? {
        val text =
            "<gray> distance: <white>" + playerData.offset + "<gray>, <white>scroll ▲<gray> to push, <white>scroll ▼<gray> to pull"
        return MiniMessage.miniMessage().deserialize(text)
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = null,
                    value = "full", options = listOf("full", "hollow"),
                    models = mapOf(
                        "full" to 1,
                        "hollow" to 3
                    )
                )
            ),
            3
        )
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList<Target>(listOf<Target>(Block(), Distance()))
    }
}