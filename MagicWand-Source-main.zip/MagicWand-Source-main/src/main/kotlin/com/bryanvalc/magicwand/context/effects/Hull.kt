package com.bryanvalc.magicwand.context.effects

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet

class Hull(val minFaces: Int, val maxFaces: Int, var directions: List<BlockVector3> = listOf<BlockVector3>(
    BlockVector3.at(1, 0, 0),
    BlockVector3.at(-1, 0, 0),
    BlockVector3.at(0, 1, 0),
    BlockVector3.at(0, -1, 0),
    BlockVector3.at(0, 0, 1),
    BlockVector3.at(0, 0, -1)
)): Effect {


    override fun apply(original: List<Pair<BlockVector3, WrappedBlockState>>): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        var allPositions = ObjectOpenHashSet<BlockVector3>(original.size)

        for(row in original) {
            allPositions.add(row.first)
        }

        var retList = ObjectArrayList<Pair<BlockVector3, WrappedBlockState>>(original.size)
        for(row in original) {
            var faces = 0
            for(direction in directions) {
                if(allPositions.contains(row.first.add(direction))) { faces+=1}
            }
            if (!(faces >= minFaces && faces <= maxFaces)) {
                retList.add(row)
            }
        }

        return retList
    }
}