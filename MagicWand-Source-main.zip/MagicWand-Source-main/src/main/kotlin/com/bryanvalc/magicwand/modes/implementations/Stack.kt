package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.boundingBox
import com.bryanvalc.magicwand.context.BlockVectorUtils.bresenham3D
import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.anyWithinBounds
import com.bryanvalc.magicwand.context.effects.Offset
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.BooleanProperty
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.Distance
import com.bryanvalc.magicwand.targets.implementations.ExtendAny
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*

class Stack : Mode(), Configurable {
    init {
        name = "stack"
        permission = "mode.stack"
        materialMenu = Material.NETHERITE_SCRAP
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/stack"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        val pivot = playerData.pivot
        if(pivot!=null && clickLocations.size!=3){
            clickLocations.add(pivot)
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        val menu = forPlayer(playerData)
        val previewOnlyAir = (menu?.propertyByName("preview") as BooleanProperty?)?.value != false
        val method = (menu?.propertyByName("method") as EnumProperty?)?.value?:"constant.box"
        val excludeAir = (menu?.propertyByName("exclude.air") as BooleanProperty?)?.value != false

        val shape = ReferenceArrayList<Pair<BlockVector3, WrappedBlockState>>(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        if (clickLocations.size <= 2) {
            val newCubeMin: BlockVector3 = minBlockVector(*clickLocations.toTypedArray<BlockVector3>())
            val newCubeMax: BlockVector3 = maxBlockVector(*clickLocations.toTypedArray<BlockVector3>())

            val minX = newCubeMin.x()
            val minY = newCubeMin.y()
            val minZ = newCubeMin.z()
            val maxX = newCubeMax.x()
            val maxY = newCubeMax.y()
            val maxZ = newCubeMax.z()

            // TODO: not a single case is special, but should do for now
            val wrappedBlockState = SpigotConversionUtil.fromBukkitBlockData(Material.BLUE_STAINED_GLASS.createBlockData())

            for (x in minX..maxX) {
                for (y in minY..maxY) {
                    for (z in minZ..maxZ) {
                        if (previewOnlyAir) {
                            if(world.getBlockData(x, y, z).material.isAir) {
                                putBlock(shape, BlockVector3.at(x, y, z), wrappedBlockState, world, true, true, true, true)
                            }
                        } else {
                            putBlock(shape, BlockVector3.at(x, y, z), wrappedBlockState, world, true, true, true, true)
                        }
                    }
                }
            }
        } else if (clickLocations.size == 3) {
            val locationsCopy: MutableList<BlockVector3> = ArrayList<BlockVector3>(clickLocations)
            val lastClick = locationsCopy.removeLast()
            val newCubeMin: BlockVector3 = minBlockVector(*locationsCopy.toTypedArray<BlockVector3>())
            val newCubeMax: BlockVector3 = maxBlockVector(*locationsCopy.toTypedArray<BlockVector3>())

            val minX = newCubeMin.x()
            val minY = newCubeMin.y()
            val minZ = newCubeMin.z()
            val maxX = newCubeMax.x()
            val maxY = newCubeMax.y()
            val maxZ = newCubeMax.z()

            val baseShape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
                ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))

            for (x in minX..maxX) {
                for (y in minY..maxY) {
                    for (z in minZ..maxZ) {
                        val blockData =  world.getBlockData(x, y, z)
                        val wrapped = SpigotConversionUtil.fromBukkitBlockData(blockData)

                        if (excludeAir) {
                            if (!blockData.material.isAir) {
                                putBlock(baseShape, BlockVector3.at(x, y, z), wrapped, world, true, true, true, true)
                            }
                        } else {
                            putBlock(baseShape, BlockVector3.at(x, y, z), wrapped, world, true, true, true, true)
                        }

                    }
                }
            }

            val secondClick = locationsCopy.lastOrNull()
            if(secondClick == null) return null

            val positionsToTry = bresenham3D(secondClick, lastClick)

            var lastPivot: BlockVector3 = secondClick
            var previousFirst: BlockVector3 = newCubeMin
            var previousSecond: BlockVector3 = newCubeMax

            when(method) {
                "constant.box" -> {
                    for(position in positionsToTry) {
                        val offset = position.subtract(secondClick)
                        val first = newCubeMin.add(offset)
                        val second = newCubeMax.add(offset)

                        val box = boundingBox(previousFirst, previousSecond)
                        if(!anyWithinBounds(first, second, box)){
                            val subShape = Offset(offset).apply(baseShape)
                            previousFirst = first
                            previousSecond = second

                            for(newBlock in subShape) {
                                putBlock(shape, newBlock.first, newBlock.second, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
                            }

                        }

                    }
                }
                "reverse.smudge" -> {
                    for(position in positionsToTry) {
                        val offset = position.subtract(secondClick)
                        val subShape = Offset(offset).apply(baseShape)

                        for(newBlock in subShape) {
                            putBlock(shape, newBlock.first, newBlock.second, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
                        }
                    }
                }
                "smudge" -> {
                    for(position in positionsToTry.reversed()) {
                        val offset = position.subtract(secondClick)
                        val subShape = Offset(offset).apply(baseShape)

                        for(newBlock in subShape) {
                            putBlock(shape, newBlock.first, newBlock.second, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
                        }
                    }
                }
            }

        }

        val intermediateMap = Object2ObjectOpenHashMap<BlockVector3, WrappedBlockState>(shape.size)
        for (row in shape) {
            intermediateMap[row.first] = row.second
        }
        shape.clear()
        for(entry in intermediateMap.entries) {
            shape.add(Pair(entry.key, entry.value))
        }

        return shape
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                BooleanProperty(
                    row = 1, column = 1, name = "preview",
                    material = Material.ENDER_EYE,
                    lore = "preview.lore",
                    model = 1,
                    overrideDisplays = mapOf(
                        true to "only.air",
                        false to "all.blocks"
                    ),
                    models = mapOf(
                        true to 1,
                        false to 2
                    )
                ),
                EnumProperty(
                    row = 1, column = 3, name = "method",
                    material = Material.COMPARATOR,
                    lore = "method.lore",
                    model = null,
                    value = "constant.box", options = listOf("constant.box", "smudge", "reverse.smudge"), //, "avoid overlap", "fixed count", "fixed distance"
                    models = mapOf(
                        "constant.box" to 1,
                        "smudge" to 2,
                        "reverse.smudge" to 3
                    )
                )
                ,
                BooleanProperty(
                    row = 1, column = 5, name = "exclude.air",
                    material = Material.STRUCTURE_VOID,
                    lore = "exclude.air.lore",
                    model = null,
                    models = mapOf(
                        true to 1,
                        false to 2
                    )
                )
            ),
            3
        )
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList(listOf(Block(), Distance(), ExtendAny())) //ManyAxis
    }

}