package com.bryanvalc.magicwand.data.modifier

import com.bryanvalc.magicwand.context.PlayerUtils
import com.bryanvalc.magicwand.data.PlayerData
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.block.BlockFace
import org.bukkit.entity.Player
import org.bukkit.event.block.Action
import org.bukkit.event.player.PlayerInteractEvent

class ArrayModifier(var offsetX: Int, var offsetY: Int, var offsetZ: Int, var count: Int) : Modifier {
    override fun apply(
        originalShape: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {

        val newShape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ArrayList<Pair<BlockVector3, WrappedBlockState>>(count * originalShape.size)

        var i = 0
        while (i < count) {
            for (block in originalShape) {
                val originalVector: BlockVector3 = block.first
                val originalData: WrappedBlockState = block.second

                val newBlock = Pair<BlockVector3, WrappedBlockState>(
                    BlockVector3.at(
                        originalVector.x() + (i * offsetX),
                        originalVector.y() + (i * offsetY),
                        originalVector.z() + (i * offsetZ)
                    ),
                    originalData.clone()
                )
                newShape.add(newBlock)
            }

            i += 1
        }
        return newShape
    }

    override fun handleInteraction(event: PlayerInteractEvent, playerData: PlayerData) {
        val player = event.getPlayer()

        val facing: BlockFace? = PlayerUtils.getFacing(player)
        if (facing == null) {
            return
        }

        val action = event.getAction()

        when (action) {
            Action.LEFT_CLICK_BLOCK, Action.LEFT_CLICK_AIR -> when (facing) {
                BlockFace.UP -> this.offsetY += 1
                BlockFace.DOWN -> this.offsetY -= 1
                BlockFace.EAST -> this.offsetX += 1
                BlockFace.WEST -> this.offsetX -= 1
                BlockFace.SOUTH -> this.offsetZ += 1
                BlockFace.NORTH -> this.offsetZ -= 1
                else -> {}
            }

            Action.RIGHT_CLICK_BLOCK, Action.RIGHT_CLICK_AIR -> when (facing) {
                BlockFace.UP -> this.count += 1
                BlockFace.DOWN -> if (this.count >= 2) { //safety
                    this.count -= 1
                }

                else -> {}
            }

            Action.PHYSICAL -> {}
        }
    }

    override fun display(): Component? {
            val text = "<red>x:" + offsetX + " " +
                    "<green>y:" + offsetY + " " +
                    "<blue>z:" + offsetZ + " " +
                    "<gray> count: " + count +
                    "<gray>, <white>◀<gray> to move, <white>▶<gray> to increase"
            return MiniMessage.miniMessage().deserialize(text)
        }
}