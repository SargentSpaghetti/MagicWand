package com.bryanvalc.magicwand.data

data class PortableSchem(
    val playerFacing: String,
    val bin: ByteArray
)
