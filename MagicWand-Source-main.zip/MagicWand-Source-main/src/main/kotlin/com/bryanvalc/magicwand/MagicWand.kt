package com.bryanvalc.magicwand

import com.bryanvalc.magicwand.CustomMetrics.addCustomMetrics
import com.bryanvalc.magicwand.commands.*
import com.bryanvalc.magicwand.commands.parameter.ConfigurableType
import com.bryanvalc.magicwand.commands.parameter.MaterialListType
import com.bryanvalc.magicwand.commands.parameter.ModeType
import com.bryanvalc.magicwand.commands.regions.Antigravity
import com.bryanvalc.magicwand.commands.regions.PersistLeaves
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.events.*
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.ModeManager
import com.bryanvalc.magicwand.module.*
import com.bryanvalc.magicwand.module.storage.PlayerDao
import com.bryanvalc.magicwand.noise.Hook
import com.bryanvalc.magicwand.placeholders.Mode
import com.bryanvalc.magicwand.placeholders.Placing
import com.bryanvalc.magicwand.placeholders.Preview
import com.bryanvalc.magicwand.placeholders.Reset
import com.bryanvalc.magicwand.utils.UpdateChecker
import com.bryanvalc.magicwand.utils.platform.Mediator
import com.github.retrooper.packetevents.PacketEvents
import com.github.shynixn.mccoroutine.bukkit.ShutdownStrategy
import com.github.shynixn.mccoroutine.bukkit.launch
import com.github.shynixn.mccoroutine.bukkit.mcCoroutineConfiguration
import io.github.retrooper.packetevents.factory.spigot.SpigotPacketEventsBuilder
import kotlinx.coroutines.delay
import net.kyori.adventure.text.Component
import org.bstats.bukkit.Metrics
import org.bukkit.Bukkit
import org.bukkit.event.player.PlayerKickEvent
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import org.koin.core.context.startKoin
import org.koin.core.module.Module
import org.koin.dsl.module
import revxrsal.commands.Lamp
import revxrsal.commands.bukkit.BukkitLamp
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.zapper.ZapperJavaPlugin
import java.util.*


class MagicWand : ZapperJavaPlugin() , KoinComponent {

    private val loader: Loader by inject()
    private val license: License by inject()
    private val ktPlugin: KtPlugin by inject()
    private val players: MutableMap<UUID, PlayerData> by inject()
    private val modeManager: ModeManager by inject()
    private val materialRegistry: MaterialRegistry by inject()

    override fun onLoad() {
        PacketEvents.setAPI(SpigotPacketEventsBuilder.build(this))
        //On Bukkit, calling this here is essential, hence the name "load"
        PacketEvents.getAPI().load()
    }

    override fun onEnable() {

        PacketEvents.getAPI().init()

        val consoleSender = Bukkit.getServer().consoleSender
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f_§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f_§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f,§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f.§x§6§8§1§5§f§f_§x§6§8§1§5§f§f ")
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f@§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f`§x§6§8§1§5§f§f`§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f@§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f ")
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f.§x§6§8§1§5§f§f@§x§6§8§1§5§f§f@§x§6§8§1§5§f§f,§x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§fg§x§6§8§1§5§f§f@§x§6§8§1§5§f§fg§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f@§x§6§8§1§5§f§f@§x§6§8§1§5§f§fg§x§6§8§1§5§f§f §x§6§8§1§5§f§f3§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fK§x§6§8§1§5§f§f §x§6§8§1§5§f§fg§x§6§8§1§5§f§f@§x§6§8§1§5§f§fg§x§6§8§1§5§f§f_§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f,§x§6§8§1§5§f§f@§x§6§8§1§5§f§fg§x§6§8§1§5§f§f_§x§6§8§1§5§f§f §x§6§8§1§5§f§f.§x§6§8§1§5§f§f@§x§6§8§1§5§f§fL§x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f ")
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f^§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f@§x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f`§x§6§8§1§5§f§f`§x§6§8§1§5§f§f_§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fF§x§6§8§1§5§f§f §x§6§8§1§5§f§f'§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f`§x§6§8§1§5§f§f §x§6§8§1§5§f§f^§x§6§8§1§5§f§f §x§6§8§1§5§f§f!§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f@§x§6§8§1§5§f§f`§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f`§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fF§x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f_§x§6§8§1§5§f§f@§x§6§8§1§5§f§f`§x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f ")
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§fj§x§6§8§1§5§f§fF§x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fF§x§6§8§1§5§f§f^§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f_§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§fj§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§fj§x§6§8§1§5§f§fF§x§6§8§1§5§f§f §x§6§8§1§5§f§f.§x§6§8§1§5§f§f@§x§6§8§1§5§f§f^§x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f_§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f ")
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§f §x§6§8§1§5§f§f!§x§6§8§1§5§f§f@§x§6§8§1§5§f§f`§x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f@§x§6§8§1§5§f§f_§x§6§8§1§5§f§fj§x§6§8§1§5§f§f@§x§6§8§1§5§f§f_§x§6§8§1§5§f§f!§x§6§8§1§5§f§fL§x§6§8§1§5§f§f_§x§6§8§1§5§f§fJ§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§fL§x§6§8§1§5§f§f_§x§6§8§1§5§f§fJ§x§6§8§1§5§f§fK§x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§f@§x§6§8§1§5§f§fK§x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§f@§x§6§8§1§5§f§fK§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f_§x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f §x§6§8§1§5§f§f%§x§6§8§1§5§f§f_§x§6§8§1§5§f§f_§x§6§8§1§5§f§fJ§x§6§8§1§5§f§fL§x§6§8§1§5§f§f ")
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§f^§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f^§x§6§8§1§5§f§f §x§6§8§1§5§f§f'§x§6§8§1§5§f§f\"§x§6§8§1§5§f§f §x§6§8§1§5§f§f^§x§6§8§1§5§f§f^§x§6§8§1§5§f§f`§x§6§8§1§5§f§f'§x§6§8§1§5§f§f^§x§6§8§1§5§f§f §x§6§8§1§5§f§f`§x§6§8§1§5§f§f^§x§6§8§1§5§f§f`§x§6§8§1§5§f§f@§x§6§8§1§5§f§f §x§6§8§1§5§f§f'§x§6§8§1§5§f§f\"§x§6§8§1§5§f§f §x§6§8§1§5§f§f`§x§6§8§1§5§f§f^§x§6§8§1§5§f§f^§x§6§8§1§5§f§f`§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f'§x§6§8§1§5§f§f^§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f'§x§6§8§1§5§f§f^§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f`§x§6§8§1§5§f§f^§x§6§8§1§5§f§f^§x§6§8§1§5§f§f`§x§6§8§1§5§f§f^§x§6§8§1§5§f§f`§x§6§8§1§5§f§f^§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f'§x§6§8§1§5§f§f`§x§6§8§1§5§f§f §x§6§8§1§5§f§f`§x§6§8§1§5§f§f^§x§6§8§1§5§f§f`§x§6§8§1§5§f§f^§x§6§8§1§5§f§f`§x§6§8§1§5§f§f ")
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f!§x§6§8§1§5§f§f@§x§6§8§1§5§f§f,§x§6§8§1§5§f§fJ§x§6§8§1§5§f§fF§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f ")
        consoleSender.sendMessage("§x§e§8§0§3§f§f§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f`§x§6§8§1§5§f§f`§x§6§8§1§5§f§f`§x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f §x§6§8§1§5§f§f ")

        val plugin = this
        plugin.mcCoroutineConfiguration.shutdownStrategy = ShutdownStrategy.MANUAL

        // DI
        val pluginModule = module {
            single<JavaPlugin> {
                this@MagicWand
            }
        }

        val allModules = mutableListOf<Module>()
        allModules.add(pluginModule)
        allModules.addAll(appModules)
        val finalModules = allModules.toList()

        startKoin {
            modules(finalModules)
        }

        Mediator.defineFork()

        loader.createInitialConfig()
        plugin.server.scheduler.runTaskTimerAsynchronously(this, Runnable {
            license.validate()
        }, 1L, 20*3600*24) // one check every 24 hours

        val pluginId = ktPlugin.id
        if(pluginId!=null) {
            val metrics = Metrics(this, pluginId)
            addCustomMetrics(metrics)
        }

        val lamp: Lamp<BukkitCommandActor> = BukkitLamp.builder(this)
            .parameterTypes {
                it.addParameterType(com.bryanvalc.magicwand.modes.Mode::class.java, ModeType(modeManager))
                it.addParameterType(Configurable::class.java, ConfigurableType(modeManager))
                it.addParameterType(MaterialList::class.java, MaterialListType(materialRegistry))
            }
            .build()

        lamp.register(Reload())
        lamp.register(Wiki())
        lamp.register(QuotaReset())
        lamp.register(ModifierCommand())
        lamp.register(MagicBrush())
        lamp.register(BrushOptions())
        lamp.register(Lock())
        lamp.register(MagicSetting())
        lamp.register(MagicToggle())
        lamp.register(Antigravity())
        lamp.register(PersistLeaves())
        lamp.register(Redeem())

        val playerJoin = PlayerJoin()
        val blockInteractions = BlockInteractions()
        val itemDrop = ItemDrop()
        val playerInteract = PlayerInteract()
        val modesCommand = ModesCommand()
        Bukkit.getPluginManager().registerEvents(playerJoin, this)
        Bukkit.getPluginManager().registerEvents(blockInteractions, this)
        Bukkit.getPluginManager().registerEvents(itemDrop, this)
        Bukkit.getPluginManager().registerEvents(playerInteract, this)
        Bukkit.getPluginManager().registerEvents(modesCommand, this)
        Bukkit.getPluginManager().registerEvents(PlayerScroll(), this)
        Bukkit.getPluginManager().registerEvents(ValidateVersion(), this)
        Bukkit.getPluginManager().registerEvents(MenuInteract(), this)
        Bukkit.getPluginManager().registerEvents(ModeToggle(), this)

        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            Mode().register()
            Placing().register()
            Preview().register()
            Reset().register()
        }

        // Register extra worldedit noise functions, brought to you by squidpony
        Hook().register()

        initializeLegacyMaterialSupport() //TODO: figure out why this is needed and how to avoid it
        UpdateChecker.scheduleChecks()
    }



    override fun onDisable() {
        val plugin = this

        server.onlinePlayers.forEach { player -> //cleanup and save
            val uuid = player.uniqueId
            val playerDataOriginal: PlayerData? = players[uuid]

            if (playerDataOriginal == null) return

            PlayerDao.save(playerDataOriginal) //save to db
            players.remove(uuid) //thread safe remove
        }
        server.onlinePlayers.forEach {
            Mediator.kick(it)
        }



        plugin.launch {
            plugin.logger.info("Waiting for termination of tasks")
            delay(5_000L)
        }

        plugin.mcCoroutineConfiguration.disposePluginSession()
        PacketEvents.getAPI().terminate();
        // Plugin shutdown logic
    }

    private fun initializeLegacyMaterialSupport() {
        try {
            logger.info("Initializing Legacy Material Support, this might take a while...")
            val craftLegacyClass = Class.forName("org.bukkit.craftbukkit.legacy.CraftLegacy")
            logger.info("Legacy Material Support has been initialized.")
        } catch (e: Exception) {
            logger.severe("Failed to initialize Legacy Material Support: " + e.message)
        }
    }
}
