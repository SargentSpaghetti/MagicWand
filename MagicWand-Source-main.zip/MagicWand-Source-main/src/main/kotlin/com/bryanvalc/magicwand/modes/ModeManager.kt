package com.bryanvalc.magicwand.modes

class ModeManager {
    var modes: MutableList<Mode> = ArrayList<Mode>()

    fun getFromName(name: String): Mode? {
        val result = modes.stream().parallel()
            .filter { m: Mode -> m.name.equals(name, ignoreCase = true) }
            .findAny()
        return if (!result.isPresent) {
            null
        } else {
            result.get()
        }
    }

    fun registerMode(mode: Mode) {
        modes.add(mode)
    }

    fun registerModes(vararg mode: Mode) {
        for (item in mode) {
            modes.add(item)
        }
    }
}