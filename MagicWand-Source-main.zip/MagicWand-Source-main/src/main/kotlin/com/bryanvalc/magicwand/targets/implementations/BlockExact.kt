package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.freePlace
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import java.util.Map

class BlockExact : Target() {
    override fun isResolved(player: Player, playerData: PlayerData): Boolean {
        return true
    }

    override fun predict(player: Player, playerData: PlayerData): BlockVector3? {
        val trace = player.rayTraceBlocks(playerData.reach.toDouble())
        return if (trace != null) {

            val action = playerData.action

            if (action == null) {
                return null
            }

            var hit = trace.hitBlock // no matter what action is it, it will be the hit block
            if (hit == null) {
                return null
            }
            BlockVector3.at(hit.x, hit.y, hit.z)
        } else {
            freePlace(player, playerData)
        }
    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>>? {
        return Map.of<Int, MutableSet<BlockVector3>>()
    }
}