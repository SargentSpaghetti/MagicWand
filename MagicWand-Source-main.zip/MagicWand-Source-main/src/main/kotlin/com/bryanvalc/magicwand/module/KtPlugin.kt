package com.bryanvalc.magicwand.module

data class KtPlugin(
    val id: Int,
    val prefix: String,
    val updateUrl: String,
    val premiumMessage: String
)