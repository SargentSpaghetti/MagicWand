package com.bryanvalc.magicwand.noise.mask.impl

import com.sk89q.worldedit.function.mask.AbstractMask
import com.sk89q.worldedit.function.mask.Mask
import com.sk89q.worldedit.math.BlockVector3
import squidpony.squidmath.WhiteNoise

class WhiteMask(private val scale: Double, private val min: Double, private val max: Double) : AbstractMask() {
    override fun test(vector: BlockVector3): Boolean {
        val value = WhiteNoise.instance.getNoise(vector.x() * scale, vector.z() * scale, vector.y() * scale)
        return value >= min && value <= max
    }

    override fun copy(): Mask {
        return this
    }
}