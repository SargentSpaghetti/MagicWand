package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.DynamicTarget
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.block.BlockFace
import org.bukkit.entity.Player
import java.util.Map

class SamePlane : DynamicTarget() {
    override fun isResolved(player: Player, playerData: PlayerData): Boolean {
        return true
    }

    override fun predict(player: Player, playerData: PlayerData): BlockVector3? {
        return null
    }

    override fun nextTarget(player: Player, playerData: PlayerData): Target {
        val clicks = playerData.clicks

        val previousClick = clicks.lastOrNull()
        if(previousClick==null) return HitY()

        val previousTarget = previousClick.target

        return if (previousTarget == null) {
            HitY()
        } else if (previousTarget is HitX) {
            HitX()
        } else if (previousTarget is HitZ) {
            HitZ()
        } else if (previousTarget is HitY) {
            HitY()
        } else {
            HitY()
        }
    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>> {
        return Map.of<Int, MutableSet<BlockVector3>>()
    }
}