package com.bryanvalc.magicwand.modes

import com.bryanvalc.magicwand.data.PlayerData
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player

interface Multicolor {
    fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>
}