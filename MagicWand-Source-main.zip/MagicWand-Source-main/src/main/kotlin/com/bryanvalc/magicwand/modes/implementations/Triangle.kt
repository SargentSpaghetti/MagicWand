package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.bresenham3D
import com.bryanvalc.magicwand.context.fakeToBlockPoint
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.Distance
import com.bryanvalc.magicwand.targets.implementations.HitWall
import com.bryanvalc.magicwand.targets.implementations.HitY
import com.bryanvalc.magicwand.targets.implementations.SamePlane
import com.bryanvalc.magicwand.utils.Coloring
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.Vector3
import com.sk89q.worldedit.math.interpolation.LinearInterpolation
import com.sk89q.worldedit.math.interpolation.Node
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.entity.Player
import java.lang.Double
import java.util.*


class Triangle : Mode(), Multicolor, Scrollable, Configurable {
    init {
        name = "triangle"
        permission = "mode.triangle"
        materialMenu = Material.COAL
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/triangle"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        if (clickLocations.size == 1 || clickLocations.size == 2) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocations.add(pivot)
            }
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        if (clickLocations.size == 1) {
            val location: BlockVector3 = clickLocations[0]
            putBlock(shape, location, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
        } else if (clickLocations.size == 2) {
            val firstBlock: BlockVector3 = clickLocations[0]
            val lastBlock: BlockVector3 = clickLocations[1]

            val prediction: MutableList<BlockVector3> = bresenham3D(firstBlock, lastBlock)
            for (block in prediction) {
                putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
            }
        } else if (clickLocations.size == 3) {
            val firstBlock = clickLocations[0]
            val secondBlock = clickLocations[1]
            val thirdBlock = clickLocations[2]

            val firstVector = Vector3.at(firstBlock.x() + 0.5, firstBlock.y() + 0.5, firstBlock.z() + 0.5)
            val secondVector = Vector3.at(secondBlock.x() + 0.5, secondBlock.y() + 0.5, secondBlock.z() + 0.5)
            val thirdVector = Vector3.at(thirdBlock.x() + 0.5, thirdBlock.y() + 0.5, thirdBlock.z() + 0.5)

            val menu = forPlayer(playerData)
            val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"

            val finalPrediction: MutableList<BlockVector3> = ArrayList<BlockVector3>()
            when(filling) {
                "skeleton" -> {
                    val firstLine: MutableList<BlockVector3> = bresenham3D(firstBlock, secondBlock)
                    val secondLine: MutableList<BlockVector3> = bresenham3D(secondBlock, thirdBlock)
                    val thirdLine: MutableList<BlockVector3> = bresenham3D(thirdBlock, firstBlock)
                    finalPrediction.addAll(firstLine)
                    finalPrediction.addAll(secondLine)
                    finalPrediction.addAll(thirdLine)
                }
                else -> {
                    val firstNode = Node(firstVector)
                    val secondNode = Node(secondVector)
                    val thirdNode = Node(thirdVector)

                    val firstGroup = listOf<Node>(firstNode, secondNode)
                    val firstInterpolation = LinearInterpolation()
                    firstInterpolation.setNodes(firstGroup)

                    var i = 0.0
                    while (i <= 1) {
                        val floatingPoint = firstInterpolation.getPosition(i)
                        val floatingNode = Node(floatingPoint)

                        val temporalInterpolation = LinearInterpolation()
                        temporalInterpolation.setNodes(listOf<Node>(floatingNode, thirdNode))

                        var j = 0.0
                        while (j <= 1) {
                            val secondFloatingPoint = temporalInterpolation.getPosition(j)
                            val vector = secondFloatingPoint.fakeToBlockPoint()
                            finalPrediction.add(vector)

                            j += 0.01
                        }

                        i += 0.01
                    }
                }
            }

            for (block in finalPrediction) {
                putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
            }
        }

        val tempSet: MutableSet<Pair<BlockVector3, WrappedBlockState>> =
            ObjectOpenHashSet(shape)
        val ret: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(tempSet)

        return ret
    }

    override fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        return Coloring.falloffGradient(originalMesh, player, playerData)
    }

    override fun handleScrollUp(player: Player, playerData: PlayerData) {

        var currentOffset = playerData.offset
        if (Double.isNaN(currentOffset)) return
        currentOffset += 2.0
        playerData.offset = currentOffset
    }

    override fun handleScrollDown(player: Player, playerData: PlayerData) {

        var currentOffset = playerData.offset
        if (Double.isNaN(currentOffset)) return
        currentOffset -= 2.0
        playerData.offset = currentOffset
    }

    override fun getScrollTip(player: Player, playerData: PlayerData): Component? {
        val text =
            "<gray> distance: <white>" + playerData.offset + "<gray>, <white>scroll ▲<gray> to push, <white>scroll ▼<gray> to pull"
        return MiniMessage.miniMessage().deserialize(text)
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        val menu = forPlayer(playerData)
        val lock = (menu?.propertyByName("facing") as EnumProperty?)?.value?:"floor"

        val order = when(lock) {
            "floor" -> ArrayList(listOf(Block(), HitY(), SamePlane()))
            "wall" -> ArrayList(listOf(Block(), HitWall(), SamePlane()))
            else -> ArrayList(listOf(Block(), Distance(), Distance()))
        }

        return order
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "facing",
                    material = Material.QUARTZ,
                    lore = "facing.lore",
                    model = null,
                    value = "floor", options = listOf("any", "floor", "wall"),
                    models = mapOf(
                        "any" to 1,
                        "floor" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 3, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = null,
                    value = "full", options = listOf("full", "skeleton"),
                    models = mapOf(
                        "full" to 1,
                        "skeleton" to 4
                    )
                )
            ),
            3
        )
    }

}