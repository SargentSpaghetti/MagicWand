package com.bryanvalc.magicwand.utils.platform.paper

import com.bryanvalc.magicwand.utils.Messaging.getParsed
import com.bryanvalc.magicwand.utils.platform.PlatformImplementation
import com.github.retrooper.packetevents.protocol.item.ItemStack
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
import org.bukkit.Bukkit
import org.bukkit.Sound
import org.bukkit.block.Block
import org.bukkit.entity.Player
import org.bukkit.event.player.PlayerKickEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.InventoryHolder
import org.bukkit.inventory.InventoryView
import org.bukkit.inventory.meta.ItemMeta
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

object PaperSpecific: KoinComponent, PlatformImplementation {

    val plugin: JavaPlugin by inject()

    override fun getPluginVersion(): String {
        return plugin.pluginMeta.version
    }

    override fun getLanguageForPlayer(player: Player): String {
        val locale = player.locale()
        val language = locale.language.lowercase() + "_" + locale.country.uppercase()
        return language
    }

    override fun getProtocolVersionForPlayer(player: Player): Int {
        return player.protocolVersion
    }

    override fun setResourcePack(
        player: Player,
        url: String,
        hash: String,
        required: Boolean,
        prompt: String
    ) {
        player.setResourcePack(
            url,
            hash,
            required,
            player.getParsed(
                prompt
            )
        )
    }

    override fun sendActionBar(player: Player, message: Component) {
        player.sendActionBar(message)
    }

    override fun sendMessage(player: Player, message: Component) {
        player.sendMessage(message)
    }

    override fun displayName(itemMeta: ItemMeta, name: String) {
        itemMeta.displayName(MiniMessage.miniMessage().deserialize(name))
    }

    override fun displayName(itemMeta: ItemMeta, name: Component) {
        itemMeta.displayName(name)
    }

    override fun createInventory(
        owner: InventoryHolder?,
        size: Int,
        title: String
    ): Inventory {
        return Bukkit.createInventory(null, 54, Component.text(title))
    }

    override fun lore(
        itemMeta: ItemMeta,
        lore: List<Component>
    ) {
        itemMeta.lore(lore)
    }

    override fun getTitle(inventoryView: InventoryView): String {
        return PlainTextComponentSerializer.plainText().serialize(inventoryView.title())
    }

    override fun getDisplayName(itemStack: org.bukkit.inventory.ItemStack): String? {
        val displayName = itemStack.itemMeta.displayName()
        if(displayName==null) return null
        return PlainTextComponentSerializer.plainText().serialize(displayName)
    }

    override fun getLore(itemStack: org.bukkit.inventory.ItemStack): List<String>? {
        val baseLore = itemStack.lore()
        var loreStr = arrayListOf<String>()
        if (baseLore != null) {
            for (row in baseLore) {
                loreStr.add(PlainTextComponentSerializer.plainText().serialize(row))
            }
        }
        return loreStr
    }

    override fun playSound(player: Player, sound: Sound) {
        val convertedSound = net.kyori.adventure.sound.Sound.sound(
            sound.key(),
            net.kyori.adventure.sound.Sound.Source.BLOCK,
            1f, 1f)
        player.playSound(convertedSound)
    }

    override fun isEmpty(block: Block): Boolean {
        return block.isEmpty
    }

    override fun isSolid(block: Block): Boolean {
        return block.isSolid
    }

    override fun isLiquid(block: Block): Boolean {
        return block.isLiquid
    }

    override fun kick(player: Player) {
        player.kick(Component.text("Server closed"), PlayerKickEvent.Cause.PLUGIN)
    }


}