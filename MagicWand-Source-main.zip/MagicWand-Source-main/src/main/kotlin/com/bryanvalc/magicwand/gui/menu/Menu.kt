package com.bryanvalc.magicwand.gui.menu

import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.platform.Mediator
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Bukkit
import org.bukkit.entity.Player
import kotlin.math.max

class Menu(
    val title: String,
    val options: Set<Property>,
    val rowCount: Int? = null,
) {

    fun propertyByName(name: String): Property? {
        return options.asSequence().firstOrNull { it.name == name }
    }

    fun render(player: Player) {
        var rowAmount = 1

        for(option in options) {
            rowAmount = max(rowAmount, option.row+1)
        }
        var cellAmount = rowAmount*9
        if(rowCount!=null) {
            cellAmount = rowCount*9
        }

        var titleStr = "No translation found for $title"
        val languagePack = player.getLanguagePack()
        languagePack?.let {
            titleStr = it.subMenus[title] ?: titleStr
        }
        val gui = Mediator.createInventory(null, cellAmount, titleStr)

        for(option in options) {
            gui.setItem(option.position(), option.getItem(player))
        }

        player.openInventory(gui)
    }

    override fun hashCode() = title.hashCode()

    override fun equals(other: Any?): Boolean {
        val otherMenu = other as Menu
        return otherMenu.hashCode() == this.hashCode()
    }

}