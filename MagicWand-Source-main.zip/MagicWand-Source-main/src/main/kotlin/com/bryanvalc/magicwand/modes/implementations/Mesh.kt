package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.bresenham3D
import com.bryanvalc.magicwand.context.fakeToBlockPoint
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.IntProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.ContinuousDistance
import com.bryanvalc.magicwand.utils.Coloring
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.Vector3
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.World
import org.bukkit.entity.Player
import java.util.*
import java.util.function.Function
import java.util.stream.Collectors
import kotlin.IllegalStateException

class Mesh : Mode(), Multicolor, Scrollable, Configurable {
    init {
        name = "mesh"
        permission = "mode.mesh"
        materialMenu = Material.POPPED_CHORUS_FRUIT
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/mesh"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocationsRepeated: MutableList<BlockVector3> = ArrayList<BlockVector3>(clicks.size + 1)
        for (click in clicks) {
            clickLocationsRepeated.add(click.location)
        }
        val pivot = playerData.pivot
        if(pivot!=null){
            clickLocationsRepeated.add(pivot)
        } // this is dirty, but who cares
        val locationsSet: MutableSet<BlockVector3> = HashSet<BlockVector3>(clickLocationsRepeated)
        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>(locationsSet)

        if (clickLocations.isEmpty()) {
            return null
        }

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ObjectArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        when (clickLocations.size) {
            1 -> drawSinglePoint(
                shape,
                clickLocations[0],
                blockData,
                world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )

            2 -> drawLine(
                shape,
                clickLocations[0],
                clickLocations[1],
                blockData,
                world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )

            else -> drawMesh(
                shape,
                clickLocations,
                blockData,
                playerData,
                world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )
        }

        return ReferenceArrayList(shape)
    }

    private fun drawSinglePoint(
        shape: MutableList<Pair<BlockVector3, WrappedBlockState>>,
        location: BlockVector3,
        blockData: WrappedBlockState,
        world: World,
        replaceAir: Boolean,
        replaceSolid: Boolean,
        replaceSoft: Boolean,
        replaceLiquid: Boolean
    ) {
        putBlock(shape, location, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
    }

    private fun drawLine(
        shape: MutableList<Pair<BlockVector3, WrappedBlockState>>,
        start: BlockVector3,
        end: BlockVector3,
        blockData: WrappedBlockState,
        world: World,
        replaceAir: Boolean,
        replaceSolid: Boolean,
        replaceSoft: Boolean,
        replaceLiquid: Boolean
    ) {
        val prediction: MutableList<BlockVector3> = bresenham3D(start, end)
        for (block in prediction) {
            putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
        }
    }

    private fun drawMesh(
        shape: MutableList<Pair<BlockVector3, WrappedBlockState>>,
        clickLocations: List<BlockVector3>,
        blockData: WrappedBlockState,
        playerData: PlayerData,
        world: World,
        replaceAir: Boolean,
        replaceSolid: Boolean,
        replaceSoft: Boolean,
        replaceLiquid: Boolean
    ) {
        val groups = buildNeighborGroups(playerData, clickLocations)
        val cleanedPermutations = generateCleanedPermutations(groups)


        for (triangle in cleanedPermutations) {
            val triangleFace = makeTriangle(triangle[0], triangle[1], triangle[2])
            for (block in triangleFace) {
                putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
            }
        }
    }

    private fun buildNeighborGroups(
        playerData: PlayerData,
        clickLocations: List<BlockVector3>
    ): MutableMap<BlockVector3, MutableList<BlockVector3>> {

        val menu = forPlayer(playerData)
        val offset = ((menu?.propertyByName("merge.distance") as IntProperty?)?.value?:25).toDouble()

        var retValue: MutableMap<BlockVector3, MutableList<BlockVector3>> =
            Object2ObjectOpenHashMap()
        try {
            retValue = clickLocations.stream().collect(
                Collectors.toMap(
                    Function { evaluated: BlockVector3 -> evaluated },
                    Function { evaluated: BlockVector3 ->
                        clickLocations.stream()
                            .filter { c: BlockVector3 -> c.distance(evaluated) < offset }
                            .collect(Collectors.toList())
                    }
                ))
        } catch (_: IllegalStateException) { // we don't really care about duplicates and the exception thrown
        }
        return retValue
    }

    private fun generateCleanedPermutations(groups: MutableMap<BlockVector3, MutableList<BlockVector3>>): MutableList<MutableList<BlockVector3>> {
        val uniqueTriangles: MutableSet<MutableSet<BlockVector3>> = HashSet<MutableSet<BlockVector3>>()

        for (entry in groups.entries) {
            val key: BlockVector3 = entry.key
            val neighbors: MutableList<BlockVector3> = entry.value
            if (neighbors.size < 2) continue

            for (i in 0..<neighbors.size - 1) {
                for (j in i + 1..<neighbors.size) {
                    val triangle: MutableSet<BlockVector3> =
                        HashSet<BlockVector3>(listOf(key, neighbors[i], neighbors[j]))
                    if (triangle.size == 3) {  // Ensure we have 3 unique points
                        uniqueTriangles.add(triangle)
                    }
                }
            }
        }

        return uniqueTriangles.stream()
            .map { c: MutableSet<BlockVector3> -> ArrayList(c) }
            .collect(Collectors.toList())
    }

    fun makeTriangle(
        firstBlock: BlockVector3,
        secondBlock: BlockVector3,
        thirdBlock: BlockVector3
    ): MutableList<BlockVector3> {
        val prediction: MutableSet<BlockVector3> = HashSet<BlockVector3>()

        val v1 = Vector3.at(firstBlock.x() + 0.5, firstBlock.y() + 0.5, firstBlock.z() + 0.5)
        val v2 = Vector3.at(secondBlock.x() + 0.5, secondBlock.y() + 0.5, secondBlock.z() + 0.5)
        val v3 = Vector3.at(thirdBlock.x() + 0.5, thirdBlock.y() + 0.5, thirdBlock.z() + 0.5)

        var i = 0.0
        while (i <= 1) {
            val edge1 = v1.multiply(1 - i).add(v2.multiply(i))
            var j = 0.0
            while (j <= 1) {
                val point = edge1.multiply(1 - j).add(v3.multiply(j))
                prediction.add(point.fakeToBlockPoint())
                j += 0.02
            }
            i += 0.02
        }

        return ArrayList<BlockVector3>(prediction)
    }

    override fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        return Coloring.falloffGradient(originalMesh, player, playerData)
    }

    override fun handleScrollUp(player: Player, playerData: PlayerData) {

        var currentOffset = playerData.offset
        if (currentOffset.isNaN()) return
        currentOffset += 2.0
        playerData.offset = currentOffset
    }

    override fun handleScrollDown(player: Player, playerData: PlayerData) {

        var currentOffset = playerData.offset
        if (currentOffset.isNaN()) return
        currentOffset -= 2.0
        playerData.offset = currentOffset
    }

    override fun getScrollTip(player: Player, playerData: PlayerData): Component? {
        val text =
            "<gray> distance: <white>" + playerData.offset + "<gray>, <white>scroll ▲<gray> to push, <white>scroll ▼<gray> to pull"
        return MiniMessage.miniMessage().deserialize(text)
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList(listOf(Block(), ContinuousDistance()))
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                IntProperty(
                    row = 1, column = 1, name = "merge.distance",
                    material = Material.BLAZE_ROD,
                    lore = "merge.distance.lore",
                    model = 1,
                    value = 25
                )
            ),
            3
        )
    }

}