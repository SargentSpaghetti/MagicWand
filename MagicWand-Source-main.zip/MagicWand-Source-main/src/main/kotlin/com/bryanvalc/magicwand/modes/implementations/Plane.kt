package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.effects.Hull
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.Hit
import com.bryanvalc.magicwand.targets.implementations.HitWall
import com.bryanvalc.magicwand.targets.implementations.HitY
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*

class Plane : Mode(), Configurable {
    init {
        name = "plane"
        permission = "mode.plane"
        materialMenu = Material.PAPER
        premium = false
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/plane"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        if (clickLocations.size == 1) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocations.add(pivot)
            }
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val menu = forPlayer(playerData)
        val origin = (menu?.propertyByName("origin") as EnumProperty?)?.value?:"corner"
        val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"

        when(origin) {
            "center" -> {
                val firstClick = clickLocations.firstOrNull()
                val lastClick = clickLocations.lastOrNull()
                if(firstClick!=null && lastClick!=null) {
                    val diff = lastClick.subtract(firstClick)
                    val otherCorner = firstClick.subtract(diff)
                    clickLocations.add(otherCorner)
                }
            }
        }

        val newCubeMin: BlockVector3 = minBlockVector(*clickLocations.toTypedArray<BlockVector3>())
        val newCubeMax: BlockVector3 = maxBlockVector(*clickLocations.toTypedArray<BlockVector3>())

        val minX = newCubeMin.x()
        val minY = newCubeMin.y()
        val minZ = newCubeMin.z()
        val maxX = newCubeMax.x()
        val maxY = newCubeMax.y()
        val maxZ = newCubeMax.z()

        var shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        for (x in minX..maxX) {
            for (y in minY..maxY) {
                for (z in minZ..maxZ) {
                    shape.add(Pair(BlockVector3.at(x,y,z), blockData))
                }
            }
        }

        when(filling) {
            "skeleton" -> {
                shape = Hull(4,4).apply(shape)
            }
            else -> {}
        }

        val shapeFinal: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(shape.size)

        for (block in shape) {
            putBlock(
                shapeFinal,
                block.first,
                blockData,
                world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )
        }

        return shapeFinal
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "facing",
                    material = Material.QUARTZ,
                    lore = "facing.lore",
                    model = null,
                    value = "floor", options = listOf("any", "floor", "wall"),
                    models = mapOf(
                        "any" to 1,
                        "floor" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 3, name = "origin",
                    material = Material.NETHER_WART,
                    lore = "origin.lore",
                    model = null,
                    value = "corner", options = listOf("corner", "center"),
                    models = mapOf(
                        "corner" to 1,
                        "center" to 2
                    )
                ),
                EnumProperty(
                    row = 1, column = 5, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = null,
                    value = "full", options = listOf("full", "skeleton"),
                    models = mapOf(
                        "full" to 1,
                        "skeleton" to 4
                    )
                )
            ),
            3
        )
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {

        val menu = forPlayer(playerData)
        val lock = (menu?.propertyByName("facing") as EnumProperty?)?.value?:"floor"

        val order = when(lock) {
            "floor" -> ArrayList(listOf(Block(), HitY()))
            "wall" -> ArrayList(listOf(Block(), HitWall()))
            else -> ArrayList(listOf(Block(), Hit()))
        }

        return order
    }

}