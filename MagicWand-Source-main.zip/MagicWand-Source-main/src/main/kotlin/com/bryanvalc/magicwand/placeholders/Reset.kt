package com.bryanvalc.magicwand.placeholders

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.storage.PlayerDao
import me.clip.placeholderapi.expansion.PlaceholderExpansion
import org.bukkit.OfflinePlayer
import org.bukkit.entity.Player
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID

class Reset : PlaceholderExpansion(), KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()

    override fun getAuthor(): String {
        return "BryanValc" //
    }

    override fun getIdentifier(): String {
        return "reset"
    }

    override fun getVersion(): String {
        return "1.0.0"
    }

    override fun onRequest(player: OfflinePlayer, params: String): String? {
        val uuid = player.uniqueId
        var playerData: PlayerData? = players[uuid]
        if (playerData == null) { playerData = PlayerData(uuid) }
        val player1 = player.player
        if (player1 == null) { playerData = PlayerDao.load(playerData) }

        var intervalMs = playerData.limitInterval
        if(intervalMs==-1L){
            intervalMs = Long.MAX_VALUE
        } else {
            intervalMs*=1000
        }

        val lastResetMs = playerData.lastReset
        val currentMs = System.currentTimeMillis()

        var diff = intervalMs - (currentMs - lastResetMs)

        if (params.equals("milliseconds", ignoreCase = true)) {
            return diff.toString() + ""
        }
        diff /= 1000
        if (params.equals("seconds", ignoreCase = true)) {
            return diff.toString() + ""
        }
        diff /= 60
        if (params.equals("minutes", ignoreCase = true)) {
            return diff.toString() + ""
        }
        diff /= 60
        if (params.equals("hours", ignoreCase = true)) {
            return diff.toString() + ""
        }
        diff /= 24
        if (params.equals("days", ignoreCase = true)) {
            return diff.toString() + ""
        }

        return null
    }

    override fun onPlaceholderRequest(player: Player, params: String): String? {
        val uuid = player.uniqueId
        var playerData: PlayerData? = players[uuid]
        if (playerData == null) { playerData = PlayerData(uuid) }
        val player1 = player.player
        if (player1 == null) { playerData = PlayerDao.load(playerData) }

        var intervalMs = playerData.limitInterval
        if(intervalMs==-1L){
            intervalMs = Long.MAX_VALUE
        } else {
            intervalMs*=1000
        }
        val lastResetMs = playerData.lastReset
        val currentMs = System.currentTimeMillis()

        var diff = intervalMs - (currentMs - lastResetMs)

        if (params.equals("milliseconds", ignoreCase = true)) {
            return diff.toString() + ""
        }
        diff /= 1000
        if (params.equals("seconds", ignoreCase = true)) {
            return diff.toString() + ""
        }
        diff /= 60
        if (params.equals("minutes", ignoreCase = true)) {
            return diff.toString() + ""
        }
        diff /= 60
        if (params.equals("hours", ignoreCase = true)) {
            return diff.toString() + ""
        }
        diff /= 24
        if (params.equals("days", ignoreCase = true)) {
            return diff.toString() + ""
        }

        return null
    }
}