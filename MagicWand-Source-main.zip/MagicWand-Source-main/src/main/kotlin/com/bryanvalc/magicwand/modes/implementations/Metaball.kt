package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.equalsByTolerance
import com.bryanvalc.magicwand.context.BlockVectorUtils.removeTailingClick
import com.bryanvalc.magicwand.context.BlockVectorUtils.preCalculateInfluence
import com.bryanvalc.magicwand.context.effects.Hull
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.ContinuousDistance
import com.bryanvalc.magicwand.utils.Coloring
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*
import java.util.function.Consumer

class Metaball : Mode(), Scrollable, Multicolor, Configurable {
    init {
        name = "metaball"
        permission = "mode.metaball"
        materialMenu = Material.WHITE_DYE
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/metaball"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        var clicks: MutableList<ClickData> = ArrayList<ClickData>(playerData.clicks) // to avoid side effects

        val metaballs: MutableList<BlockVector3> = ArrayList<BlockVector3>(clicks.size + 1)
        clicks.forEach(Consumer { click: ClickData -> metaballs.add(click.location) })

        val pivot = playerData.pivot
        if (pivot != null) {
            metaballs.add(pivot)
        }

        if (metaballs.isEmpty()) {
            return null
        }

        val totalInfluence: MutableMap<BlockVector3, Double> = HashMap<BlockVector3, Double>()

        clicks = removeTailingClick(clicks, 2)
        for (clickData in clicks) {
            val radius = clickData.brushSize.toDouble()
            val influenceCache: MutableMap<BlockVector3, Double> = preCalculateInfluence(radius)
            processMetaball(clickData.location, totalInfluence, influenceCache)
        }

        if(clicks.isEmpty()) return null

        val last = clicks.lastOrNull()

        if (pivot!=null && last!=null && !equalsByTolerance(pivot, last.location, 2.0)) {
            val radius = playerData.brushSize.toDouble()
            val influenceCache: MutableMap<BlockVector3, Double> = preCalculateInfluence(radius)
            processMetaball(pivot, totalInfluence, influenceCache)
        }

        var shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        for (entry in totalInfluence.entries) {
            if (entry.value >= 1) {
                val point = entry.key

                shape.add(Pair(point, blockData))
            }
        }

        val menu = forPlayer(playerData)
        val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"

        when(filling) {
            "hollow" -> {
                shape = Hull(6,6).apply(shape)
            }
            else -> {}
        }

        val shapeFinal: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(shape.size)

        for(block in shape) {
            putBlock(
                shapeFinal,
                block.first,
                blockData,
                world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )
        }

        return shapeFinal
    }

    private fun processMetaball(
        metaball: BlockVector3,
        totalInfluence: MutableMap<BlockVector3, Double>,
        influenceCache: MutableMap<BlockVector3, Double>
    ) {
        for (entry in influenceCache.entries) {
            val offset = entry.key
            val point = metaball.add(offset)
            totalInfluence.merge(point, entry.value) { a: Double, b: Double -> a+b }
        }
    }

    override fun handleScrollUp(player: Player, playerData: PlayerData) {
        val uuid = player.uniqueId
        val currentSize = playerData.brushSize + 1
        playerData.setBrushSize(uuid, currentSize)
    }

    override fun handleScrollDown(player: Player, playerData: PlayerData) {
        val uuid = player.uniqueId
        val currentSize = playerData.brushSize - 1
        playerData.setBrushSize(uuid, currentSize)
    }

    override fun getScrollTip(player: Player, playerData: PlayerData): Component? {
        val text =
            "<gray> size: <white>" + playerData.brushSize + "<gray>, <white>scroll ▲<gray> to increase size, <white>scroll ▼<gray> to decrease"
        return MiniMessage.miniMessage().deserialize(text)
    }

    override fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        return Coloring.falloffGradient(originalMesh, player, playerData)
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList(listOf(Block(), ContinuousDistance()))
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = 1,
                    value = "full", options = listOf("full", "hollow"),
                    models = mapOf(
                        "full" to 1,
                        "hollow" to 3
                    )
                )
            ),
            3
        )

//        DoubleProperty(
//            row = 1, column = 3, name = "Merge distance",
//            material = Material.REDSTONE,
//            lore = "Distance for the metaballs to connect",
//            model = 1,
//            value = 4.0,
//            min = 1.0,
//            max = 10.0
//        )
    }

}