package com.bryanvalc.magicwand.modes

interface Refreshable {
}