package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.annotation.Optional
import revxrsal.commands.annotation.Suggest
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission
import java.util.UUID

class MagicToggle: KoinComponent {

    val plugin: JavaPlugin by inject()
    val players: MutableMap<UUID, PlayerData> by inject()

    @Command("magictoggle", "mt")
    @CommandPermission("magicwand.magictoggle")
    fun toggle(
        actor: BukkitCommandActor,
        @Suggest("brushmode", "origin", "surfacesnap", "chatfeedback", "tutorial",
            "ruler", "useglowing", "smartpaint", "airmask", "solidmask", "softmask", "liquidmask") option: String,
        @Optional enable: Boolean?
    ){
        val sender = actor.sender()
        if (sender !is Player) {
            return
        }
        val player = sender as Player

        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        val message = when(option) {
            "brushmode" -> {
                playerData.brushMode = enable?:!playerData.brushMode
                if (playerData.brushMode) {
                    "Brush mode enabled"
                } else {
                    "Brush mode disabled"
                }
            }
            "origin" -> {
                playerData.centerOrigin = enable?:!playerData.centerOrigin
                if (playerData.centerOrigin) {
                    "Origin set to center"
                } else {
                    "Origin set to face"
                }
            }
            "surfacesnap" -> {
                playerData.snap = enable?:!playerData.snap
                if (playerData.snap) {
                    "Snap to surface enabled"
                } else {
                    "Snap to surface disabled"
                }
            }
            "chatfeedback" -> {
                playerData.chatFeedback = enable?:!playerData.chatFeedback
                if (playerData.chatFeedback) {
                    "Chat feedback enabled"
                } else {
                    "Chat feedback disabled"
                }
            }
            "tutorial" -> {
                playerData.tutorial = enable?:!playerData.tutorial
                if (playerData.tutorial) {
                    "Tutorial mode enabled"
                } else {
                    "Tutorial mode disabled"
                }
            }
            "ruler" -> {
                playerData.ruler = enable?:!playerData.ruler
                if (playerData.ruler) {
                    "Ruler mode enabled"
                } else {
                    "Ruler mode disabled"
                }
            }
            "useglowing" -> {
                playerData.glowing = enable?:!playerData.glowing
                if (playerData.glowing) {
                    "Glowing mode enabled"
                } else {
                    "Glowing mode disabled"
                }
            }
            "smartpaint" -> {
                playerData.smartPaint = enable?:!playerData.smartPaint
                if (playerData.smartPaint) {
                    "Smart paint enabled"
                } else {
                    "Smart paint disabled"
                }
            }
            "airmask" -> {
                playerData.replaceAir = enable?:!playerData.replaceAir
                if (playerData.replaceAir) {
                    "Air mask enabled"
                } else {
                    "Air mask disabled"
                }
            }
            "solidmask" -> {
                playerData.replaceSolid = enable?:!playerData.replaceSolid
                if (playerData.replaceSolid) {
                    "Solid mask enabled"
                } else {
                    "Solid mask disabled"
                }
            }
            "softmask" -> {
                playerData.replaceSoft = enable?:!playerData.replaceSoft
                if (playerData.replaceSoft) {
                    "Soft mask enabled"
                } else {
                    "Soft mask disabled"
                }
            }
            "liquidmask" -> {
                playerData.replaceLiquid = enable?:!playerData.replaceLiquid
                if (playerData.replaceLiquid) {
                    "Liquid mask enabled"
                } else {
                    "Liquid mask disabled"
                }
            }
            else -> {null}
        }
        message?.let {
            player.sendParsed(message)
        }
        players[uuid] = playerData
    }
}