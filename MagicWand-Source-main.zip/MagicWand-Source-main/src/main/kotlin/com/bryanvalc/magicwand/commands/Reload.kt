package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.module.KtPlugin
import com.bryanvalc.magicwand.module.License
import com.bryanvalc.magicwand.module.Loader
import com.bryanvalc.magicwand.module.config.Configuration
import com.bryanvalc.magicwand.module.locales.LangManager
import com.bryanvalc.magicwand.utils.ConfLoader
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission
import java.io.File

class Reload: KoinComponent {

    val loader: Loader by inject()
    val plugin: JavaPlugin by inject()
    val config: Configuration by inject()
    val license: License by inject()
    val ktPlugin: KtPlugin by inject()
    val langManager: LangManager by inject()

    @Command("reload")
    @CommandPermission("magicwand.reload")
    fun reload(actor: BukkitCommandActor) {
        plugin.server.scheduler.runTask(plugin, Runnable {
            loader.createInitialConfig()

            val configFile = File(plugin.dataFolder, "config.conf")
            val newConfig = ConfLoader.loadAndOrUpdate<Configuration>(configFile, "config.conf")!!
            config.useGlowing = newConfig.useGlowing
            config.maxDistance = newConfig.maxDistance
            config.storage = newConfig.storage
            config.license = newConfig.license
            config.defaults = newConfig.defaults
            config.texturePack = newConfig.texturePack
            config.maxBound = newConfig.maxBound
            config.language = newConfig.language
            config.updateNotify = newConfig.updateNotify

            license.validate()
            langManager.languages.clear()
            val sender = actor.sender()
            if (sender is Player) {
                val player = sender as Player
                if (license.cachedResult) {
                    player.sendParsed("Reloaded! License valid. Thanks for your support!")
                } else {
                    player.sendParsed("Reload successful, couldn't validate license")
                    player.sendParsed(ktPlugin.premiumMessage)
                }
                player.sendParsed("Feedback? " +
                        "<gradient:#3792d4:#8968d3:#8d4ca9><a:https://forms.gle/kvkwMQWdmPnM2aKh6>Share yours</a></gradient>! " +
                        "Takes 2 minutes, helps improve the tool and could enable " +
                        "full-time development bringing many more features.")
            }
        })

    }

}