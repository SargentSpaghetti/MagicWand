package com.bryanvalc.magicwand.module.storage

import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.Table

import java.util.UUID

object Players : Table() {

    val uuid: Column<UUID> = uuid("uuid")
    val previewedNow: Column<Long> = long("previewed")
    val placedNow: Column<Long> = long("placed")
    val allTimePlaced: Column<Long> = long("all_time_placed")
    val reach: Column<Int> = integer("reach")
    val boundLimit: Column<Int> = integer("bound_limit")
    val falloffStrength: Column<Double> = double("falloff_strength")
    val mixingStrength: Column<Double> = double("mixing_strength")
    val brushSize: Column<Int> = integer("brush_size")
    val replaceAir: Column<Boolean> = bool("replace_air")
    val replaceSolid: Column<Boolean> = bool("replace_solid")
    val replaceSoft: Column<Boolean> = bool("replace_soft")
    val replaceLiquid: Column<Boolean> = bool("replace_liquid")
    val smartPaint: Column<Boolean> = bool("smart_paint")
    val glowing: Column<Boolean> = bool("glowing")
    val ruler: Column<Boolean> = bool("ruler")
    val mode: Column<String> = varchar("mode", 20)
    val favoriteModes: Column<String> = text("favorite_modes")
    val tutorial: Column<Boolean> = bool("tutorial")
    val snap: Column<Boolean> = bool("snap")
    val brushMode: Column<Boolean> = bool("brush")
    val centerOrigin: Column<Boolean> = bool("center_origin")
    val chatFeedback: Column<Boolean> = bool("chat_feedback").default(false)

    override val primaryKey = PrimaryKey(uuid)

}