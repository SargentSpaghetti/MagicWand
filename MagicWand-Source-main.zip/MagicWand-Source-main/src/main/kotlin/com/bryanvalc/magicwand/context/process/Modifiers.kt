package com.bryanvalc.magicwand.context.process

import com.bryanvalc.magicwand.context.PlayerUtils.modifiersFromShulker
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.data.modifier.Modifier
import com.bryanvalc.magicwand.utils.Masking
import com.bryanvalc.magicwand.utils.ModifierParser
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.Material
import org.bukkit.entity.Player

object Modifiers {

    fun attemptApply(player: Player, playerData: PlayerData, newShape: List<Pair<BlockVector3, WrappedBlockState>>): MutableList<Pair<BlockVector3, WrappedBlockState>>? {



        if (player.inventory.itemInOffHand.type != Material.AIR) {
            val modifier: Modifier? = ModifierParser.loadFromItem(player.inventory.itemInOffHand)
            if (modifier != null) {
                return modifier.apply(newShape, player, playerData)
            } else { //we use the item in the off-hand as mask, or maybe list of modifiers
                val modifiers: List<Modifier>? = modifiersFromShulker(player)
                if (!modifiers.isNullOrEmpty()) {
                    var buffer = newShape.toMutableList()
                    for (modifierItem in modifiers) {
                        buffer = modifierItem.apply(buffer, player, playerData)
                    }
                    return buffer
                } else {
                    return Masking.offHand(newShape, player)
                }
            }
        }

        return newShape.toMutableList()
    }


}