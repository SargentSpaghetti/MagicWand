package com.bryanvalc.magicwand.context.overlay

import com.bryanvalc.magicwand.context.BlockVectorUtils
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.PluginRepository
import com.sk89q.worldedit.math.BlockVector3
import de.oliver.fancyholograms.api.data.HologramData
import de.oliver.fancyholograms.api.data.TextHologramData
import de.oliver.fancyholograms.api.hologram.Hologram
import org.bukkit.Color
import org.bukkit.Location
import org.bukkit.entity.Display
import org.bukkit.entity.Player
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.function.ToDoubleFunction
import java.util.stream.Collectors

object ShowDimensions: KoinComponent {

    val pluginRepository: PluginRepository by inject()

    fun show(player: Player, playerData: PlayerData) {
        val clickDataList: MutableList<ClickData> = playerData.clicks
        val clicksArrayList: MutableList<BlockVector3> = ArrayList()

        if (clickDataList.isEmpty()) return

        for (click in clickDataList) {
            clicksArrayList.add(click.location)
        }
        val pivot = playerData.pivot
        if (pivot != null) {
            clicksArrayList.add(pivot)
        }

        val clicks = clicksArrayList.toTypedArray<BlockVector3>()

        if (clicks.isEmpty()) {
            return
        }

        val newCubeMin: BlockVector3 = BlockVectorUtils.minBlockVector(*clicks)
        val newCubeMax: BlockVector3 = BlockVectorUtils.maxBlockVector(*clicks)

        val minX = newCubeMin.x()
        val minY = newCubeMin.y()
        val minZ = newCubeMin.z()
        val maxX = newCubeMax.x()
        val maxY = newCubeMax.y()
        val maxZ = newCubeMax.z()

        val world = player.world

        val eightVertexes = listOf<Location>(
            Location(world, (minX - 1).toDouble(), (minY - 1).toDouble(), (minZ - 1).toDouble()),
            Location(world, (minX - 1).toDouble(), (minY - 1).toDouble(), (maxZ + 1).toDouble()),
            Location(world, (minX - 1).toDouble(), (maxY + 1).toDouble(), (minZ - 1).toDouble()),
            Location(world, (minX - 1).toDouble(), (maxY + 1).toDouble(), (maxZ + 1).toDouble()),
            Location(world, (maxX + 1).toDouble(), (minY - 1).toDouble(), (minZ - 1).toDouble()),
            Location(world, (maxX + 1).toDouble(), (minY - 1).toDouble(), (maxZ + 1).toDouble()),
            Location(world, (maxX + 1).toDouble(), (maxY + 1).toDouble(), (minZ - 1).toDouble()),
            Location(world, (maxX + 1).toDouble(), (maxY + 1).toDouble(), (maxZ + 1).toDouble())
        )

        val playerLoc = player.eyeLocation
        val trace = player.getLineOfSight(null, playerData.reach)
        var closestDistSoFar = 1000.0

        var closest: Location = eightVertexes.first()
        for (block in trace) {
            val closestVertex: Location = eightVertexes.stream()
                .sorted(
                    Comparator.comparingDouble(
                        ToDoubleFunction { c: Location -> c.distance(block.location) })
                )
                .collect(Collectors.toList())
                .first()

            if (closestVertex.distance(block.location) < closestDistSoFar) {
                closestDistSoFar = closestVertex.distance(block.location)
                closest = closestVertex
            }
        }

        val x = maxX - minX + 1
        val y = maxY - minY + 1
        val z = maxZ - minZ + 1

        if (x == 1 && y == 1 && z == 1) {
            return
        }

        val constantDistance = 7.0
        val brightness = Display.Brightness(15, 15)

        val hologramManager = pluginRepository.hologramManager
        if(hologramManager==null) return

        val stringX = player.name + "_x"
        var hologramX: Hologram? = hologramManager.getHologram(stringX).orElse(null)
        val locationX = Location(world, (minX + maxX + 1).toDouble() / 2, closest.y, closest.z)
        val ratioX = (playerLoc.distance(locationX) - constantDistance) / playerLoc.distance(locationX)
        val locationXMiddle = Location(
            world,
            (locationX.x * (1 - ratioX) + playerLoc.x * ratioX),
            (locationX.y * (1 - ratioX) + playerLoc.y * ratioX),
            (locationX.z * (1 - ratioX) + playerLoc.z * ratioX)
        )

        val stringY = player.name + "_y"
        var hologramY: Hologram? = hologramManager.getHologram(stringY).orElse(null)
        val locationY = Location(world, closest.x, (minY + maxY + 1).toDouble() / 2, closest.z)
        val ratioY = (playerLoc.distance(locationY) - constantDistance) / playerLoc.distance(locationY)
        val locationYMiddle = Location(
            world,
            (locationY.x * (1 - ratioY) + playerLoc.x * ratioY),
            (locationY.y * (1 - ratioY) + playerLoc.y * ratioY),
            (locationY.z * (1 - ratioY) + playerLoc.z * ratioY)
        )

        val stringZ = player.name + "_z"
        var hologramZ: Hologram? = hologramManager.getHologram(stringZ).orElse(null)
        val locationZ = Location(world, closest.x, closest.y, (minZ + maxZ + 1).toDouble() / 2)
        val ratioZ = (playerLoc.distance(locationZ) - constantDistance) / playerLoc.distance(locationZ)
        val locationZMiddle = Location(
            world,
            (locationZ.x * (1 - ratioZ) + playerLoc.x * ratioZ),
            (locationZ.y * (1 - ratioZ) + playerLoc.y * ratioZ),
            (locationZ.z * (1 - ratioZ) + playerLoc.z * ratioZ)
        )

        if (hologramX == null) {
            val hologramDataX = TextHologramData(stringX, locationXMiddle)

            hologramDataX.setBackground(Color.fromBGR(100, 100, 255))
            hologramDataX.setText(listOf(x.toString() + ""))
            hologramDataX.setPersistent(false)
            hologramDataX.setSeeThrough(false)
            hologramDataX.setVisibilityDistance(10)
            hologramDataX.setTextUpdateInterval(1)
            hologramDataX.setBrightness(brightness)

            hologramX = hologramManager.create(hologramDataX)
            hologramManager.addHologram(hologramX)
        }

        val hologramDataX: HologramData? = hologramX.getData()
        if (hologramDataX is TextHologramData) {
            if (x == 1) {
                //Just hiding it somewhere, don't want the weird flicker effect, neither store more data
                hologramDataX.setLocation(playerLoc.clone().add(0.0, 100.0, 0.0))
                hologramDataX.setText(listOf(""))
            } else {
                hologramDataX.setLocation(locationXMiddle)
                hologramDataX.setText(listOf(x.toString() + ""))
            }
        }

        if (hologramY == null) {
            val hologramDataY = TextHologramData(stringY, locationYMiddle)

            hologramDataY.setBackground(Color.fromBGR(100, 255, 100))
            hologramDataY.setText(listOf<String>(y.toString() + ""))
            hologramDataY.setPersistent(false)
            hologramDataY.setSeeThrough(false)
            hologramDataY.setVisibilityDistance(10)
            hologramDataY.setTextUpdateInterval(1)
            hologramDataY.setBrightness(brightness)

            hologramY = hologramManager.create(hologramDataY)
            hologramManager.addHologram(hologramY)
        }
        val hologramDataY: HologramData? = hologramY.getData()
        if (hologramDataY is TextHologramData) {
            if (y == 1) {
                hologramDataY.setLocation(playerLoc.clone().add(0.0, 100.0, 0.0))
                hologramDataY.setText(listOf(""))
            } else {
                hologramDataY.setLocation(locationYMiddle)
                hologramDataY.setText(listOf(y.toString() + ""))
            }
        }

        if (hologramZ == null) {
            val hologramDataZ = TextHologramData(stringZ, locationZMiddle)

            hologramDataZ.setBackground(Color.fromBGR(255, 100, 100))
            hologramDataZ.setText(listOf(z.toString() + ""))
            hologramDataZ.setPersistent(false)
            hologramDataZ.setSeeThrough(false)
            hologramDataZ.setVisibilityDistance(10)
            hologramDataZ.setTextUpdateInterval(1)
            hologramDataZ.setBrightness(brightness)

            hologramZ = hologramManager.create(hologramDataZ)
            hologramManager.addHologram(hologramZ)
        }
        val hologramDataZ: HologramData? = hologramZ.getData()
        if (hologramDataZ is TextHologramData) {
            if (z == 1) {
                hologramDataZ.setLocation(playerLoc.clone().add(0.0, 100.0, 0.0))
                hologramDataZ.setText(listOf(z.toString() + ""))
            } else {
                hologramDataZ.setLocation(locationZMiddle)
                hologramDataZ.setText(listOf(z.toString() + ""))
            }
        }

    }
}