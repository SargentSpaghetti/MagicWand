package com.bryanvalc.magicwand.data.modifier

import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.PlayerUtils
import com.bryanvalc.magicwand.data.PlayerData
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.bukkit.BukkitAdapter
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.transform.AffineTransform
import com.sk89q.worldedit.regions.CuboidRegion
import com.sk89q.worldedit.world.block.BlockState
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Bukkit
import org.bukkit.block.BlockFace
import org.bukkit.entity.Player
import org.bukkit.event.block.Action
import org.bukkit.event.player.PlayerInteractEvent

class RadialArrayModifier(
    var centerX: Int,
    var centerY: Int,
    var centerZ: Int,
    var count: Int,
    var isAlternate: Boolean
) : Modifier {
    override fun apply(
        originalShape: List<Pair<BlockVector3, WrappedBlockState>>,
        forPlayer: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        if (count == 1) {
            return originalShape.toMutableList()
        }


        val rotationStep = 360.0 / count


        val allLocations = ObjectOpenHashSet<BlockVector3>(originalShape.size)
        originalShape.forEach { allLocations.add(it.first) }
        val newCubeMin: BlockVector3 = minBlockVector(*allLocations.toTypedArray<BlockVector3>())
        val newCubeMax: BlockVector3 = maxBlockVector(*allLocations.toTypedArray<BlockVector3>())

        val region = CuboidRegion(newCubeMin, newCubeMax)

        val clipboard = BlockArrayClipboard(region)
        val origin = BlockVector3.at(centerX, centerY, centerZ)
        clipboard.origin = origin

        for (row in originalShape) {
            val blockData = SpigotConversionUtil.toBukkitBlockData(row.second)

            val weBlockState = BukkitAdapter.adapt(blockData)
            clipboard.setBlock<BlockState>(row.first, weBlockState)
        }


        val finalShape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ObjectArrayList(originalShape.size * count)
        var degrees = 0.0
        while (degrees <= 360) {
            val buffer: MutableList<Pair<BlockVector3, WrappedBlockState>> =
                ObjectArrayList((originalShape.size * 1.1).toInt())
            val transform = AffineTransform().rotateY(degrees)
            val tempClipboard = clipboard.transform(transform)

            for (block in tempClipboard.region) {
                val blockState = tempClipboard.getBlock(block)
                val blockData = BukkitAdapter.adapt(blockState)
                if (blockData.material.isAir) continue

                val wrappedBlockState = SpigotConversionUtil.fromBukkitBlockData(blockData)

                buffer.add(Pair(BlockVector3.at(block.x(), block.y(), block.z()), wrappedBlockState))
            }

            finalShape.addAll(buffer)
            degrees += rotationStep
        }
        return finalShape
    }

    override fun handleInteraction(event: PlayerInteractEvent, playerData: PlayerData) {
        val player = event.getPlayer()

        val facing: BlockFace? = PlayerUtils.getFacing(player)
        if (facing == null) {
            return
        }

        val action = event.getAction()

        when (action) {
            Action.LEFT_CLICK_BLOCK, Action.LEFT_CLICK_AIR -> {
                val rayTraceResult = player.rayTraceBlocks(playerData.reach.toDouble())
                if (rayTraceResult == null) {
                    return
                }
                val block = rayTraceResult.hitBlock
                if(block!=null){
                    centerX = block.x
                    centerY = block.y
                    centerZ = block.z
                }
            }

            Action.RIGHT_CLICK_BLOCK, Action.RIGHT_CLICK_AIR -> if (player.isSneaking) {
                this.isAlternate = !this.isAlternate
            } else {
                when (facing) {
                    BlockFace.UP -> this.count += 1
                    BlockFace.DOWN -> if (this.count >= 2) { //safety
                        this.count -= 1
                    }

                    else -> {}
                }
            }

            Action.PHYSICAL -> {}
            }
        }

    override fun display(): Component? {
            val text = "<red>x:" + centerX + " " +
                    "<green>y:" + centerY + " " +
                    "<blue>z:" + centerZ + " " +
                    "<gray> count: " + count +
                    "<gray> alternate: " + (if (this.isAlternate) "yes" else "no") +
                    "<gray>, <white>◀<gray> to define center, <white>▶<gray> to increase count, <white>shift+▶<gray> to toggle alternate"
            return MiniMessage.miniMessage().deserialize(text)
        }
}