package com.bryanvalc.magicwand.context

import com.github.shynixn.mccoroutine.bukkit.launch
import com.bryanvalc.magicwand.context.Display.attemptDraw
import com.bryanvalc.magicwand.data.PlayerData
import com.github.shynixn.mccoroutine.bukkit.asyncDispatcher
import kotlinx.coroutines.delay
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID
import kotlin.math.max

object PacketScheduler: KoinComponent {

    val plugin: JavaPlugin by inject()
    val players: MutableMap<UUID, PlayerData> by inject()

    fun forPlayer(player: Player) {

        plugin.launch(context = plugin.asyncDispatcher) {

            try {
                delay(1_000L)
                var savedTime = System.currentTimeMillis()
                while (player.isOnline) {
                    if (((System.currentTimeMillis() - savedTime) <= 15)) {
                        val timeToSleep = max((16 - (System.currentTimeMillis() - savedTime)), 0)
                        delay(
                            timeToSleep
                        ) //adjust to 60fps lol
                    }
                    savedTime = System.currentTimeMillis()
                    val uuid = player.uniqueId
                    val playerData: PlayerData? = players[uuid]
                    if (playerData == null) break

                    attemptDraw(player, playerData)

                }
            } catch (e: Exception) {
                TODO("Not yet implemented")
            }
        }

    }
}