package com.bryanvalc.magicwand

import com.bryanvalc.magicwand.data.PlayerData
import org.bstats.bukkit.Metrics
import org.bstats.charts.AdvancedPie
import org.bstats.charts.SingleLineChart
import org.bukkit.Bukkit
import org.bukkit.Material
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.*
import java.util.concurrent.Callable
import kotlin.math.roundToInt


object CustomMetrics: KoinComponent {

    val players: MutableMap<UUID, PlayerData> by inject()

    fun addCustomMetrics(baseMetrics: Metrics) {

        baseMetrics.addCustomChart(AdvancedPie("most_used_brushes", object : Callable<MutableMap<String?, Int?>?> {
            @Throws(java.lang.Exception::class)
            override fun call(): MutableMap<String?, Int?> {
                val valueMap: MutableMap<String?, Int?> = HashMap<String?, Int?>()

                val datas = players.values.toList()

                val mapped = datas.asSequence().groupBy {
                    it.mode?.name ?: "none"
                }.toMutableMap()
                mapped.remove("none")

                for (data in mapped) {
                    valueMap.put(data.key, data.value.size)
                }

                return valueMap
            }
        }))

        //maybe when I want to truly show off
//        baseMetrics.addCustomChart(SingleLineChart("millions_blocks_changed", object : Callable<Int> {
//            @Throws(Exception::class)
//            override fun call(): Int {
//                var total = 0L
//                for (offlinePlayer in Bukkit.getOfflinePlayers()) {
//                    var playerDataOriginal: PlayerData? = players[offlinePlayer.uniqueId]
//                    if (playerDataOriginal == null) { //we load from database, but we won't put in the list
//                        playerDataOriginal = PlayerData(offlinePlayer.uniqueId)
////                        playerDataOriginal = PlayerDao.loadPlayerSettings(playerDataOriginal)
//                    }
//
//                    total += playerDataOriginal.allTimePlaced
//                }
//
//                return (total.toFloat() / 1_000_000).roundToInt()
//            }
//        }))
    }
}