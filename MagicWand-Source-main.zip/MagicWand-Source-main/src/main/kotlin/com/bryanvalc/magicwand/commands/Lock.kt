package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.module.MaterialList
import com.bryanvalc.magicwand.module.MaterialRegistry
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission
import java.util.UUID

class Lock: KoinComponent {

    val plugin: JavaPlugin by inject()
    val players: MutableMap<UUID, PlayerData> by inject()

    @Command("lock")
    @CommandPermission("magicwand.lock")
    fun lockVersion(
        actor: BukkitCommandActor,
        palette: MaterialList
    ){
        val sender = actor.sender()
        if (sender !is Player) {
            return
        }
        val player = sender as Player

        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return


        playerDataOriginal.versionLock = palette.name

        val message = player.getLanguagePack()?.versionLock
            ?: "§2Your materials have been locked to version \$version"
        player.sendParsed(message.replace("\$version", palette.name))

    }


}