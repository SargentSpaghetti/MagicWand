package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.bresenham3D
import com.bryanvalc.magicwand.context.BlockVectorUtils.stacker
import com.bryanvalc.magicwand.context.effects.Hull
import com.bryanvalc.magicwand.context.fakeToBlockPoint
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.Distance
import com.bryanvalc.magicwand.targets.implementations.ExtendAny
import com.bryanvalc.magicwand.targets.implementations.HitWall
import com.bryanvalc.magicwand.targets.implementations.HitY
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.Vector3
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*

class ExtendedSlope : Mode(), Configurable {
    init {
        name = "extendedSlope"
        permission = "mode.extendedslope"
        materialMenu = Material.AMETHYST_SHARD
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/extended-slope"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        if (clickLocations.size <= 3) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocations.add(pivot)
            }
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        var shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        val placements = ObjectOpenHashSet<BlockVector3>(16 + ((playerData.newBlocks.size * 1.25).toInt()))

        val menu = forPlayer(playerData)
        val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"

        if (clickLocations.size == 1) {
            val location = clickLocations[0]
            putBlock(shape, location, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
            return shape
        } else if (clickLocations.size == 2) {
            val firstBlock = clickLocations[0].toVector3().add(0.5, 0.5, 0.5)
            val lastBlock = clickLocations[1].toVector3().add(0.5, 0.5, 0.5)

            val prediction: MutableList<Vector3> = bresenham3D(firstBlock, lastBlock)
            for (block in prediction) {
                placements.add(block.fakeToBlockPoint())
            }
        } else if (clickLocations.size in 3..4) {
            val firstBlock = clickLocations[0].toVector3().add(0.5, 0.5, 0.5)
            val secondBlock = clickLocations[1].toVector3().add(0.5, 0.5, 0.5)
            val thirdBlock = clickLocations[2].toVector3().add(0.5, 0.5, 0.5)

            val firstLine: MutableList<Vector3> = bresenham3D(firstBlock, secondBlock)

            var secondPredictionVec: MutableList<Vector3> =
                ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))

            when(filling) {
                "walls" -> {
                    val offsetToSecond = secondBlock.subtract(firstBlock)
                    val virtualFourthPosition = thirdBlock.subtract(offsetToSecond)
                    val secondLine = bresenham3D(secondBlock, thirdBlock)
                    val thirdLine = bresenham3D(thirdBlock, virtualFourthPosition)
                    val fourthLine = bresenham3D(firstBlock, virtualFourthPosition)
                    secondPredictionVec.addAll(firstLine)
                    secondPredictionVec.addAll(secondLine)
                    secondPredictionVec.addAll(thirdLine)
                    secondPredictionVec.addAll(fourthLine)
                }
                else -> {
                    secondPredictionVec = stacker(firstLine, secondBlock, thirdBlock)
                }
            }

            if (clickLocations.size==4) {
                val fourthBlock = clickLocations[3].toVector3().add(0.5, 0.5, 0.5)

                secondPredictionVec = stacker(secondPredictionVec, thirdBlock, fourthBlock)
            }

            for (block in secondPredictionVec) {
                placements.add(block.fakeToBlockPoint())
            }
        }

        for(block in placements) {
            shape.add(Pair(block, blockData))
        }

        when(filling) {
            "hollow" -> {
                shape = Hull(6,6).apply(shape)
            }
            else -> {}
        }

        val shapeFinal: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(shape.size)

        for(block in shape) {
            putBlock(
                shapeFinal,
                block.first,
                block.second,
                world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )
        }

        return shapeFinal
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {

        val menu = forPlayer(playerData)
        val lock = (menu?.propertyByName("facing") as EnumProperty?)?.value?:"floor"

        val order = when(lock) {
            "floor" -> ArrayList(listOf(Block(), HitY(), ExtendAny(), Distance()))
            "wall" -> ArrayList(listOf(Block(), HitWall(), ExtendAny(), Distance()))
            else -> ArrayList(listOf(Block(), Distance(), Distance(), Distance()))
        }

        return order
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "facing",
                    material = Material.QUARTZ,
                    lore = "facing.lore",
                    model = null,
                    value = "floor", options = listOf("any", "floor", "wall"),
                    models = mapOf(
                        "any" to 1,
                        "floor" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 3, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = null,
                    value = "full", options = listOf("full", "walls", "hollow"),
                    models = mapOf(
                        "full" to 1,
                        "walls" to 2,
                        "hollow" to 3,
                        "skeleton" to 4
                    )
                )
            ),
            3
        )
    }
}