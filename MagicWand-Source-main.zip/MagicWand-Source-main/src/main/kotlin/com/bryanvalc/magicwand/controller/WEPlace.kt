package com.bryanvalc.magicwand.controller

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.LocalSession
import com.sk89q.worldedit.WorldEdit
import com.sk89q.worldedit.bukkit.BukkitAdapter
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

object WEPlace: KoinComponent {

    private val plugin: JavaPlugin by inject()

    fun place(player: Player, newBlocks: List<Pair<BlockVector3, WrappedBlockState>>) {

        val wePlayer: com.sk89q.worldedit.entity.Player = BukkitAdapter.adapt(player)
        val manager = WorldEdit.getInstance().sessionManager
        val localSession = manager.get(wePlayer)

        if(localSession == null) {
            plugin.logger.severe { "Couldn't find session for ${player.name}" }
            return
        }

        try {
            WorldEdit.getInstance().newEditSession(wePlayer).use { editSession ->
                for (row in newBlocks) {
                    val blockData = SpigotConversionUtil.toBukkitBlockData(row.second)
                    editSession.setBlock(row.first, BukkitAdapter.adapt(blockData))
                }
                localSession.remember(editSession)
            }
        } catch (e: Exception) {
            plugin.logger.severe(e.message)
        }
    }
}