package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.fakeEquals
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.data.PortableSchem
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.BooleanProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.AutoSwitch
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.PreOperation
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.BlockExact
import com.bryanvalc.magicwand.targets.implementations.Distance
import com.bryanvalc.magicwand.utils.PortableSchemStore
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.bukkit.BukkitAdapter
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard
import com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.regions.CuboidRegion
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.inventory.ItemStack
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.*

class Copy : Mode(), PreOperation, AutoSwitch, Configurable {
    init {
        name = "copy"
        permission = "mode.copy"
        materialMenu = Material.POTATO
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/copy"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        val pivot = playerData.pivot
        if(pivot!=null){
            clickLocations.add(pivot)
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val world = player.world

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        if (clickLocations.size <= 2) {
            val newCubeMin: BlockVector3 = minBlockVector(*clickLocations.toTypedArray<BlockVector3>())
            val newCubeMax: BlockVector3 = maxBlockVector(*clickLocations.toTypedArray<BlockVector3>())

            val minX = newCubeMin.x()
            val minY = newCubeMin.y()
            val minZ = newCubeMin.z()
            val maxX = newCubeMax.x()
            val maxY = newCubeMax.y()
            val maxZ = newCubeMax.z()

            // TODO: not a single case is special, but should do for now
            val wrappedBlockState = SpigotConversionUtil.fromBukkitBlockData(Material.BLUE_STAINED_GLASS.createBlockData())

            val menu = forPlayer(playerData)
            val previewOnlyAir = (menu?.propertyByName("preview") as BooleanProperty?)?.value != false

            for (x in minX..maxX) {
                for (y in minY..maxY) {
                    for (z in minZ..maxZ) {
                        if (previewOnlyAir) {
                            if(world.getBlockData(x, y, z).material.isAir) {
                                putBlock(shape, BlockVector3.at(x, y, z), wrappedBlockState, world, true, true, true, true)
                            }
                        } else {
                            putBlock(shape, BlockVector3.at(x, y, z), wrappedBlockState, world, true, true, true, true)
                        }
                    }
                }
            }
        } else if (clickLocations.size == 3) {
            val locationsCopy: MutableList<BlockVector3> = ArrayList<BlockVector3>(clickLocations)
            val lastClick = locationsCopy.removeLast()
            val newCubeMin: BlockVector3 = minBlockVector(*locationsCopy.toTypedArray<BlockVector3>())
            val newCubeMax: BlockVector3 = maxBlockVector(*locationsCopy.toTypedArray<BlockVector3>())

            val minX = newCubeMin.x()
            val minY = newCubeMin.y()
            val minZ = newCubeMin.z()
            val maxX = newCubeMax.x()
            val maxY = newCubeMax.y()
            val maxZ = newCubeMax.z()

            // TODO: not a single case is special, but should do for now
            val wrappedBlockState = SpigotConversionUtil.fromBukkitBlockData(Material.BLUE_STAINED_GLASS.createBlockData())

            for (x in minX..maxX) {
                for (y in minY..maxY) {
                    for (z in minZ..maxZ) {
                        if (world.getBlockData(x, y, z).material.isAir
                        ) { //override so we can see the glass no matter what
                            putBlock(shape, BlockVector3.at(x, y, z), wrappedBlockState, world, true, true, true, true)
                        }
                    }
                }
            }
            val wrappedBlockStateShroom = SpigotConversionUtil.fromBukkitBlockData(Material.SHROOMLIGHT.createBlockData())
            putBlock(shape, lastClick, wrappedBlockStateShroom, world, true, true, true, true)
        }

        return shape
    }

    override fun exec(player: Player, playerData: PlayerData) {

        val clicks: MutableList<ClickData> = playerData.clicks

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        val pivot = playerData.pivot
        if(pivot!=null){
            clickLocations.add(pivot)
        }

        if (clickLocations.isEmpty()) {
            return
        }

        val world = player.world
        if (clickLocations.size <= 4) {
            val locationsCopy: MutableList<BlockVector3> = ArrayList<BlockVector3>(clickLocations)
            val lastClick = locationsCopy.removeLast()

            val locationsCopyLast = locationsCopy.lastOrNull()
            if(locationsCopyLast==null) return

            if (locationsCopyLast.fakeEquals(lastClick)) {
                locationsCopy.removeLast()
            }

            val newCubeMin: BlockVector3 = minBlockVector(*locationsCopy.toTypedArray<BlockVector3>())
            val newCubeMax: BlockVector3 = maxBlockVector(*locationsCopy.toTypedArray<BlockVector3>())

            val region = CuboidRegion(newCubeMin, newCubeMax)

            val clipboard = BlockArrayClipboard(region)
            clipboard.origin = lastClick

            // Copy blocks from the world into the clipboard
            for (pos in region) {
                val bukkitBlock = world.getBlockAt(pos.x(), pos.y(), pos.z())
                val weBlockState = BukkitAdapter.adapt(bukkitBlock.blockData)
                clipboard.setBlock(pos, weBlockState)
            }

            val outputStream = ByteArrayOutputStream()
            try {
                BuiltInClipboardFormat.SPONGE_V3_SCHEMATIC.getWriter(outputStream).use { writer ->
                    writer.write(clipboard)
                }
            } catch (e: IOException) {
                throw RuntimeException("Failed to save schematic", e)
            }


            var itemStack = player.inventory.itemInMainHand

            if (itemStack.type == Material.AIR) {
                val blockDist = clipboard.getBlockDistribution(region)
                var biggestCount = blockDist.removeLast().getID()
                var data = BukkitAdapter.adapt(biggestCount.itemType)
                if (data == Material.AIR) {
                    biggestCount = blockDist.removeLast().getID()
                    data = BukkitAdapter.adapt(biggestCount.itemType)
                }

                player.inventory.setItemInMainHand(ItemStack(data))
            }
            itemStack = player.inventory.itemInMainHand

            val playerFacing = player.facing

            val portableSchem = PortableSchem(playerFacing.name, outputStream.toByteArray())
            PortableSchemStore.write(itemStack, portableSchem)

        }
    }

    override fun switch(): String {
        return "paste"
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                BooleanProperty(
                    row = 1, column = 1, name = "preview",
                    material = Material.ENDER_EYE,
                    lore = "preview.lore",
                    model = 1,
                    overrideDisplays = mapOf(
                        true to "only.air",
                        false to "all.blocks"
                    ),
                    models = mapOf(
                        true to 1,
                        false to 2
                    )
                )
            ),
            3
        )
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList(listOf(Block(), Distance(), BlockExact()))
    }
}