package com.bryanvalc.magicwand.context

import com.sk89q.worldedit.function.RegionFunction
import com.sk89q.worldedit.function.operation.Operations
import com.sk89q.worldedit.function.visitor.RegionVisitor
import com.sk89q.worldedit.internal.expression.EvaluationException
import com.sk89q.worldedit.internal.expression.Expression
import com.sk89q.worldedit.internal.expression.ExpressionException
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.regions.CuboidRegion
import com.sk89q.worldedit.regions.shape.WorldEditExpressionEnvironment
import com.sk89q.worldedit.world.World
import com.sk89q.worldedit.world.registry.LegacyMapper
import it.unimi.dsi.fastutil.objects.ReferenceArrayList

object VirtualTransform {
    @Throws(ExpressionException::class, EvaluationException::class)
    fun getShape(
        min: BlockVector3,
        max: BlockVector3,
        world: World,
        expression: String
    ): MutableList<BlockVector3> {
        val region = CuboidRegion(world, min, max)
        val zero = min.toVector3()
        val unit = max.subtract(min).toVector3()

        val compiledExpr = Expression.compile(expression, "x", "y", "z", "type", "data")
        compiledExpr.optimize()

        val env = WorldEditExpressionEnvironment(world, unit, zero)
        compiledExpr.environment = env

        val results: MutableList<BlockVector3> = ReferenceArrayList<BlockVector3>()

        val visitor = RegionVisitor(
            region,
            RegionFunction { position: BlockVector3 ->
                try {
                    val state = world.getBlock(position)
                    val legacyIds = LegacyMapper.getInstance().getLegacyFromBlock(state)

                    // FIXED: Normalize to [-1, 1] instead of [0, 1]
                    val scaled = position.toVector3()
                        .subtract(zero)
                        .divide(unit)
                        .multiply(2.0)
                        .subtract(1.0, 1.0, 1.0) // Key fix here

                    val evalResult = compiledExpr.evaluate(
                        scaled.x(),
                        scaled.y(),
                        scaled.z(),
                        (if (legacyIds != null) legacyIds[0] else 0).toDouble(),
                        (if (legacyIds != null && legacyIds.size > 1) legacyIds[1] else 0).toDouble()
                    )

                    if (evalResult > 0) {
                        results.add(BlockVector3.at(position.x(), position.y(), position.z()))
                    }
                } catch (e: EvaluationException) {
                    throw RuntimeException("Evaluation failed at $position", e)
                }
                true
            }
        )

        Operations.complete(visitor)
        return results
    }
}