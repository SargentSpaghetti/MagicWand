package com.bryanvalc.magicwand.placeholders

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.storage.PlayerDao
import me.clip.placeholderapi.expansion.PlaceholderExpansion
import org.bukkit.OfflinePlayer
import org.bukkit.entity.Player
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID

class Placing : PlaceholderExpansion(), KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()

    override fun getAuthor(): String {
        return "BryanValc" //
    }

    override fun getIdentifier(): String {
        return "placing"
    }

    override fun getVersion(): String {
        return "1.0.0"
    }

    override fun onRequest(player: OfflinePlayer, params: String): String? {
        val uuid = player.uniqueId
        var playerData: PlayerData? = players[uuid]
        if (playerData == null) { playerData = PlayerData(uuid) }
        val player1 = player.player
        if (player1 == null) { playerData = PlayerDao.load(playerData) }

        val current = playerData.placedNow
        var limit = playerData.placingLimit
        if(limit==-1L){
            limit = Long.MAX_VALUE
        }

        if (params.equals("current", ignoreCase = true)) {
            return current.toString() + ""
        }

        if (params.equals("limit", ignoreCase = true)) {
            return limit.toString() + ""
        }

        if (params.equals("remaining", ignoreCase = true)) {
            return (limit - current).toString() + ""
        }

        if (params.equals("percent", ignoreCase = true)) {
            val percent = ((limit - current).toDouble() / limit) * 100.0
            return String.format("%.2f", percent)
        }

        return null
    }

    override fun onPlaceholderRequest(player: Player, params: String): String? {
        val uuid = player.uniqueId
        var playerData: PlayerData? = players[uuid]
        if (playerData == null) { playerData = PlayerData(uuid) }
        val player1 = player.player
        if (player1 == null) { playerData = PlayerDao.load(playerData) }

        val current = playerData.placedNow
        var limit = playerData.placingLimit
        if(limit==-1L){
            limit = Long.MAX_VALUE
        }

        if (params.equals("current", ignoreCase = true)) {
            return current.toString() + ""
        }

        if (params.equals("limit", ignoreCase = true)) {
            return limit.toString() + ""
        }

        if (params.equals("remaining", ignoreCase = true)) {
            return (limit - current).toString() + ""
        }

        if (params.equals("percent", ignoreCase = true)) {
            val percent = ((limit - current).toDouble() / limit) * 100.0
            return String.format("%.2f", percent)
        }

        return null
    }
}