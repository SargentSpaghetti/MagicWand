package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.fakeEquals
import com.bryanvalc.magicwand.context.fakeToBlockPoint
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.utils.Coloring
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.Vector3
import com.sk89q.worldedit.math.interpolation.KochanekBartelsInterpolation
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.World
import org.bukkit.entity.Player

import java.util.*


class Vine : Mode(), Multicolor {
    init {
        name = "vine"
        permission = "mode.vine"
        materialMenu = Material.LEAD
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/vine"
    }

    val timeoutMs = 1_000

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> ? {
        val startTime = System.currentTimeMillis()


        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        val pivot = playerData.pivot
        if(pivot!=null){
            clickLocations.add(pivot)
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world


        if (clickLocations.size == 1) {
            putBlock(
                shape,
                clickLocations[0],
                blockData,
                world,
                replaceAir,
                replaceSolid,
                replaceSoft,
                replaceLiquid
            )
            return shape
        }

        val start = clickLocations[0]
        val end: BlockVector3 = clickLocations[1]

        // Calculate bounding box
        val min: BlockVector3 = minBlockVector(start, end).subtract(EXPANSION, EXPANSION, EXPANSION)
        val max: BlockVector3 = maxBlockVector(start, end).add(EXPANSION, EXPANSION, EXPANSION)


        // Find path using A* algorithm
        val pathRaw = findPath(player.world, start, end, min, max, startTime)
        if (pathRaw == null) {
            return null
        } else if (pathRaw.isEmpty()) {
            return null
        }


        val pathInterpolated: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        val nodeGroup: MutableList<com.sk89q.worldedit.math.interpolation.Node> =
            ArrayList<com.sk89q.worldedit.math.interpolation.Node>()
//        run {
        var index = 0.0
        while (index < pathRaw.size) {
            if ((index % 7).toInt() != 0 && index != pathRaw.size.toDouble() - 1) {
                index += 1
                continue
            }
            val block = pathRaw[index.toInt()]
            val vector = Vector3.at(block.x() + 0.5, block.y() + 0.5, block.z() + 0.5)
            val newNode = com.sk89q.worldedit.math.interpolation.Node(vector)
            newNode.tension = -1.0
            nodeGroup.add(newNode)
            index += 1
        }
//        }
        nodeGroup.firstOrNull()?.tension = 0.0
        nodeGroup.lastOrNull()?.tension = 0.0

        val interpolation = KochanekBartelsInterpolation()
        interpolation.setNodes(nodeGroup)

        var i = 0.0
        while (i <= 1) {
            val floatingPoint = interpolation.getPosition(i)
            pathInterpolated.add(floatingPoint.fakeToBlockPoint())
            i += 0.002
        }


        // Add path to shape
        for (point in pathInterpolated) {
            putBlock(shape, point, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
        }

        return shape
    }

    private fun findPath(
        world: World,
        start: BlockVector3,
        end: BlockVector3,
        min: BlockVector3,
        max: BlockVector3,
        startTime: Long
    ): MutableList<BlockVector3>? {
        if (System.currentTimeMillis() - startTime > timeoutMs) return null

        val openSet = PriorityQueue<Node>()
        val closedSet: MutableSet<BlockVector3> = HashSet<BlockVector3>()
        val allNodes: MutableMap<BlockVector3, Node> = HashMap<BlockVector3, Node>()

        val startNode = Node(start, null, 0.0, heuristic(start, end))
        openSet.add(startNode)
        allNodes.put(start, startNode)

        while (openSet.isNotEmpty()) {
            if (System.currentTimeMillis() - startTime > timeoutMs) return null
            val current = openSet.poll()

            if (current.pos.fakeEquals(end)) {
                return reconstructPath(current, startTime)
            }

            closedSet.add(current.pos)

            val neighbors = getNeighbors(world, current.pos, min, max, startTime)
            if (neighbors == null) {
                return null
            }

            for (neighbor in neighbors) {
                if (System.currentTimeMillis() - startTime > timeoutMs) return null
                if (closedSet.contains(neighbor)) {
                    continue
                }

                val tentativeGScore = current.gScore + 1

                var neighborNode = allNodes[neighbor]
                if (neighborNode == null) {
                    neighborNode = Node(neighbor, current, tentativeGScore, heuristic(neighbor, end))
                    allNodes.put(neighbor, neighborNode)
                    openSet.add(neighborNode)
                } else if (tentativeGScore < neighborNode.gScore) {
                    neighborNode.parent = current
                    neighborNode.gScore = tentativeGScore
                    neighborNode.fScore = neighborNode.gScore + neighborNode.hScore
                    openSet.remove(neighborNode)
                    openSet.add(neighborNode)
                }
            }
        }

        return ArrayList<BlockVector3>() // No path found
    }

    private fun getNeighbors(
        world: World,
        pos: BlockVector3,
        min: BlockVector3,
        max: BlockVector3,
        startTime: Long
    ): MutableList<BlockVector3>? {
        val neighbors: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (dx in -1..1) {
            for (dy in -1..1) {
                for (dz in -1..1) {
                    if (System.currentTimeMillis() - startTime > timeoutMs) return null
                    if (dx == 0 && dy == 0 && dz == 0) continue
                    val neighbor = pos.add(dx, dy, dz)
                    if (isWithinBounds(neighbor, min, max) && isValidBlock(world, neighbor)) {
                        neighbors.add(neighbor)
                    }
                }
            }
        }
        return neighbors
    }

    private fun isWithinBounds(pos: BlockVector3, min: BlockVector3, max: BlockVector3): Boolean {
        return pos.x() >= min.x() && pos.x() <= max.x() && pos.y() >= min.y() && pos.y() <= max.y() && pos.z() >= min.z() && pos.z() <= max.z()
    }

    private fun isValidBlock(world: World, pos: BlockVector3): Boolean {
        if (world.getBlockAt(pos.x(), pos.y(), pos.z()).type.isAir()) {
            for (dx in -1..1) {
                for (dy in -1..1) {
                    for (dz in -1..1) {
                        if (dx == 0 && dy == 0 && dz == 0) continue
                        val neighbor = pos.add(dx, dy, dz)
                        if (!world.getBlockAt(neighbor.x(), neighbor.y(), neighbor.z()).type.isAir()) {
                            return true
                        }
                    }
                }
            }
        }
        return false
    }

    private fun heuristic(a: BlockVector3, b: BlockVector3): Double {
        return a.distance(b)
    }

    private fun reconstructPath(end: Node, startTime: Long): MutableList<BlockVector3>? {
        val path: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        var current: Node? = end
        while (current != null) {
            if (System.currentTimeMillis() - startTime > timeoutMs) return null
            path.add(current.pos)
            current = current.parent
        }
        path.reverse()
        return path
    }

    private class Node(var pos: BlockVector3, var parent: Node?, var gScore: Double, var hScore: Double) :
        Comparable<Node> {
        var fScore: Double = gScore + hScore

        override fun compareTo(other: Node): Int {
            return this.fScore.compareTo(other.fScore)
        }
    }

    override fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        return Coloring.falloffGradient(originalMesh, player, playerData)
    }

    companion object {
        private const val EXPANSION = 20
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList<Target>(listOf(Block(), Block()))
    }

}