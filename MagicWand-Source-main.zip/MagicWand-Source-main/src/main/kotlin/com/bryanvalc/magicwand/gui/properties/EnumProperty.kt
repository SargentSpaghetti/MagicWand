package com.bryanvalc.magicwand.gui.properties

import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.TextFormatter
import com.bryanvalc.magicwand.utils.platform.Mediator
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.inventory.ItemStack
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class EnumProperty(row: Int, column: Int, name: String, material: Material, lore: String, model: Int?,
                   var value: String,
                   var options: List<String>,
                   var materials: Map<String, Material>? = null,
                   var models: Map<String, Int>? = null
):
    Property(row, column, name, material, lore, model) {
    override fun handleLeftClick(event: InventoryClickEvent) {
        if(options.isNullOrEmpty()) return

        var nextValue =  if (!options.contains(value)) {
            options[0]
        } else {
            options[(options.indexOf(value)+1)%options.size]
        }

        value = nextValue
    }

    override fun handleRightClick(event: InventoryClickEvent) {
        if(options.isNullOrEmpty()) return

        if (!options.contains(value)) {
            value = options[0]
        } else {
            var index = options.indexOf(value)-1
            if(index<=-1) {index=options.size-1}

            value = options[max((index%options.size),0)]
        }
    }

    override fun printableValue(): String {
        return value
    }

    override fun updateMaterial(): Material? {
        val locked = materials
        if (locked.isNullOrEmpty()) return material

        val newMaterial = locked[value]
        if (newMaterial != null) {
            material = newMaterial
        }

        return material


    }

    override fun updateModel(): Int? {
        val locked = models
        if (locked.isNullOrEmpty()) return model

        val newModel = locked[value]

        if (newModel != null) {
            model = newModel
        }
        return model


    }

    override fun getItem(player: Player): ItemStack {
        updateModel()
        updateMaterial()

        var itemStack = ItemStack(material)
        var meta = itemStack.itemMeta

        var nameStr = "No translation found for $name"
        var loreStr = "No translation found for $lore"
        var printableStr = "No translation found for ${printableValue()}"
        val languagePack = player.getLanguagePack()
        languagePack?.let {
            nameStr = it.subMenus[name] ?: nameStr
            loreStr = it.subMenus[lore] ?: loreStr
            printableStr = it.subMenus[printableValue()] ?: printableStr
        }

        Mediator.displayName(meta, "<#4d65b4>$nameStr: <#f57d4a>$printableStr")

        val baseLore = TextFormatter.createComponents(loreStr, 30, "<#6b3e75>")
        baseLore.add(Component.text(""))

        if (options.size <= 9) {
            for(item in options) {
                var itemStr = "No translation found for $item"
                languagePack?.let {
                    itemStr = it.subMenus[item] ?: itemStr
                }
                if(item==value) {
                    baseLore.add(MiniMessage.miniMessage().deserialize("<#4d9be6>$itemStr"))
                } else {
                    baseLore.add(MiniMessage.miniMessage().deserialize("<#484a77>$itemStr"))
                }
            }
        } else {
            val size = options.size
            val index = options.indexOf(value)
            val steps = 4

            val tailingStart = if (index+steps+1 > size) {
                (index+steps+1)%(size)
            } else {
                0
            }

            val tailingEnd = if (index < steps) {
                abs(index - steps)
            } else {
                0
            }

            val start = max(index-steps, 0)
            val end = min(index+steps+1, size)

            val subList = mutableListOf<String>()

            if (tailingEnd!=0) {
                subList.addAll(options.subList(size-tailingEnd, size))
            }
            subList.addAll(options.subList(start, end))
            if (tailingStart!=0) {
                subList.addAll(options.subList(0, tailingStart))
            }

            for(item in subList) {
                var itemStr = "No translation found for $item"
                languagePack?.let {
                    itemStr = it.subMenus[item] ?: itemStr
                }
                if(item==value) {
                    baseLore.add(MiniMessage.miniMessage().deserialize("<#4d9be6>$itemStr"))
                } else {
                    baseLore.add(MiniMessage.miniMessage().deserialize("<#484a77>$itemStr"))
                }
            }
        }

        Mediator.lore(meta, baseLore)

        meta.setCustomModelData(model)

        itemStack.setItemMeta(meta)

        return itemStack
    }

}