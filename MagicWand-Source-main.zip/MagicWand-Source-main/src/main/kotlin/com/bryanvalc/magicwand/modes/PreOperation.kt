package com.bryanvalc.magicwand.modes

import com.bryanvalc.magicwand.data.PlayerData
import org.bukkit.entity.Player

interface PreOperation {
    fun exec(player: Player, playerData: PlayerData)
}