package com.bryanvalc.magicwand.utils

import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage

object TextFormatter {
    fun createComponents(text: String, maxLength: Int, prefix: String?=""): MutableList<Component> {
        val components: MutableList<Component> = ArrayList<Component>()
        val words = text.split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        val currentLine = StringBuilder()

        for (word in words) {
            // Check if adding the next word exceeds the maxLength
            if (currentLine.length + word.length + 1 > maxLength && currentLine.isNotEmpty()) {
                // Add the current line to components if it's not empty
                components.add(MiniMessage.miniMessage().deserialize(prefix+currentLine.toString()))
                currentLine.setLength(0) // Reset for next line
            }
            // Add the word to the current line
            if (currentLine.isNotEmpty()) {
                currentLine.append(" ") // Add space before the word
            }
            currentLine.append(word)
        }

        // Add any remaining text as a final line
        if (currentLine.isNotEmpty()) {
            components.add(MiniMessage.miniMessage().deserialize(prefix+currentLine.toString()))
        }

        return components
    }
}