package com.bryanvalc.magicwand.module

import com.sk89q.worldedit.bukkit.WorldEditPlugin
import com.sk89q.worldguard.bukkit.WorldGuardPlugin
import de.oliver.fancyholograms.api.FancyHologramsPlugin
import de.oliver.fancyholograms.api.HologramManager
import net.luckperms.api.LuckPerms
import net.luckperms.api.LuckPermsProvider
import org.bukkit.Bukkit
import org.bukkit.plugin.Plugin
import org.bukkit.plugin.java.JavaPlugin

class PluginRepository(
    private val basePlugin: JavaPlugin
) {
    var packetEventsEnabled = true
    var worldEditPlugin: WorldEditPlugin? = null
    var faweEnabled: Boolean = true
    var griefDefenderEnabled: Boolean = false
    var worldGuardPlugin: WorldGuardPlugin? = null
    var plotPlugin: JavaPlugin? = null
    var luckPermsInstance: LuckPerms? = null
    var hologramManager: HologramManager? = null
    var placeholderApi: Plugin? = null

    fun setup() {
        val logger = basePlugin.logger

        worldEditPlugin = Bukkit.getPluginManager().getPlugin("WorldEdit") as WorldEditPlugin?
        if (worldEditPlugin == null) {
            logger.severe("FastAsyncWorldEdit seems to be missing, please add it to the plugins directory")
        }

        worldGuardPlugin = Bukkit.getPluginManager().getPlugin("WorldGuard") as WorldGuardPlugin?
        if (worldGuardPlugin == null) {
//            logger.warning("WorldGuard seems to be missing, beware players might break stuff at will")
        }

        val plotPlugin = Bukkit.getPluginManager().getPlugin("LuckPerms")
        if (plotPlugin == null) {
//            logger.info("PlotSquared seems to be missing, if you plan to monetize you might wanna add it")
        }

        val luckPerms = Bukkit.getPluginManager().getPlugin("LuckPerms")
        if (luckPerms != null) {
            luckPermsInstance = LuckPermsProvider.get()
        } else {
//            logger.info("LuckPerms seems to be missing, if you plan to monetize you might wanna add it")
        }

        val fancyHolograms = Bukkit.getPluginManager().getPlugin("FancyHolograms")
        if (fancyHolograms == null) {
            logger.severe("FancyHolograms seems to be missing, some visual effects won't be visible.")
        } else {
            hologramManager = FancyHologramsPlugin.get().hologramManager
        }

        placeholderApi = Bukkit.getPluginManager().getPlugin("PlaceholderAPI")

        val fawe = Bukkit.getPluginManager().getPlugin("FastAsyncWorldEdit")
        if (fawe == null) {
            faweEnabled = false
            logger.warning("FastAsyncWorldEdit not detected, it is preferred over normal WorldEdit.")
        }

        val griefDefender = Bukkit.getPluginManager().getPlugin("GriefDefender")
        if (griefDefender != null) {
            griefDefenderEnabled = true
        }

    }

}