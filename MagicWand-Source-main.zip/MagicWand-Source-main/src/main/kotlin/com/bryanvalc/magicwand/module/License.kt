package com.bryanvalc.magicwand.module

import com.bryanvalc.magicwand.module.config.Configuration
import dev.respark.licensegate.LicenseGate

class License(
    private val config: Configuration
) {
    var cachedResult = true
        private set

    fun validate() {

        cachedResult = true
    }

}