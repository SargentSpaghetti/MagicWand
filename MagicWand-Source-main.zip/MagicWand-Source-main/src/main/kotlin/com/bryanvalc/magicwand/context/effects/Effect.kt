package com.bryanvalc.magicwand.context.effects

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3

interface Effect {

    fun apply(original: List<Pair<BlockVector3, WrappedBlockState>>): MutableList<Pair<BlockVector3, WrappedBlockState>>

}