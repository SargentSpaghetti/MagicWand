package com.bryanvalc.magicwand.utils

import com.bryanvalc.magicwand.context.BlockVectorUtils.getCleanSphereBlock
import com.bryanvalc.magicwand.context.PlayerUtils.serveBlockData
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.FluidCollisionMode
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*
import java.util.function.ToDoubleFunction
import java.util.stream.Collectors
import kotlin.math.max

object Coloring {

    fun falloffGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        val world = player.world

        val rayTraceResult = player.rayTraceBlocks(1000.0, FluidCollisionMode.NEVER)
        var blockData = serveBlockData(player, rayTraceResult, playerData)

        var lastBlockData: WrappedBlockState
        if (blockData == null) {
            lastBlockData = playerData.blockData?: SpigotConversionUtil.fromBukkitBlockData(Material.AIR.createBlockData())
        } else {
            lastBlockData = SpigotConversionUtil.fromBukkitBlockData(blockData)
        }

        val lastLocation = playerData.pivot

        val clickDataList = playerData.clicks
        val buffer: MutableList<ClickData> = ObjectArrayList<ClickData>(clickDataList)

        // to make things easier for me
        val floatingTarget = playerData.floatingTarget
        if(lastLocation!=null && floatingTarget!=null){
            val newClick = ClickData(
                playerData.targetIndex,
                playerData.targetSubIndex,
                lastLocation,
                floatingTarget,
                player.location.clone(),
                playerData.brushSize,
                lastBlockData
            )
            buffer.add(newClick)
        }

        if(buffer.isEmpty()){
            return originalMesh.toMutableList()
        }

        val tempSet: MutableSet<WrappedBlockState> = ObjectOpenHashSet<WrappedBlockState>()
        for (item in buffer) {
            tempSet.add(item.blockData)
        }
        if (tempSet.size == 1) { //there's no point in attempting to create a gradient
            return originalMesh.toMutableList()
        }

        val radius = playerData.falloffStrength / 5 //we don't want to get too crazy
        val chance = playerData.mixingStrength

        val tempMap: MutableMap<BlockVector3, WrappedBlockState> =
            Object2ObjectOpenHashMap(originalMesh.size) //convert to hashmap
        for (row in originalMesh) {
            tempMap.put(row.first, row.second)
        }

        for (row in originalMesh) { //assign to nearest click
            val chosen = buffer.stream()
                .sorted(
                    Comparator.comparingDouble<ClickData>(
                        ToDoubleFunction { c: ClickData ->
                            c.location.distance(row.first) / (max(
                                1.0,
                                c.brushSize.toDouble()
                            ))
                        }
                    ))
                .collect(Collectors.toList())
                .firstOrNull()
            if(chosen==null) return originalMesh.toMutableList()
            tempMap.put(row.first, chosen.blockData)
        }

        val bufferMesh: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(originalMesh.size) //this will be returned
        for (entry in tempMap.entries) {
            bufferMesh.add(Pair(entry.key, entry.value))
        }

        if (radius == 0.0 || chance == 0.0) { //there's no point in attempting to create a gradient here either
            return bufferMesh
        }

        var sphere = getCleanSphereBlock(world, radius.toInt()).toList() //cheaper than picking random rotation and distance each time
        val rnd = Random()


        val retMesh: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(originalMesh.size) //this will be returned
        for (row in bufferMesh) {
            if (rnd.nextDouble(100.0) <= chance) {
                val eval: BlockVector3 = row.first
                var relative: BlockVector3?
                do {
                    relative = eval.add(sphere[rnd.nextInt(sphere.size)])
                } while (!tempMap.containsKey(relative))
                val pickedBlock = tempMap[relative]
                pickedBlock?.let {
                    retMesh.add(Pair(eval, it))
                }

            } else {
                retMesh.add(row)
            }
        }

        return retMesh
    }
}