package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.context.Display.reset
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.data.PlayerPerms
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.ModeManager
import com.bryanvalc.magicwand.module.KtPlugin
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import com.bryanvalc.magicwand.utils.TextFormatter
import com.bryanvalc.magicwand.utils.platform.Mediator
import com.github.shynixn.mccoroutine.bukkit.launch
import com.github.shynixn.mccoroutine.bukkit.minecraftDispatcher
import kotlinx.coroutines.delay
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.Sound
import org.bukkit.command.Command
import org.bukkit.command.CommandExecutor
import org.bukkit.command.CommandSender
import org.bukkit.enchantments.Enchantment
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.EventPriority
import org.bukkit.event.Listener
import org.bukkit.event.block.Action
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryCloseEvent
import org.bukkit.event.player.PlayerInteractEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemFlag
import org.bukkit.inventory.ItemStack
import org.bukkit.plugin.java.JavaPlugin
import org.bukkit.NamespacedKey
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

class ModesCommand : CommandExecutor, Listener, KoinComponent {

    val plugin: JavaPlugin by inject()
    val players: MutableMap<UUID, PlayerData> by inject()
    val modeManager: ModeManager by inject()
    val ktPlugin: KtPlugin by inject()

    override fun onCommand(sender: CommandSender, command: Command, label: String, args: Array<String>): Boolean {
        if (sender !is Player) {
            sender.sendMessage("Only executable for players")
            return true
        }
        val player = sender

        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return false
        val playerData = playerDataOriginal.clone()


        openGui(player, playerData)

        return true
    }

    @EventHandler(priority = EventPriority.LOWEST)
    fun onPlayerInteract(event: PlayerInteractEvent) {
        val player = event.player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        if(System.currentTimeMillis() - playerData.lastInteraction<10L) return //avoid open menu when dropping item
        val material = player.inventory.itemInMainHand.type
        if (material == Material.NETHER_STAR) {
            if ((event.action == Action.LEFT_CLICK_AIR || event.action == Action.LEFT_CLICK_BLOCK)) {
                playerData.lastInteraction = System.currentTimeMillis()
                players[uuid] = playerData
                openGui(player, playerData)

                val rt = player.rayTraceBlocks(200.0) // undo PIECE OF SHIT AXIOM, stuff like this is expected, from a lesser programmer
                val hitLocation = rt?.hitBlock?.location?.clone()
                val originalBlockData = rt?.hitBlock?.blockData?.clone()

                if(originalBlockData!=null && hitLocation!=null){
                    plugin.launch(context = plugin.minecraftDispatcher) {
                        delay(20L)
                        hitLocation.block.setBlockData(originalBlockData, false)
                        player.sendBlockChange(hitLocation, originalBlockData)
                    }
                }
            }
        }
    }

    @EventHandler
    fun onInventoryClose(event: InventoryCloseEvent) {
        val player = event.player as Player
        val inventory = event.inventory

        if (!inventory.viewers.contains(player) ||
            Mediator.getTitle(event.view) != INVENTORY_TITLE) return

        player.playSound(player.eyeLocation, closing, 1f, 1f)
    }

    @EventHandler
    fun onInventoryClick(event: InventoryClickEvent) {
        if (event.whoClicked !is Player) return
        val player = event.whoClicked as Player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        val inventory = event.inventory

        if (!inventory.viewers.contains(player) ||
            Mediator.getTitle(event.view) != INVENTORY_TITLE) return

        event.isCancelled = true

        val clickedItem = event.getCurrentItem()
        if (clickedItem == null || clickedItem.type == Material.AIR) return

        val mode = getModeFromMaterial(clickedItem.type) //this isn't really the best solution

        val languagePack = player.getLanguagePack()
        var yes = "Yes"
        var no = "No"
        var face = "Face"
        var center = "Center"
        var disableTitle = "Disable"
        var disableLore = "Disable current brush and build like you would normally."
        var distanceTitle = "Distance"
        var distanceLore = "Max distance between you and initial target."
        var sizeTitle = "Size"
        var sizeLore = "Max size of the shape."
        var falloffStrengthTitle = "Falloff Strength"
        var falloffStrengthLore = "Distance for the mixing of blocks."
        var mixingStrengthTitle = "Mixing Strength"
        var mixingStrengthLore = "Amount of mixing for different blocks."
        var replaceAirTitle = "Replace Air"
        var replaceAirLore = "Replace air blocks from the world."
        var replaceSolidTitle = "Replace Solid"
        var replaceSolidLore = "Replace solid blocks from the world."
        var replaceSoftTitle = "Replace Soft"
        var replaceSoftLore = "Replace soft blocks from the world, like grass for instance."
        var replaceLiquidTitle = "Replace Liquid"
        var replaceLiquidLore = "Replace liquid blocks from the world, like water/lava for instance."
        var brushModeTitle = "Brush Mode"
        var brushModeLore = "Use nether star if enabled, or the blocks that you want to place if disabled."
        var originTitle = "Origin"
        var originLore = "If set to center, the hit block is the starting point, if set to face, the neighbor block is the starting point."
        var snapToSurfaceTitle = "Snap to Surface"
        var snapToSurfaceLore = "Decide if solid blocks in the world get in the way."
        var chatFeedbackTitle = "Chat Feedback"
        var chatFeedbackLore = "Show feedback for positions in the chat."
        var tutorialModeTitle = "Tutorial Mode"
        var tutorialModeLore = "Show lines to help beginners. Warning: may cause lag on low-end devices because it uses entities."
        var showRulerTitle = "Show Ruler"
        var showRulerLore = "Show holograms for the size of the shapes. Warning: may cause an annoying issue where Axiom opens a menu for the entity.."
        var useGlowingTitle = "Use Glowing"
        var useGlowingLore = "Show shape outline. Warning: may cause lag on low-end devices because it uses entities."
        var smartPaintTitle = "Smart Paint"
        var smartPaintLore = "Fills the shape using a mix of the masks and magic select. Warning: it's slow by its nature, still needs some optimization."

        languagePack?.let {
            yes = languagePack.yes
            no = languagePack.no
            face = languagePack.face
            center = languagePack.center
            val menu = languagePack.menu
            disableTitle = menu["disable"]?.title ?:disableTitle
            disableLore = menu["disable"]?.lore ?:disableLore
            sizeTitle = menu["size"]?.title ?: sizeTitle
            sizeLore = menu["size"]?.lore ?: sizeLore
            distanceTitle = menu["distance"]?.title ?: distanceTitle
            distanceLore = menu["distance"]?.lore ?: distanceLore
            falloffStrengthTitle = menu["falloffStrength"]?.title ?:falloffStrengthTitle
            falloffStrengthLore = menu["falloffStrength"]?.lore ?:falloffStrengthLore
            mixingStrengthTitle = menu["mixingStrength"]?.title ?:mixingStrengthTitle
            mixingStrengthLore = menu["mixingStrength"]?.lore ?:mixingStrengthLore
            replaceAirTitle = menu["replaceAir"]?.title ?:replaceAirTitle
            replaceAirLore = menu["replaceAir"]?.lore ?:replaceAirLore
            replaceSolidTitle = menu["replaceSolid"]?.title ?:replaceSolidTitle
            replaceSolidLore = menu["replaceSolid"]?.lore ?:replaceSolidLore
            replaceSoftTitle = menu["replaceSoft"]?.title ?:replaceSoftTitle
            replaceSoftLore = menu["replaceSoft"]?.lore ?:replaceSoftLore
            replaceLiquidTitle = menu["replaceLiquid"]?.title ?:replaceLiquidTitle
            replaceLiquidLore = menu["replaceLiquid"]?.lore ?:replaceLiquidLore
            brushModeTitle = menu["brushMode"]?.title ?:brushModeTitle
            brushModeLore = menu["brushMode"]?.lore ?:brushModeLore
            originTitle = menu["origin"]?.title ?:originTitle
            originLore = menu["origin"]?.lore ?:originLore
            snapToSurfaceTitle = menu["snapToSurface"]?.title ?:snapToSurfaceTitle
            snapToSurfaceLore = menu["snapToSurface"]?.lore ?:snapToSurfaceLore
            chatFeedbackTitle = menu["chatFeedback"]?.title ?:chatFeedbackTitle
            chatFeedbackLore = menu["chatFeedback"]?.lore ?:chatFeedbackLore
            tutorialModeTitle = menu["tutorialMode"]?.title ?:tutorialModeTitle
            tutorialModeLore = menu["tutorialMode"]?.lore ?:tutorialModeLore
            showRulerTitle = menu["showRuler"]?.title ?:showRulerTitle
            showRulerLore = menu["showRuler"]?.lore ?:showRulerLore
            useGlowingTitle = menu["useGlowing"]?.title ?:useGlowingTitle
            useGlowingLore = menu["useGlowing"]?.lore ?:useGlowingLore
            smartPaintTitle = menu["smartPaint"]?.title ?:smartPaintTitle
            smartPaintLore = menu["smartPaint"]?.lore ?:smartPaintLore
        }

        if (mode != null) {
            if (!player.hasPermission(plugin.name.lowercase()+"."+mode.permission)) {
                player.sendParsed(player.getLanguagePack()?.permission ?: "You don't have permission to use this")
                return
            }

            if (event.isShiftClick || event.isRightClick) {
                if(mode is Configurable) {
                    player.playSound(player.eyeLocation, favorite, 1f, 1f)

                    val menu = mode.forPlayer(playerData)
                    menu?.render(player)
                }
            } else if (event.isLeftClick) {
                reset(player, playerData)
                player.playSound(player.eyeLocation, picking, 1f, 1f)
                val previousMode = playerData.mode
                val message: Component? = playerData.setMode(mode)
                if(message==null){
                    player.sendParsed(ktPlugin.premiumMessage)
                } else {
                    Mediator.sendActionBar(player, message)
                    mode?.let {

                        var name = it.name
                        languagePack?.let {
                            name = languagePack.brushes[mode.name]?.name ?: mode.name
                        }

                        var optionsMessage = "$name: <#8968d3><u><a:${it.wiki}><bold>wiki</bold></a></u> "
                        if (mode is Configurable) {
                            optionsMessage+= "<hover:show_text:'Change ${it.name} options'><u><click:run_command:'/brushoptions ${(it.name).replace(" ", "_")}'><#8d4ca9><bold>options</bold>"
                        }
                        player.sendParsed(optionsMessage)
                    }
                    var model = 1
                    if(previousMode != mode){
                        val modes = modeManager.modes
                        val toAdd = modes.indexOf(mode)+1
                        model+=toAdd
                    }
                    val item = player.inventory.itemInMainHand
                    if(event.isLeftClick && item.type == Material.NETHER_STAR) {
                        var meta = item.itemMeta
                        Mediator.displayName(meta, mode.name)
                        meta.setCustomModelData(model)
                        item.itemMeta = meta
                    }
                }
                player.closeInventory()
            }
        } else if (clickedItem.type == Material.BARRIER) {
            player.playSound(player.eyeLocation, clicking, 1f, 1f)
            reset(player, playerData)
            val message: Component? = playerData.setMode(null)
            val item = player.inventory.itemInMainHand
            if(item.type == Material.NETHER_STAR) {
                var meta = item.itemMeta
                Mediator.displayName(meta, "MagicWand Menu")
                meta.setCustomModelData(1)
                item.itemMeta = meta
            }
            if(message!=null){
                Mediator.sendActionBar(player, message)
            }
            player.closeInventory()
        } else if (clickedItem.type == Material.FIREWORK_ROCKET) {
            player.playSound(player.eyeLocation, clicking, 1f, 1f)
            var reach = playerData.reach
            if (event.isLeftClick) { //increase
                reach += if (event.isShiftClick) { //by 10
                    10
                } else {
                    1
                }
            } else if (event.isRightClick) { //decrease
                reach -= if (event.isShiftClick) { //by 10
                    10
                } else {
                    1
                }
            }

            val maxReach = PlayerPerms.getLongPath(uuid, "reach")
            playerData.reach = min(max(5,reach),maxReach.toInt())
            updateItem(
                inventory,
                event.slot,
                clickedItem.type,
                MiniMessage.miniMessage().deserialize("<#5e4fa2>$distanceTitle: <#f79459>" + playerData.reach),
                distanceLore,
                false,
                1
            )
        } else if (clickedItem.type == Material.NAME_TAG) {
            player.playSound(player.eyeLocation, clicking, 1f, 1f)
            var bound = playerData.boundLimit
            if (event.isLeftClick) { //increase
                bound += if (event.isShiftClick) { //by 10
                    10
                } else {
                    1
                }
            } else if (event.isRightClick) { //decrease
                bound -= if (event.isShiftClick) { //by 10
                    10
                } else {
                    1
                }
            }
            val maxBound = PlayerPerms.getLongPath(uuid, "bound")
            playerData.boundLimit = min(max(0,bound),maxBound.toInt())
            updateItem(
                inventory,
                event.slot,
                clickedItem.type,
                MiniMessage.miniMessage().deserialize("<#5e4fa2>$sizeTitle: <#f79459>" + playerData.boundLimit),
                sizeLore,
                false,
                1
            )
        } else if (clickedItem.type == Material.BLAZE_POWDER) {
            player.playSound(player.eyeLocation, clicking, 1f, 1f)
            var falloff = playerData.falloffStrength
            if (event.isLeftClick) { //increase
                falloff += if (event.isShiftClick) { //by 10
                    10.0
                } else {
                    1.0
                }
            } else if (event.isRightClick) { //decrease
                falloff -= if (event.isShiftClick) { //by 10
                    10.0
                } else {
                    1.0
                }
            }

            playerData.falloffStrength = min(max(0.0,falloff),100.0)
            updateItem(
                inventory,
                event.slot,
                clickedItem.type,
                MiniMessage.miniMessage()
                    .deserialize("<#5e4fa2>$falloffStrengthTitle: <#f79459>" + playerData.falloffStrength),
                falloffStrengthLore,
                false,
                1
            )
        } else if (clickedItem.type == Material.MAGMA_CREAM) {
            player.playSound(player.eyeLocation, clicking, 1f, 1f)
            var mixing = playerData.mixingStrength
            if (event.isLeftClick) { //increase
                mixing += if (event.isShiftClick) { //by 10
                    10.0
                } else {
                    1.0
                }
            } else if (event.isRightClick) { //decrease
                mixing -= if (event.isShiftClick) { //by 10
                    10.0
                } else {
                    1.0
                }
            }

            playerData.mixingStrength = min(max(0.0,mixing),100.0)
            updateItem(
                inventory,
                event.slot,
                clickedItem.type,
                MiniMessage.miniMessage()
                    .deserialize("<#5e4fa2>$mixingStrengthTitle: <#f79459>" + playerData.mixingStrength),
                mixingStrengthLore,
                false,
                1
            )
        } else if (clickedItem.type == Material.FEATHER) {
            val replaceAir = playerData.replaceAir
            playerData.replaceAir = !replaceAir
            if (playerData.replaceAir) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceAirTitle: <green>$yes ✔"),
                    replaceAirLore, true, 2
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceAirTitle: <red>$no ✘"),
                    replaceAirLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.IRON_INGOT) {
            val replaceSolid = playerData.replaceSolid
            playerData.replaceSolid = !replaceSolid
            if (playerData.replaceSolid) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceSolidTitle: <green>$yes ✔"),
                    replaceSolidLore, true, 2
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceSolidTitle: <red>$no ✘"),
                    replaceSolidLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.SEAGRASS) {
            val replaceSoft = playerData.replaceSoft
            playerData.replaceSoft = !replaceSoft
            if (playerData.replaceSoft) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceSoftTitle: <green>$yes ✔"),
                    replaceSoftLore, true, 2
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceSoftTitle: <red>$no ✘"),
                    replaceSoftLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.WATER_BUCKET) {
            val replaceLiquid: Boolean = playerData.replaceLiquid
            playerData.replaceLiquid = !replaceLiquid
            if (playerData.replaceLiquid) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceLiquidTitle: <green>$yes ✔"),
                    replaceLiquidLore, true, 2
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceLiquidTitle: <red>$no ✘"),
                    replaceLiquidLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.BEETROOT_SOUP) {
            val smartPaint: Boolean = playerData.smartPaint
            playerData.smartPaint = !smartPaint
            if (playerData.smartPaint) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$smartPaintTitle: <green>$yes ✔"),
                    smartPaintLore, true, 1
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$smartPaintTitle: <red>$no ✘"),
                    smartPaintLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.BLAZE_ROD) {
            val ruler: Boolean = playerData.ruler
            playerData.ruler = !ruler
            if (playerData.ruler) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$showRulerTitle: <green>$yes ✔"),
                    showRulerLore, true, 1
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$showRulerTitle: <red>$no ✘"),
                    showRulerLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.GLOW_INK_SAC) {
            val glowing: Boolean = playerData.glowing
            playerData.glowing = !glowing
            if (playerData.glowing) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$useGlowingTitle: <green>$yes ✔"),
                    useGlowingLore, true, 1
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$useGlowingTitle: <red>$no ✘"),
                    useGlowingLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.BOOK) {
            val tutorial: Boolean = playerData.tutorial
            playerData.tutorial = !tutorial
            if (playerData.tutorial) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$tutorialModeTitle: <green>$yes ✔"),
                    tutorialModeLore, true, 1
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$tutorialModeTitle: <red>$no ✘"),
                    tutorialModeLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.SLIME_BALL) {
            val snap: Boolean = playerData.snap
            playerData.snap = !snap
            if (playerData.snap) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$snapToSurfaceTitle: <green>$yes ✔"),
                    snapToSurfaceLore, true, 1
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$snapToSurfaceTitle: <red>$no ✘"),
                    snapToSurfaceLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.ARROW) {
            val brushMode: Boolean = playerData.brushMode
            playerData.brushMode = !brushMode
            if (playerData.brushMode) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$brushModeTitle: <green>$yes ✔"),
                    brushModeLore, true, 1
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$brushModeTitle: <red>$no ✘"),
                    brushModeLore, false, 1
                )
            }
        } else if (clickedItem.type == Material.HONEYCOMB) {
            val centerOrigin: Boolean = playerData.centerOrigin
            playerData.centerOrigin = !centerOrigin
            if (playerData.centerOrigin) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$originTitle: <#f79459>$center"),
                    originLore, true, 1
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$originTitle: <#f79459>$face"),
                    originLore, false, 2
                )
            }
        }  else if (clickedItem.type == Material.MUSIC_DISC_13) {
            val chatFeedback: Boolean = playerData.chatFeedback
            playerData.chatFeedback = !chatFeedback
            if (playerData.chatFeedback) {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$chatFeedbackTitle: <green>$yes ✔"),
                    chatFeedbackLore, true, 1
                )
            } else {
                player.playSound(player.eyeLocation, clicking, 1f, 1f)
                updateItem(
                    inventory, event.slot, clickedItem.type,
                    MiniMessage.miniMessage().deserialize("<#5e4fa2>$chatFeedbackTitle: <red>$no ✘"),
                    chatFeedbackLore, false, 1
                )
            }
        }


        players[uuid] = playerData
    }

    private fun getModeFromMaterial(material: Material): Mode? {
        for (mode in modeManager.modes) {
            if (material == mode.materialMenu) {
                return mode
            }
        }
        return null
    }

    private fun updateItem(
        inventory: Inventory,
        slot: Int,
        material: Material,
        display: Component,
        loreText: String?,
        glow: Boolean,
        model: Int?
    ) {
        val item = createGuiItem(material, display, loreText, glow, model)
        inventory.setItem(slot, item)
    }

    private fun createGuiItem(material: Material?, name: Component, loreText: String?, glow: Boolean, model: Int?): ItemStack {
        val item = if (material!=null) {
            ItemStack(material)
        } else {
            ItemStack(Material.STONE)
        }

        val meta = item.itemMeta
        Mediator.displayName(meta, name)
        if (glow) {
            Enchantment.getByKey(NamespacedKey.minecraft("unbreaking"))?.let { meta.addEnchant(it, 1, true) }
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS)
        }


        if (loreText != null) {
            Mediator.lore(meta, TextFormatter.createComponents(loreText, 30))
        }

        if(model!=null) {
            meta.setCustomModelData(model)
        }

        item.setItemMeta(meta)
        return item
    }

    fun openGui(player: Player, playerData: PlayerData) {
        if(!player.hasPermission("${plugin.name.lowercase()}.menu")) return

        player.playSound(player.eyeLocation, opening, 1f, 1f)
        val uuid = player.uniqueId

        val gui = Mediator.createInventory(null, 54, INVENTORY_TITLE)

        val languagePack = player.getLanguagePack()
        var yes = "Yes"
        var no = "No"
        var face = "Face"
        var center = "Center"
        var disableTitle = "Disable"
        var disableLore = "Disable current brush and build like you would normally."
        var distanceTitle = "Distance"
        var distanceLore = "Max distance between you and initial target."
        var sizeTitle = "Size"
        var sizeLore = "Max size of the shape."
        var falloffStrengthTitle = "Falloff Strength"
        var falloffStrengthLore = "Distance for the mixing of blocks."
        var mixingStrengthTitle = "Mixing Strength"
        var mixingStrengthLore = "Amount of mixing for different blocks."
        var replaceAirTitle = "Replace Air"
        var replaceAirLore = "Replace air blocks from the world."
        var replaceSolidTitle = "Replace Solid"
        var replaceSolidLore = "Replace solid blocks from the world."
        var replaceSoftTitle = "Replace Soft"
        var replaceSoftLore = "Replace soft blocks from the world, like grass for instance."
        var replaceLiquidTitle = "Replace Liquid"
        var replaceLiquidLore = "Replace liquid blocks from the world, like water/lava for instance."
        var brushModeTitle = "Brush Mode"
        var brushModeLore = "Use nether star if enabled, or the blocks that you want to place if disabled."
        var originTitle = "Origin"
        var originLore = "If set to center, the hit block is the starting point, if set to face, the neighbor block is the starting point."
        var snapToSurfaceTitle = "Snap to Surface"
        var snapToSurfaceLore = "Decide if solid blocks in the world get in the way."
        var chatFeedbackTitle = "Chat Feedback"
        var chatFeedbackLore = "Show feedback for positions in the chat."
        var tutorialModeTitle = "Tutorial Mode"
        var tutorialModeLore = "Show lines to help beginners. Warning: may cause lag on low-end devices because it uses entities."
        var showRulerTitle = "Show Ruler"
        var showRulerLore = "Show holograms for the size of the shapes. Warning: may cause an annoying issue where Axiom opens a menu for the entity.."
        var useGlowingTitle = "Use Glowing"
        var useGlowingLore = "Show shape outline. Warning: may cause lag on low-end devices because it uses entities."
        var smartPaintTitle = "Smart Paint"
        var smartPaintLore = "Fills the shape using a mix of the masks and magic select. Warning: it's slow by its nature, still needs some optimization."

        languagePack?.let {
            yes = languagePack.yes
            no = languagePack.no
            face = languagePack.face
            center = languagePack.center
            val menu = languagePack.menu
            disableTitle = menu["disable"]?.title ?:disableTitle
            disableLore = menu["disable"]?.lore ?:disableLore
            sizeTitle = menu["size"]?.title ?: sizeTitle
            sizeLore = menu["size"]?.lore ?: sizeLore
            distanceTitle = menu["distance"]?.title ?: distanceTitle
            distanceLore = menu["distance"]?.lore ?: distanceLore
            falloffStrengthTitle = menu["falloffStrength"]?.title ?:falloffStrengthTitle
            falloffStrengthLore = menu["falloffStrength"]?.lore ?:falloffStrengthLore
            mixingStrengthTitle = menu["mixingStrength"]?.title ?:mixingStrengthTitle
            mixingStrengthLore = menu["mixingStrength"]?.lore ?:mixingStrengthLore
            replaceAirTitle = menu["replaceAir"]?.title ?:replaceAirTitle
            replaceAirLore = menu["replaceAir"]?.lore ?:replaceAirLore
            replaceSolidTitle = menu["replaceSolid"]?.title ?:replaceSolidTitle
            replaceSolidLore = menu["replaceSolid"]?.lore ?:replaceSolidLore
            replaceSoftTitle = menu["replaceSoft"]?.title ?:replaceSoftTitle
            replaceSoftLore = menu["replaceSoft"]?.lore ?:replaceSoftLore
            replaceLiquidTitle = menu["replaceLiquid"]?.title ?:replaceLiquidTitle
            replaceLiquidLore = menu["replaceLiquid"]?.lore ?:replaceLiquidLore
            brushModeTitle = menu["brushMode"]?.title ?:brushModeTitle
            brushModeLore = menu["brushMode"]?.lore ?:brushModeLore
            originTitle = menu["origin"]?.title ?:originTitle
            originLore = menu["origin"]?.lore ?:originLore
            snapToSurfaceTitle = menu["snapToSurface"]?.title ?:snapToSurfaceTitle
            snapToSurfaceLore = menu["snapToSurface"]?.lore ?:snapToSurfaceLore
            chatFeedbackTitle = menu["chatFeedback"]?.title ?:chatFeedbackTitle
            chatFeedbackLore = menu["chatFeedback"]?.lore ?:chatFeedbackLore
            tutorialModeTitle = menu["tutorialMode"]?.title ?:tutorialModeTitle
            tutorialModeLore = menu["tutorialMode"]?.lore ?:tutorialModeLore
            showRulerTitle = menu["showRuler"]?.title ?:showRulerTitle
            showRulerLore = menu["showRuler"]?.lore ?:showRulerLore
            useGlowingTitle = menu["useGlowing"]?.title ?:useGlowingTitle
            useGlowingLore = menu["useGlowing"]?.lore ?:useGlowingLore
            smartPaintTitle = menu["smartPaint"]?.title ?:smartPaintTitle
            smartPaintLore = menu["smartPaint"]?.lore ?:smartPaintLore
        }

        gui.setItem(
            0, createGuiItem(
                Material.FIREWORK_ROCKET,
                MiniMessage.miniMessage().deserialize("<#5e4fa2>$distanceTitle: <#f79459>" + playerData.reach), distanceLore, false, 1
            )
        )
        gui.setItem(
            1, createGuiItem(
                Material.NAME_TAG,
                MiniMessage.miniMessage().deserialize("<#5e4fa2>$sizeTitle: <#f79459>" + playerData.boundLimit),
                sizeLore,
                false, 1
            )
        )
        gui.setItem(
            2, createGuiItem(
                Material.BLAZE_POWDER,
                MiniMessage.miniMessage()
                    .deserialize("<#5e4fa2>$falloffStrengthTitle: <#f79459>" + playerData.falloffStrength), falloffStrengthLore, false, 1
            )
        )
        gui.setItem(
            3, createGuiItem(
                Material.MAGMA_CREAM,
                MiniMessage.miniMessage()
                    .deserialize("<#5e4fa2>$mixingStrengthTitle: <#f79459>" + playerData.mixingStrength), mixingStrengthLore, false, 1
            )
        )


        gui.setItem(4, createGuiItem(Material.BARRIER, Component.text(disableTitle), disableLore, false, 1))

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val smartReplace = playerData.smartPaint
        val glowing = playerData.glowing
        val ruler = playerData.ruler
        val tutorial = playerData.tutorial
        val snap = playerData.snap
        val chatFeedback = playerData.chatFeedback
        val brushMode = playerData.brushMode
        val centerOrigin = playerData.centerOrigin

        val airComponent = if (replaceAir) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceAirTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceAirTitle: <red>$no ✘")
        }
        gui.setItem(5, createGuiItem(Material.FEATHER, airComponent, replaceAirLore, replaceAir, if(replaceAir){2}else{1}))

        val solidComponent = if (replaceSolid) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceSolidTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceSolidTitle: <red>$no ✘")
        }
        gui.setItem(6, createGuiItem(Material.IRON_INGOT, solidComponent, replaceSolidLore, replaceSolid, if(replaceSolid){2}else{1}))


        val softComponent = if (replaceSoft) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceSoftTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceSoftTitle: <red>$no ✘")
        }
        gui.setItem(7, createGuiItem(Material.SEAGRASS, softComponent, replaceSoftLore, replaceSoft, if(replaceSoft){2}else{1}))

        val liquidComponent = if (replaceLiquid) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceLiquidTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$replaceLiquidTitle: <red>$no ✘")
        }
        gui.setItem(8, createGuiItem(Material.WATER_BUCKET, liquidComponent, replaceLiquidLore, replaceLiquid, if(replaceLiquid){2}else{1}))

        val brushComponent = if (brushMode) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$brushModeTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$brushModeTitle: <red>$no ✘")
        }
        gui.setItem(9, createGuiItem(Material.ARROW, brushComponent, brushModeLore, brushMode, 1))

        val centerComponent = if (centerOrigin) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$originTitle: <#f79459>$center")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$originTitle: <#f79459>$face")
        }
        gui.setItem(10, createGuiItem(Material.HONEYCOMB, centerComponent, originLore, centerOrigin, if(centerOrigin){1}else{2}))

        val snapComponent = if (snap) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$snapToSurfaceTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$snapToSurfaceTitle: <red>$no ✘")
        }
        gui.setItem(11, createGuiItem(Material.SLIME_BALL, snapComponent, snapToSurfaceLore, snap, 1))


        val chatComponent = if (chatFeedback) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$chatFeedbackTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$chatFeedbackTitle: <red>$no ✘")
        }
        gui.setItem(12, createGuiItem(Material.MUSIC_DISC_13, chatComponent, chatFeedbackLore, chatFeedback, 1))

        val tutorialComponent = if (tutorial) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$tutorialModeTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$tutorialModeTitle: <red>$no ✘")
        }
        gui.setItem(14, createGuiItem(Material.BOOK, tutorialComponent,
            tutorialModeLore, tutorial, 1))

        val rulerComponent = if (ruler) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$showRulerTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$showRulerTitle: <red>$no ✘")
        }
        gui.setItem(15, createGuiItem(Material.BLAZE_ROD, rulerComponent,
            showRulerLore, ruler, 1))

        val glowingComponent = if (glowing) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$useGlowingTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$useGlowingTitle: <red>$no ✘")
        }
        gui.setItem(16, createGuiItem(Material.GLOW_INK_SAC, glowingComponent,
            useGlowingLore, glowing, 1))

        val smartComponent = if (smartReplace) {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$smartPaintTitle: <green>$yes ✔")
        } else {
            MiniMessage.miniMessage().deserialize("<#5e4fa2>$smartPaintTitle: <red>$no ✘")
        }
        gui.setItem(17, createGuiItem(Material.BEETROOT_SOUP, smartComponent,
            smartPaintLore,
            smartReplace, 1))


        val toSkip = listOf(31, 40, 49)

        var index = 27
        for (mode in modeManager.modes) {

            var name = mode.name
            var description = "No description"
            languagePack?.let {
                name = languagePack.brushes[mode.name]?.name ?: mode.name
                description = languagePack.brushes[mode.name]?.description ?: "No description"
            }

            val title = if (player.hasPermission(plugin.name.lowercase()+"."+mode.permission)) {
                MiniMessage.miniMessage().deserialize("<green>$name ✔")
            } else {
                MiniMessage.miniMessage().deserialize("<red>$name ✘")
            }

            //var isFavorite = (playerData.favoriteModes.contains(mode) || mode==playerData.mode)
            var isFavorite = (mode==playerData.mode)
            if(toSkip.contains(index)) index+=1

            gui.setItem(
                index,
                createGuiItem(mode.materialMenu, title, description, isFavorite, if(isFavorite){2}else{1}))
            index += 1
        }

        player.openInventory(gui)

        players[uuid] = playerData
    }

    companion object {
        private const val INVENTORY_TITLE = "MagicWand Menu"

        var opening: Sound = Sound.UI_TOAST_IN
        var closing: Sound = Sound.UI_TOAST_OUT
        var picking: Sound = Sound.BLOCK_AMETHYST_BLOCK_STEP
        var favorite: Sound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP
        var clicking: Sound = Sound.UI_BUTTON_CLICK
    }
}