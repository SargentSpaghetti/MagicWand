package com.bryanvalc.magicwand.controller

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack

object ItemRemover {

    fun removeItems(player: Player, newBlocks: List<Pair<BlockVector3, WrappedBlockState>>): Boolean {
        val amounts: MutableMap<Material, Int> = Reference2IntOpenHashMap()

        for (block in newBlocks) {
            val material = SpigotConversionUtil.toBukkitBlockData(block.second).material
            amounts.put(material, amounts.getOrDefault(material, 0) + 1)
        }


        val inventory: Inventory = player.inventory

        // Check if the player has all required materials
        for (entry in amounts.entries) {
            val material: Material = entry.key
            val amountNeeded: Int = entry.value

            if (inventory.contains(material, amountNeeded)) {
                continue  // Player has enough of this material
            } else {
                player.sendMessage("You do not have enough " + material.name + "(s). Required: " + amountNeeded)
                return false
            }
        }

        // If the player has all items, proceed with removal
        for (entry in amounts.entries) {
            val material: Material = entry.key
            val amountToRemove: Int = entry.value

            val itemStack = ItemStack(material, amountToRemove)
            val removed = inventory.removeItem(itemStack).size // This returns items that couldn't be removed

            if (removed == 0) {
//                player.sendMessage("Successfully removed " + amountToRemove + " " + material.name + "(s) from your inventory.")
            } else {
                player.sendMessage("Could not remove all " + material.name + "(s). " + removed + " were not found.")
                return false //has to be transactional in some way
            }
        }

        return true
    }

}