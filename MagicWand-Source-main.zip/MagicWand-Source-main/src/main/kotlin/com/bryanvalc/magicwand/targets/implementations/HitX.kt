package com.bryanvalc.magicwand.targets.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.hit
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.targets.Target
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import java.util.Map
import kotlin.math.abs

class HitX : Target() {
    override fun isResolved(player: Player, playerData: PlayerData): Boolean {
        return true
    }

    override fun predict(player: Player, playerData: PlayerData): BlockVector3? {
        val clicks = playerData.clicks
        if (clicks.isEmpty()) {
            return null
        }

        val previousClick = clicks.lastOrNull()
        if(previousClick==null) return null

        val previousBlock = previousClick.location
        return hit(player, playerData, previousBlock, 'X')
    }

    override fun hologramTip(
        player: Player,
        playerData: PlayerData
    ): MutableMap<Int, MutableSet<BlockVector3>> {
        val clicks = playerData.clicks
        if (clicks.isEmpty()) {
            return Map.of<Int, MutableSet<BlockVector3>>()
        }

        val previousClick = clicks.lastOrNull()
        if(previousClick==null) return Map.of<Int, MutableSet<BlockVector3>>()

        val previousBlock = previousClick.location

        val ret: MutableMap<Int, MutableSet<BlockVector3>> = HashMap<Int, MutableSet<BlockVector3>>()

        ret.put(0, mutableSetOf<BlockVector3>(previousBlock))
        var i = 1
        while (i <= 16) {
            val current: MutableSet<BlockVector3> = HashSet<BlockVector3>(i * (8))

            var y = -i
            while (y <= i) {
                if ((i - abs(y.toDouble())) < 5) {
                    current.add(previousBlock.add(0, y, i))
                    current.add(previousBlock.add(0, y, -i))
                }
                y += 1
            }
            var z = -i
            while (z <= i) {
                if ((i - abs(z.toDouble())) < 5) {
                    current.add(previousBlock.add(0, i, z))
                    current.add(previousBlock.add(0, -i, z))
                }
                z += 1
            }
            ret.put(i, current)
            i += 1
        }

        return ret
    }
}