package com.bryanvalc.magicwand.noise.pattern.parser

import com.bryanvalc.magicwand.noise.pattern.impl.ExponentialNoiseGenerator
import com.fastasyncworldedit.core.extension.factory.parser.pattern.NoisePatternParser
import com.sk89q.worldedit.WorldEdit
import java.util.function.Supplier


class ExponentialPatternParser
    (worldEdit: WorldEdit?) : NoisePatternParser(
    worldEdit,
    "exponential",
    Supplier { ExponentialNoiseGenerator() }) {
}