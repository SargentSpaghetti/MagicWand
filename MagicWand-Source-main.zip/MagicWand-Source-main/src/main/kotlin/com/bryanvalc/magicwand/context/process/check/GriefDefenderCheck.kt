package com.bryanvalc.magicwand.context.process.check

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.griefdefender.api.GriefDefender
import com.griefdefender.api.claim.TrustTypes
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Location
import org.bukkit.entity.Player

object GriefDefenderCheck: Protect {

    override fun process(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        val uuid = player.uniqueId
        val user = GriefDefender.getCore().getUser(uuid)
        if (user == null) {
            return originalMesh.toMutableList()
        }

        val filtered = originalMesh.asSequence().filter {
            val loc = Location(player.world, it.first.x().toDouble(), it.first.y().toDouble(), it.first.z().toDouble())
            val claim = GriefDefender.getCore().getClaimAt(loc)
            claim?.isUserTrusted(uuid, TrustTypes.BUILDER) ?: true
        }

        return filtered.toMutableList()
    }




}