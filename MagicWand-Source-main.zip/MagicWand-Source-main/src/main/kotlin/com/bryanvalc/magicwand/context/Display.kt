package com.bryanvalc.magicwand.context

import com.bryanvalc.magicwand.module.config.Configuration
import com.bryanvalc.magicwand.context.BlockVectorUtils.maxBlockVector
import com.bryanvalc.magicwand.context.BlockVectorUtils.minBlockVector
import com.bryanvalc.magicwand.context.PlayerUtils.serveBlockData
import com.bryanvalc.magicwand.context.overlay.GlowBlocks
import com.bryanvalc.magicwand.context.overlay.ShowDimensions
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.Packet
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.context.process.*
import com.bryanvalc.magicwand.context.process.check.GriefDefenderCheck
import com.bryanvalc.magicwand.context.process.check.PlotSquaredCheck
import com.bryanvalc.magicwand.context.process.check.WorldGuardCheck
import com.bryanvalc.magicwand.module.locales.LangManager
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.modes.Refreshable
import com.bryanvalc.magicwand.module.PluginRepository
import com.bryanvalc.magicwand.targets.DynamicTarget
import com.bryanvalc.magicwand.targets.DynamicTarget.Companion.recursivelySolveTarget
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.platform.Mediator
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.FluidCollisionMode
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.block.Action
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.text.DecimalFormat
import java.util.*

object Display: KoinComponent {

    val pluginRepository: PluginRepository by inject()
    val plugin: JavaPlugin by inject()
    val configuration: Configuration by inject()
    val langManager: LangManager by inject()

    fun draw(player: Player, playerData: PlayerData): MutableList<Pair<BlockVector3, WrappedBlockState>>? {
        val clickDataList = playerData.clicks.toList()
        val clicksArrayList: MutableList<BlockVector3> = ArrayList<BlockVector3>()

        if (clickDataList.isNotEmpty()) {
            for (click in clickDataList) {
                clicksArrayList.add(click.location)
            }
        }
        val pivot = playerData.pivot
        if (pivot != null) clicksArrayList.add(pivot)
        if (clicksArrayList.isEmpty()) return null

        val mode = playerData.mode
        if (mode == null) return null

        val itemStack = player.inventory.itemInMainHand
        if(playerData.brushMode&&itemStack.type!= Material.NETHER_STAR) {
            return null
        }

        var newShape = mode.draw(player, playerData)
        if (newShape == null) return null

        if (mode is Multicolor && !playerData.brushMode) newShape = mode.genGradient(newShape, player, playerData)

        //modifier
        newShape = Modifiers.attemptApply(player, playerData, newShape)
        if(newShape==null) return null

        //WorldGuard
        if (!(player.hasPermission("fawe.bypass.regions") || player.hasPermission("worldguard.region.bypass")) && pluginRepository.worldGuardPlugin != null) {
            newShape = WorldGuardCheck.process(newShape, player)
        }
        //plotsquared
        if (!player.hasPermission("plots.worldedit.bypass") && pluginRepository.plotPlugin != null) {
            newShape = PlotSquaredCheck.process(newShape, player)
        }
        //GriefDefender
        if (!player.hasPermission("griefdefender.admin.bypass.border-check") && pluginRepository.griefDefenderEnabled) {
            newShape = GriefDefenderCheck.process(newShape, player)
        }

        //smartpaint
        val smartPaint: Boolean = playerData.smartPaint
        if (smartPaint) {
            newShape = Transformers.fuzzyPaintB(newShape, player, playerData)
        }


        val newOriginalBlocks: MutableSet<BlockVector3> = HashSet<BlockVector3>(newShape.size)

        for (block in newShape) {
            newOriginalBlocks.add(block.first)
        }

        if(AntiTrolling.isTrolling(player, newShape)) return null

        if (playerData.ruler) {
            showSize(player, newShape, playerData)
        }

        val previousOriginalBlocks: MutableSet<BlockVector3> = playerData.originalBlocks
        val previousShape: MutableList<Pair<BlockVector3, WrappedBlockState>> = playerData.newBlocks

        if(mode is Refreshable) {
//            sendRealBlocks(player, playerData)
//            previousOriginalBlocks.clear()
            previousShape.clear()
        }

        val newShapeSet: Set<Pair<BlockVector3, WrappedBlockState>> =
            HashSet<Pair<BlockVector3, WrappedBlockState>>(newShape)

        val previousShapeSet: Set<Pair<BlockVector3, WrappedBlockState>> =
            HashSet<Pair<BlockVector3, WrappedBlockState>>(previousShape)

        var packet = HashSet<Pair<BlockVector3, WrappedBlockState>>(newShape.size)


        val positionsToRestore: MutableSet<BlockVector3> = HashSet<BlockVector3>(previousOriginalBlocks)
        positionsToRestore.removeAll(newOriginalBlocks)

        val packetAir: MutableSet<Pair<BlockVector3, WrappedBlockState>> =
            HashSet<Pair<BlockVector3, WrappedBlockState>>(previousOriginalBlocks.size)

        for (evaluated in positionsToRestore) {
            val blockData = player.world.getBlockData(evaluated.x(), evaluated.y(), evaluated.z())
            val wrapped = SpigotConversionUtil.fromBukkitBlockData(blockData)
            val worldBlock = Pair<BlockVector3, WrappedBlockState>(evaluated, wrapped)
            packetAir.add(worldBlock)
        }

        if (pluginRepository.packetEventsEnabled) {
            Glowing.attemptGlow(
                player,
                playerData,
                newShapeSet,
                previousShapeSet,
                packetAir
            )
        }

        packet.addAll(packetAir)
        packet.addAll(newShapeSet)
        packet.removeAll(previousShapeSet)

        Packet.sendBlocks(player, packet)

        playerData.previewedNow = playerData.previewedNow + packet.size // rate limit
        playerData.originalBlocks = newOriginalBlocks
        playerData.newBlocks = newShape // so fawe can use it


        return newShape
    }

    fun reset(player: Player, playerData: PlayerData) {
        val previousOriginalBlocks: MutableSet<BlockVector3> = playerData.originalBlocks
        val packet: MutableSet<Pair<BlockVector3, WrappedBlockState>> =
            HashSet<Pair<BlockVector3, WrappedBlockState>>(previousOriginalBlocks.size)
        val positionsToRestore: Set<BlockVector3> = HashSet<BlockVector3>(previousOriginalBlocks)
        val packetAir: MutableSet<Pair<BlockVector3, WrappedBlockState>> =
            HashSet<Pair<BlockVector3, WrappedBlockState>>(previousOriginalBlocks.size)

        for (evaluated in positionsToRestore) {
            val blockData = player.world.getBlockData(evaluated.x(), evaluated.y(), evaluated.z())
            val wrapped = SpigotConversionUtil.fromBukkitBlockData(blockData)
            val worldBlock = Pair<BlockVector3, WrappedBlockState>(evaluated, wrapped)
            packetAir.add(worldBlock)
        }

        packet.addAll(packetAir)

        if (pluginRepository.packetEventsEnabled && configuration.useGlowing && playerData.glowing) { //glowing
            try {
                for (block in packet) {
                    GlowBlocks.unGlow(block.first, player, playerData)
                }
            } catch (exception: Exception) {
                plugin.logger.severe(exception.message)
            }
        }

        Packet.sendBlocks(player, packet)
        playerData.clearPlacingData()
    }

    fun sendRealBlocks(player: Player, playerData: PlayerData) {
        val previousOriginalBlocks: MutableSet<BlockVector3> = playerData.originalBlocks
        val packet: MutableSet<Pair<BlockVector3, WrappedBlockState>> =
            HashSet<Pair<BlockVector3, WrappedBlockState>>(previousOriginalBlocks.size)
        val newBlocks: MutableList<Pair<BlockVector3, WrappedBlockState>> = playerData.newBlocks
        val positionsToRestore: Set<BlockVector3> = HashSet<BlockVector3>(previousOriginalBlocks)
        val packetAir: MutableSet<Pair<BlockVector3, WrappedBlockState>> =
            HashSet<Pair<BlockVector3, WrappedBlockState>>(previousOriginalBlocks.size)

        for (evaluated in positionsToRestore) {
            val blockData = player.world.getBlockData(evaluated.x(), evaluated.y(), evaluated.z())
            val wrapped = SpigotConversionUtil.fromBukkitBlockData(blockData)
            val worldBlock = Pair<BlockVector3, WrappedBlockState>(evaluated, wrapped)
            packetAir.add(worldBlock)
        }

        for (evaluated in newBlocks) {
            val blockData = player.world.getBlockData(
                evaluated.first.x(), evaluated.first.y(), evaluated.first.z()
            )
            val wrapped = SpigotConversionUtil.fromBukkitBlockData(blockData)
            val worldBlock = Pair<BlockVector3, WrappedBlockState>(evaluated.first, wrapped)
            packetAir.add(worldBlock)
        }

        packet.addAll(packetAir)
        if (configuration.useGlowing && playerData.glowing) { //glowing
            for (block in packet) {
                GlowBlocks.unGlow(block.first, player, playerData)
            }
        }
        Packet.sendBlocks(player, packet)
    }

    fun showSize(
        player: Player,
        clientPackage: List<Pair<BlockVector3, WrappedBlockState>>,
        playerData: PlayerData
    ) {
        val clickDataList: List<ClickData> = playerData.clicks
        val clicksArrayList: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clickDataList) {
            clicksArrayList.add(click.location)
        }

        val pivot = playerData.pivot
        if (pivot != null) {
            clicksArrayList.add(pivot)
        }

        val clicks = clicksArrayList.toTypedArray<BlockVector3>()

        if (clicks.isEmpty()) {
            return
        }

        val newCubeMin: BlockVector3 = minBlockVector(*clicks)
        val newCubeMax: BlockVector3 = maxBlockVector(*clicks)

        val minX = newCubeMin.x()
        val minY = newCubeMin.y()
        val minZ = newCubeMin.z()
        val maxX = newCubeMax.x()
        val maxY = newCubeMax.y()
        val maxZ = newCubeMax.z()

        val x = maxX - minX + 1
        val y = maxY - minY + 1
        val z = maxZ - minZ + 1

        if (x == 1 && y == 1 && z == 1) {
            return
        }

        val playerAction = playerData.action

        val df = DecimalFormat("###,###,###")

        var actionBar = ""

        if (pluginRepository.hologramManager != null) {
            ShowDimensions.show(player, playerData)
        } else { // will behave just like always
            when (playerAction) {
                Action.LEFT_CLICK_BLOCK,
                Action.LEFT_CLICK_AIR -> actionBar =
                    "<white>" + df.format(clientPackage.size.toLong()) + " <gray>blocks (" +
                            "<red>" + x + "<gray>x" +
                            "<green>" + y + "<gray>x" +
                            "<blue>" + z + "<gray>)" +
                            " <white>▶<gray> to <red>✘<gray>, <white>◀<gray> to <green>✔"

                Action.RIGHT_CLICK_BLOCK,
                Action.RIGHT_CLICK_AIR -> actionBar =
                    "<white>" + df.format(clientPackage.size.toLong()) + " <gray>blocks (" +
                            "<red>" + x + "<gray>x" +
                            "<green>" + y + "<gray>x" +
                            "<blue>" + z + "<gray>)" +
                            " <white>◀<gray> to <red>✘<gray>, <white>▶<gray> to <green>✔"

                else -> {}
            }
        }

        val mm = MiniMessage.miniMessage()
        val parsed = mm.deserialize(actionBar)
        Mediator.sendActionBar(player, parsed)
    }

    fun attemptDraw(player: Player, playerData: PlayerData) {
        var mode: Mode? = playerData.mode
        if (mode == null) return

        val clicks = playerData.clicks
        if (clicks.isEmpty()) { //maybe shouldn't set anything in the attemptDraw??
            playerData.targetIndex = 0

            val rayTraceResult = player.rayTraceBlocks(1000.0, FluidCollisionMode.NEVER)
            val blockData = serveBlockData(player, rayTraceResult, playerData)

            if (blockData != null) {
                val sound = blockData.soundGroup.placeSound
                playerData.sound = sound
            }
            if (blockData != null) { // update blockData on the go if currently calculated is different from null
                val wrapped = SpigotConversionUtil.fromBukkitBlockData(blockData)
                playerData.blockData = wrapped
            }
        }


        val interactionOrder = mode.getInteractionOrder(player, playerData)
        if(interactionOrder==null) return
        var currentTarget = playerData.floatingTarget
        if (currentTarget == null) {
            currentTarget = interactionOrder.firstOrNull()
            if(currentTarget==null) return
        }
        var newNextTarget = if (currentTarget is DynamicTarget) {
            recursivelySolveTarget(currentTarget, player, playerData)
        } else {
            currentTarget
        }
        val pivot = newNextTarget.predict(player, playerData)
        if (pivot == null) return
        playerData.pivot = pivot

        val languagePack = player.getLanguagePack()

        if (playerData.previewLimit!=-1L && playerData.hasReachedPreviewLimit()) {
            player.sendMessage(languagePack?.quota ?: "Your quota has been exceeded")
            reset(player, playerData)
            val message: Component? = playerData.setMode(null)
            if(message!=null) Mediator.sendActionBar(player, message)

            return
        }
        if (DeliveryOptimization.shouldCancel(player, playerData)) return
        draw(player, playerData)
    }

}