package com.bryanvalc.magicwand.events

import com.bryanvalc.magicwand.context.PacketScheduler.forPlayer
import com.bryanvalc.magicwand.module.storage.PlayerDao
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.config.Configuration
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.Messaging.getParsed
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import com.bryanvalc.magicwand.utils.platform.Mediator
import com.github.shynixn.mccoroutine.bukkit.asyncDispatcher
import com.github.shynixn.mccoroutine.bukkit.launch
import kotlinx.coroutines.delay
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.event.player.PlayerQuitEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

class PlayerJoin : Listener, KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()
    private val plugin: JavaPlugin by inject()
    private val config: Configuration by inject()

    @EventHandler
    fun onPlayerJoin(event: PlayerJoinEvent) {
        val player = event.player
        val uuid = player.uniqueId

        if (config.welcome.enabled && config.welcome.applyWhen == "newToServer" && !player.hasPlayedBefore()) {
            var stack = ItemStack(Material.NETHER_STAR)
            var meta = stack.itemMeta
            meta.setCustomModelData(1)
            stack.itemMeta = meta
            player.inventory.addItem(stack)

            val content = "<gradient:#a64d8c:#7a4da6:#4d62a6:#4d99a6>MagicWand Wiki:</gradient>\n" +
                    "<a:https://magicwand.gitbook.io/magicwand-wiki>https://magicwand.gitbook.io/magicwand-wiki</a>"

            player.sendParsed(content)
        }

        plugin.launch(context = plugin.asyncDispatcher) { //need to do this in a coroutine async, because database querying can be blocking
            val texture = config.texturePack

            if(texture.enabled){
                val languagePack = player.getLanguagePack()

                val textureFile = if (Mediator.getProtocolVersionForPlayer(player) >= 770) {
                    texture.modern
                } else {
                    texture.legacy
                }
                Mediator.setResourcePack(
                    player,
                    textureFile.link,
                    textureFile.hash,
                    texture.force,
                    languagePack?.texture ?: "§cThe server requires a custom texture pack in order to display some menus in the intended way"
                )
            }

            val playerData: PlayerData =
                players.computeIfAbsent(uuid) { _ -> PlayerDao.load(PlayerData(uuid)) }

            scheduleReset(event.getPlayer().name, playerData)
            forPlayer(event.getPlayer())
        }
    }

    fun scheduleReset(playerName: String, playerData: PlayerData) {

        val player = plugin.server.getOfflinePlayer(playerName)
        val uuid = player.uniqueId

        val interval = playerData.limitInterval
        if(interval==-1L) return

        var initialDelay: Long = ((interval * 1000) - abs(System.currentTimeMillis() - playerData.lastReset))

        initialDelay = max(initialDelay, 0) // avoid negative numbers for schedules

        plugin.launch(context = plugin.asyncDispatcher) {
            delay(initialDelay)

            while (player.isOnline) {
                delay(1_000L)
                if(((interval * 1000) - abs(System.currentTimeMillis() - playerData.lastReset))<=0L) continue

                //this counts as a separate entry point
                val playerDataB: PlayerData? = players[uuid]
                if (playerDataB == null) break

//                val playerDataB = playerDataA.clone()

                // got to check both mixin and real time data
                playerDataB.allTimePlaced = playerDataB.allTimePlaced + playerDataB.placedNow
                playerDataB.placedNow = 0 //change real time data
                playerDataB.previewedNow = 0
                playerDataB.lastReset = System.currentTimeMillis()
                val bukkitPlayer: Player? = plugin.server.getPlayer(uuid)
                bukkitPlayer?.sendParsed(bukkitPlayer.getLanguagePack()?.reset ?: "Your quota has been reset")

                players[uuid] =  playerDataB // thread safe commit
//                delay(interval*1000L)

            }
        }


    }


    @EventHandler
    fun onPlayerQuit(event: PlayerQuitEvent) {

        val player = event.player.uniqueId
        val playerDataOriginal: PlayerData? = players[player]

        if (playerDataOriginal == null) return

        PlayerDao.save(playerDataOriginal) //save to db
        players.remove(player) //thread safe remove

    }
}