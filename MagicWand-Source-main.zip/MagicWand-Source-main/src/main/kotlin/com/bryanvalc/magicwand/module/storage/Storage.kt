package com.bryanvalc.magicwand.module.storage

import com.bryanvalc.magicwand.module.config.Configuration
import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.bukkit.plugin.java.JavaPlugin
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SchemaUtils
import org.jetbrains.exposed.sql.transactions.transaction

class Storage(
    private val config: Configuration,
    private val plugin: JavaPlugin
) {

    fun setup(): Database? {
        plugin.logger.info("Setting up Database")

        val storageMethod = config.storage.method

        var database: Database
        var hikariConfig: HikariConfig
        val poolName = plugin.name

        when(storageMethod) {
            "sqlite" -> {
                val sqliteDir = plugin.dataFolder.resolve(config.storage.address)
                if(!sqliteDir.exists()) {
                    sqliteDir.mkdirs()
                }
                val sqlitePath = plugin.dataFolder.resolve(config.storage.address).resolve(config.storage.database).absolutePath

                hikariConfig = HikariConfig().apply {
                    this.poolName = poolName
                    jdbcUrl = "jdbc:sqlite:$sqlitePath"
                    driverClassName = "org.sqlite.JDBC"
                    username = ""
                    password = ""
                    // TODO: check if this is the right behavior for your use case, in most
                    //  cases this works to avoid users screwing this up
                    maximumPoolSize = 1
                    isReadOnly = false
                    transactionIsolation = "TRANSACTION_SERIALIZABLE"
                }
            }
            "mariadb" -> {
                hikariConfig = HikariConfig().apply {
                    this.poolName = poolName
                    jdbcUrl = "jdbc:mariadb://${config.storage.address}/${config.storage.database}?${config.storage.args}"
                    driverClassName = "org.mariadb.jdbc.Driver"
                    username = config.storage.username
                    password = config.storage.password
                    maximumPoolSize = config.storage.maximumPoolSize
                    isReadOnly = false
                    transactionIsolation = "TRANSACTION_SERIALIZABLE"
                }
            }
            "postgresql" -> {
                hikariConfig = HikariConfig().apply {
                    this.poolName = poolName
                    jdbcUrl = "jdbc:postgresql://${config.storage.address}/${config.storage.database}?${config.storage.args}"
                    driverClassName = "org.postgresql.Driver"
                    username = config.storage.username
                    password = config.storage.password
                    maximumPoolSize = config.storage.maximumPoolSize
                    isReadOnly = false
                    transactionIsolation = "TRANSACTION_SERIALIZABLE"
                }
            }
            "h2" -> {
                val h2Dir = plugin.dataFolder.resolve(config.storage.address)
                if(!h2Dir.exists()) {
                    h2Dir.mkdirs()
                }
                val h2Path = plugin.dataFolder.resolve(config.storage.address).resolve(config.storage.database).absolutePath
                hikariConfig = HikariConfig().apply {
                    this.poolName = poolName
                    jdbcUrl = "jdbc:h2:file:$h2Path"
                    driverClassName = "org.h2.Driver"
                    username = config.storage.username
                    password = config.storage.password
                    // TODO: check if this is the right behavior for your use case, in most
                    //  cases this works to avoid users screwing this up
                    maximumPoolSize = 1
                    isReadOnly = false
                    transactionIsolation = "TRANSACTION_SERIALIZABLE"
                }
            }
            else -> {
                return null
            }
        }


        val dataSource = HikariDataSource(hikariConfig)
        database = Database.Companion.connect(datasource = dataSource)

        // Beware PRAGMA will be a bitch for SQLite
        transaction(database) {
            SchemaUtils.create(Players)

            //TODO: migrations are broken.. or maybe need to set new fields to nullable
            // flyway can provide a better way of doing it btw
//            val statements = MigrationUtils.statementsRequiredForDatabaseMigration(Players)
//            if (statements.isNotEmpty()) {
//                // Execute migrations
//                execInBatch(statements)
//            }
        }

        return database

    }

}