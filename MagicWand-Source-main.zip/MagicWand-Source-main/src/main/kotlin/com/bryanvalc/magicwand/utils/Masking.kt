package com.bryanvalc.magicwand.utils

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.entity.Player

object Masking {
    fun offHand(
        originalShape: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        val item = player.inventory.itemInOffHand
        val material = item.type

        if (!(material == Material.WATER_BUCKET || material == Material.LAVA_BUCKET || material.isBlock)) {
            return originalShape.toMutableList()
        }

        val buffer: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList()

        val world = player.world
        for (row in originalShape) {
            val block = world.getBlockAt(row.first.x(), row.first.y(), row.first.z())
            val evalMaterial = block.type
            if (evalMaterial == material) {
                buffer.add(row)
            }
        }

        return buffer
    }
}