package com.bryanvalc.magicwand.data

import com.github.retrooper.packetevents.PacketEvents
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.github.retrooper.packetevents.util.Vector3i
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerMultiBlockChange
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerMultiBlockChange.EncodedBlock
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.entity.Player
import java.util.stream.Collectors


object Packet {

    fun sendBlocks(player: Player, data: Set<Pair<BlockVector3, WrappedBlockState>>) {
//        player.sendMessage(data.size()+""); //debugging

        val closeByPlayers: MutableList<Player> =
            player.world.players.stream().filter{ p: Player -> p.location.distance(player.location) <= 128 }.collect(Collectors.toList())

        val chunks = data.asSequence().groupBy {
                BlockVector3.at(
                    it.first.x() shr 4, it.first.y() shr 4, it.first.z() shr 4
                )
            }

        for (entry in chunks.entries) {

            val encodedBlocks = ReferenceArrayList<EncodedBlock>(entry.value.size)
            for (row in entry.value) {
                encodedBlocks.add(
                    EncodedBlock(
                        row.second,
                        row.first.x(),
                        row.first.y(),
                        row.first.z())
                )
            }

            val multiChange = WrapperPlayServerMultiBlockChange(
                Vector3i(entry.key.x(),entry.key.y(),entry.key.z()),
                true,
                encodedBlocks.toTypedArray())

            PacketEvents.getAPI().playerManager.sendPacket(player, multiChange)

            for (neighbour in closeByPlayers) {
                PacketEvents.getAPI().playerManager.sendPacket(neighbour, multiChange)
            }
        }
    }

}