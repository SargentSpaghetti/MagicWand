package com.bryanvalc.magicwand.module.locales

import kotlinx.serialization.Serializable

@Serializable
data class Brush(
    val name: String,
    val description: String
)

@Serializable
data class MenuItem(
    val title: String,
    val lore: String
)

@Serializable
data class LanguagePack(
    val quota: String,
    val reset: String,
    val permission: String,
    val texture: String,
    val versionLock: String,
    val unsupportedMaterial: String,
    val positionSet: String,
    val positionRemoved: String,
    val positionsCleared: String,
    val brushes: Map<String, Brush>,
    val yes: String,
    val no: String,
    val face: String,
    val center: String,
    val menu: Map<String, MenuItem>,
    val subMenus: Map<String, String>
)