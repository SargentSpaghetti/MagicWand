package com.bryanvalc.magicwand.context.process

import com.bryanvalc.magicwand.context.BlockVectorUtils
import com.bryanvalc.magicwand.context.overlay.GlowBlocks
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.config.Configuration
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import org.bukkit.event.block.Action
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

object Glowing: KoinComponent {

    val plugin: JavaPlugin by inject()
    val configuration: Configuration by inject()

    fun unGlowAll(player: Player,
                  playerData: PlayerData) {
        if (configuration.useGlowing && playerData.glowing) { //glowing
            try {
                for (block in playerData.glowingBlocks.entries) {
                    GlowBlocks.unGlow(block.value, player)
                }
            } catch (exception: Exception) {
                plugin.logger.severe(exception.message)
            }
        }
    }

    fun attemptGlow(player: Player,
                    playerData: PlayerData,
                    newShapeSet: Set<Pair<BlockVector3, WrappedBlockState>>,
                    previousShapeSet: Set<Pair<BlockVector3, WrappedBlockState>>,
                    packetAir: Set<Pair<BlockVector3, WrappedBlockState>>) {

        val action = playerData.action
        if (!(configuration.useGlowing && playerData.glowing && action!=null)) { //glowing
            return
        }

        for (block in packetAir) {
            GlowBlocks.unGlow(block.first, player, playerData)
        }
        val possibleToRestore: MutableSet<BlockVector3> =
            HashSet(previousShapeSet.size)
        for (block in previousShapeSet) {
            possibleToRestore.add(block.first)
        }
        for (block in previousShapeSet) {
            if (BlockVectorUtils.hasAllNeighbors(possibleToRestore, block.first)) {
                GlowBlocks.unGlow(block.first, player, playerData)
            }
        }

        for (block in newShapeSet) {
            val worldWrappedBlockState = WrappedBlockState.getByString(player.world.getBlockAt(block.first.x(), block.first.y(), block.first.z()).blockData.asString)
            if (block.second == worldWrappedBlockState) {
                GlowBlocks.glow(block.first, player, playerData)
            }
        }

        if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
            val possibleNeighbors: MutableSet<BlockVector3> =
                HashSet(newShapeSet.size)
            for (block in newShapeSet) {
                possibleNeighbors.add(block.first)
            }
            for (block in newShapeSet) {
                if (!BlockVectorUtils.hasAllNeighbors(possibleNeighbors, block.first)) {
                    GlowBlocks.glow(block.first, player, playerData)
                }
            }
        } else {
            val world = player.world
            val possibleNeighbors: MutableSet<BlockVector3> =
                HashSet(newShapeSet.size)
            for (block in newShapeSet) {
                possibleNeighbors.add(block.first)
            }
            for (block in newShapeSet) {
                if ((!BlockVectorUtils.hasAllNeighbors(possibleNeighbors, block.first))
                    && BlockVectorUtils.allBlocksAroundAreSolid(block.first, world)
                ) {
                    GlowBlocks.glow(block.first, player, playerData)
                }
            }
        }

    }


}