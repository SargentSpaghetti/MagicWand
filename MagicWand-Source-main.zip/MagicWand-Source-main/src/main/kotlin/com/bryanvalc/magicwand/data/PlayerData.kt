package com.bryanvalc.magicwand.data

import com.bryanvalc.magicwand.data.PlayerPerms.getLongPath
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.format.NamedTextColor
import org.bukkit.Sound
import org.bukkit.event.block.Action
import java.util.UUID

class PlayerData {
    val uuid: UUID
    var mode: Mode?
    var blockData: WrappedBlockState? = null
    var action: Action?
    var clicks: MutableList<ClickData>
    var previousClicksHash: Int?
    var favoriteModes: MutableList<Mode>
    var originalBlocks: MutableSet<BlockVector3>
    var newBlocks: MutableList<Pair<BlockVector3, WrappedBlockState>>
    var glowingBlocks: MutableMap<BlockVector3, Int>
    var targetIndex: Int
    var targetSubIndex: Int
    var floatingTarget: Target?
    var pivot: BlockVector3?
    var reach: Int
    var boundLimit: Int
    var falloffStrength: Double
    var mixingStrength: Double
    var brushSize: Int
    var offset: Double
    var lastInteraction: Long
    var previewLimit: Long
    var previewedNow: Long
    var placingLimit: Long
    var placedNow: Long
    var allTimePlaced: Long = 0
    var limitInterval: Long
    var lastReset = -1L
    var sound: Sound?
    var replaceAir: Boolean
    var replaceSolid: Boolean
    var replaceSoft: Boolean
    var replaceLiquid: Boolean
    var smartPaint: Boolean
    var glowing: Boolean
    var ruler: Boolean
    var tutorial: Boolean
    var snap: Boolean
    var brushMode: Boolean
    var centerOrigin: Boolean
    var chatFeedback: Boolean
    var versionLock: String? = null
    var menus: MutableSet<Menu>

    constructor(player: UUID) {
        this.uuid = player
        this.mode = null
        this.action = null
        this.clicks = ArrayList<ClickData>()
        this.previousClicksHash = 0
        this.favoriteModes = ArrayList<Mode>()
        this.originalBlocks = ReferenceOpenHashSet<BlockVector3>()
        this.newBlocks = ReferenceArrayList<Pair<BlockVector3, WrappedBlockState>>()
        this.glowingBlocks = Object2IntOpenHashMap<BlockVector3>()
        this.targetIndex = 0
        this.targetSubIndex = 0
        this.floatingTarget = null
        this.pivot = null
        this.reach = getLongPath(player, "reach").toInt()
        this.boundLimit = getLongPath(player, "bound").toInt()
        this.falloffStrength = 10.0
        this.mixingStrength = 50.0
        this.brushSize = 5
        this.offset = Double.Companion.NaN
        this.lastInteraction = 0L
        this.previewLimit = getLongPath(player, "previewlimit")
        this.previewedNow = 0
        this.placingLimit = getLongPath(player, "placinglimit")
        this.placedNow = 0
        this.allTimePlaced = 0
        this.limitInterval = getLongPath(player, "interval") // 1 hour
        this.lastReset = -1L
        this.sound = null
        this.replaceAir = true
        this.replaceSolid = true
        this.replaceSoft = true
        this.replaceLiquid = true
        this.smartPaint = false
        this.glowing = false
        this.ruler = false
        this.tutorial = true
        this.snap = true
        this.brushMode = true
        this.centerOrigin = false
        this.chatFeedback = false
        this.versionLock = null
        this.menus = ObjectOpenHashSet<Menu>()
    }

    constructor(
        uuid: UUID,
        mode: Mode?,
        blockData: WrappedBlockState?,
        action: Action?,
        clicks: MutableList<ClickData>,
        previousClicksHash: Int?,
        favoriteModes: MutableList<Mode>,
        originalBlocks: MutableSet<BlockVector3>,
        newBlocks: MutableList<Pair<BlockVector3, WrappedBlockState>>,
        glowingBlocks: MutableMap<BlockVector3, Int>,
        targetIndex: Int,
        targetSubIndex: Int,
        floatingTarget: Target?,
        pivot: BlockVector3?,
        reach: Int,
        boundLimit: Int,
        falloffStrength: Double,
        mixingStrength: Double,
        brushSize: Int,
        offset: Double,
        lastInteraction: Long,
        previewLimit: Long,
        previewedNow: Long,
        placingLimit: Long,
        placedNow: Long,
        allTimePlaced: Long,
        limitInterval: Long,
        lastReset: Long,
        sound: Sound?,
        replaceAir: Boolean,
        replaceSolid: Boolean,
        replaceSoft: Boolean,
        replaceLiquid: Boolean,
        smartPaint: Boolean,
        glowing: Boolean,
        ruler: Boolean,
        tutorial: Boolean,
        snap: Boolean,
        brushMode: Boolean,
        centerOrigin: Boolean,
        chatFeedback: Boolean,
        versionLock: String?,
        menus: MutableSet<Menu>
    ) {
        this.uuid = uuid
        this.mode = mode
        this.blockData = blockData
        this.action = action
        this.clicks = clicks
        this.previousClicksHash = previousClicksHash
        this.favoriteModes = favoriteModes
        this.originalBlocks = originalBlocks
        this.newBlocks = newBlocks
        this.glowingBlocks = glowingBlocks
        this.targetIndex = targetIndex
        this.targetSubIndex = targetSubIndex
        this.floatingTarget = floatingTarget
        this.pivot = pivot
        this.reach = reach
        this.boundLimit = boundLimit
        this.falloffStrength = falloffStrength
        this.mixingStrength = mixingStrength
        this.brushSize = brushSize
        this.offset = offset
        this.lastInteraction = lastInteraction
        this.previewLimit = previewLimit
        this.previewedNow = previewedNow
        this.placingLimit = placingLimit
        this.placedNow = placedNow
        this.allTimePlaced = allTimePlaced
        this.limitInterval = limitInterval
        this.lastReset = lastReset
        this.sound = sound
        this.replaceAir = replaceAir
        this.replaceSolid = replaceSolid
        this.replaceSoft = replaceSoft
        this.replaceLiquid = replaceLiquid
        this.smartPaint = smartPaint
        this.glowing = glowing
        this.ruler = ruler
        this.tutorial = tutorial
        this.snap = snap
        this.brushMode = brushMode
        this.centerOrigin = centerOrigin
        this.chatFeedback = chatFeedback
        this.versionLock = versionLock
        this.menus = menus
    }

    fun clone(): PlayerData {
        return PlayerData(
            this.uuid,
            this.mode,
            this.blockData,
            this.action,
            ArrayList(this.clicks),
            this.previousClicksHash,
            ArrayList(this.favoriteModes),
            HashSet(this.originalBlocks),
            ArrayList(this.newBlocks),
            HashMap(this.glowingBlocks),
            this.targetIndex,
            this.targetSubIndex,
            this.floatingTarget,
            this.pivot,
            this.reach,
            this.boundLimit,
            this.falloffStrength,
            this.mixingStrength,
            this.brushSize,
            this.offset,
            this.lastInteraction,
            this.previewLimit,
            this.previewedNow,
            this.placingLimit,
            this.placedNow,
            this.allTimePlaced,
            this.limitInterval,
            this.lastReset,
            this.sound,
            this.replaceAir,
            this.replaceSolid,
            this.replaceSoft,
            this.replaceLiquid,
            this.smartPaint,
            this.glowing,
            this.ruler,
            this.tutorial,
            this.snap,
            this.brushMode,
            this.centerOrigin,
            this.chatFeedback,
            this.versionLock,
            this.menus
        )
    }

    //maybe this isn't a good idea, but meh
    fun setMode(mode: Mode?): Component? {
        val currentMode = this.mode
        var message: Component? = null

        if (currentMode == null) {
            val successful = PlayerPerms.premiumWall(mode)
            if (successful) {
                this.mode = mode
                if (mode != null) {
                        message = Component.text("Mode " + mode.name + " enabled.").color(NamedTextColor.GREEN)
                }
            } else {
                message = null
            }
        } else if (mode === currentMode) {
            this.mode = null
            message = Component.text("Mode " + currentMode.name + " disabled.").color(NamedTextColor.RED)
        } else {
            val successful = PlayerPerms.premiumWall(mode)
            if (successful) {
                this.mode = mode
                if (mode != null) {
                    if (successful) {
                        message = Component.text("Mode " + mode.name + " enabled.").color(NamedTextColor.GREEN)
                    }
                }
            } else {
                message = null
            }

        }

        this.targetIndex = 0
        return message
    }

    fun setReach(player: UUID, reach: Int) { //supercharged
        var reach = reach
        val limit = getLongPath(player, "reach").toInt() //safety check
        if (limit < reach) {
            reach = limit
        }
        if (reach <= 0) {
            reach = 1
        }
        this.reach = reach
    }

    fun setBoundLimit(player: UUID, boundLimit: Int) {
        var boundLimit = boundLimit
        val limit = getLongPath(player, "bound").toInt() //safety check
        if (limit < boundLimit) {
            boundLimit = limit
        }

        if (boundLimit <= 0) {
            boundLimit = 1
        }

        this.boundLimit = boundLimit
    }

    fun clearTargetSubIndex() {
        this.targetSubIndex = 0
    }

    fun setBrushSize(player: UUID, brushSize: Int) {
        var brushSize = brushSize
        val limit = getLongPath(player, "brushsize").toInt() //safety check
        if (limit < brushSize) {
            brushSize = limit
        }

        if (brushSize <= -1) {
            brushSize = 0
        }

        this.brushSize = brushSize
    }

    fun clearPlacingData() {
        this.clicks.clear()
        this.originalBlocks.clear()
        this.newBlocks.clear()
        this.targetIndex = 0 //maybe not?
        this.floatingTarget = null
        this.offset = Double.Companion.NaN
    }

    fun hasReachedPreviewLimit(): Boolean {
        return previewedNow > previewLimit
    }

    fun hasReachedPlacingLimit(): Boolean {
        return placedNow > placingLimit
    }


}