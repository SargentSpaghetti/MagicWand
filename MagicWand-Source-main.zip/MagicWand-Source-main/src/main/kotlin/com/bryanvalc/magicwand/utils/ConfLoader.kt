package com.bryanvalc.magicwand.utils

import com.typesafe.config.ConfigFactory
import com.typesafe.config.ConfigRenderOptions
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.MissingFieldException
import kotlinx.serialization.hocon.Hocon
import kotlinx.serialization.hocon.decodeFromConfig
import kotlinx.serialization.hocon.encodeToConfig
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.util.UUID

object ConfLoader: KoinComponent {

    val plugin: JavaPlugin by inject()

    @OptIn(ExperimentalSerializationApi::class)
    inline fun <reified T> load(file: File): T? {
        try {
            // Load and resolve user's config
            val userConfig = ConfigFactory.parseFile(file).resolve()

            // Deserialize using kotlinx.serialization-hocon
            return Hocon.decodeFromConfig<T>(userConfig)
        } catch (_: MissingFieldException) {
            return null
        }

    }

    inline fun <reified T> save(file: File, data: T) {
        val config =  Hocon.encodeToConfig(data)

        file.writeText(config.root().render(
            ConfigRenderOptions.defaults()
                .setOriginComments(false)
                .setComments(true)
                .setFormatted(true)
                .setJson(false)
        ))
    }

    inline fun <reified T> load(stream: InputStream, extension: String): T? {

        val tempFile = File.createTempFile("${UUID.randomUUID()}", extension)
        stream.use { input ->
            tempFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }

        return load(tempFile)

    }

    @OptIn(ExperimentalSerializationApi::class)
    inline fun <reified T> loadAndOrUpdate(file: File, resourcePath: String): T? {
        try {
            // Load and resolve user's config
            val userConfig = ConfigFactory.parseFile(file).resolve()

            // Load and resolve default config from resources
            val defaultConfigStream = plugin.getResource(resourcePath) ?: throw IllegalStateException("Default config not found")
            val defaultConfigReader = InputStreamReader(defaultConfigStream)
            val defaultConfig = ConfigFactory.parseReader(defaultConfigReader).resolve()

            // Merge configs: User's config takes precedence over defaults
            val mergedConfig = userConfig.withFallback(defaultConfig)

            // Write merged config back to file (optional: only do this if necessary)

            file.writeText(
                mergedConfig.root().render(
                    ConfigRenderOptions.defaults()
                        .setOriginComments(false)
                        .setComments(true)
                        .setFormatted(true)
                        .setJson(false)
                )
            )

            // Deserialize using kotlinx.serialization-hocon
            return Hocon.decodeFromConfig<T>(mergedConfig)
        } catch (_: MissingFieldException) {
            return null
        }

    }


}