package com.bryanvalc.magicwand.utils

import com.bryanvalc.magicwand.data.PortableSchem
import org.bukkit.NamespacedKey
import org.bukkit.inventory.ItemStack
import org.bukkit.persistence.PersistentDataType
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.io.File
import java.nio.file.Files
import java.util.UUID

/**
 * Stores PortableSchem data for the Copy/Paste tools.
 *
 * We intentionally avoid NMS/NBT reflection (e.g., rTag) because it breaks across
 * Minecraft/Paper updates (1.21.x changed internals again). Instead we:
 *  - store a small ID + facing on the item using PersistentDataContainer
 *  - store the potentially large schematic bytes on disk in the plugin data folder
 */
object PortableSchemStore : KoinComponent {

    private val plugin: JavaPlugin by inject()

    private val folder: File by lazy {
        File(plugin.dataFolder, "portable-schems").also { it.mkdirs() }
    }

    private val schemIdKey: NamespacedKey by lazy { NamespacedKey(plugin, "portable_schem_id") }
    private val facingKey: NamespacedKey by lazy { NamespacedKey(plugin, "portable_schem_facing") }

    fun write(item: ItemStack, schem: PortableSchem) {
        val meta = item.itemMeta ?: return
        val pdc = meta.persistentDataContainer

        // Clean up any previous file referenced by this item
        pdc.get(schemIdKey, PersistentDataType.STRING)?.let { oldId ->
            runCatching { File(folder, "$oldId.bin").delete() }
        }

        val id = UUID.randomUUID().toString()
        runCatching {
            Files.write(File(folder, "$id.bin").toPath(), schem.bin)
        }.onFailure {
            // If disk write fails, don't stamp the item with a broken ID
            plugin.logger.severe("[MagicWand] Failed to write portable schem to disk: ${it.message}")
            return
        }

        pdc.set(schemIdKey, PersistentDataType.STRING, id)
        pdc.set(facingKey, PersistentDataType.STRING, schem.playerFacing)
        item.itemMeta = meta
    }

    fun read(item: ItemStack): PortableSchem? {
        val meta = item.itemMeta ?: return null
        val pdc = meta.persistentDataContainer

        val id = pdc.get(schemIdKey, PersistentDataType.STRING) ?: return null
        val facing = pdc.get(facingKey, PersistentDataType.STRING) ?: return null

        val file = File(folder, "$id.bin")
        if (!file.exists()) return null

        val bytes = runCatching { Files.readAllBytes(file.toPath()) }.getOrNull() ?: return null
        if (bytes.isEmpty()) return null

        return PortableSchem(facing, bytes)
    }

    fun clear(item: ItemStack) {
        val meta = item.itemMeta ?: return
        val pdc = meta.persistentDataContainer
        pdc.get(schemIdKey, PersistentDataType.STRING)?.let { id ->
            runCatching { File(folder, "$id.bin").delete() }
        }
        pdc.remove(schemIdKey)
        pdc.remove(facingKey)
        item.itemMeta = meta
    }
}
