package com.bryanvalc.magicwand.noise.mask.parser

import com.bryanvalc.magicwand.noise.mask.impl.ClassicMask
import com.bryanvalc.magicwand.noise.mask.impl.VastMask
import com.fastasyncworldedit.core.extension.factory.parser.RichParser
import com.sk89q.worldedit.WorldEdit
import com.sk89q.worldedit.command.util.SuggestionHelper
import com.sk89q.worldedit.extension.input.InputParseException
import com.sk89q.worldedit.extension.input.ParserContext
import com.sk89q.worldedit.function.mask.Mask
import java.util.stream.Stream
import javax.annotation.Nonnull
import kotlin.math.max

class VastMaskParser(worldEdit: WorldEdit?) : RichParser<Mask?>(worldEdit, "#vast") {
    override fun getSuggestions(argumentInput: String, index: Int, context: ParserContext?): Stream<String?>? {
        if (index < 3) {
            return SuggestionHelper.suggestPositiveDoubles(argumentInput)
        }
        return Stream.empty<String?>()
    }

    @Throws(InputParseException::class)
    override fun parseFromInput(@Nonnull arguments: Array<String?>, context: ParserContext?): Mask? {
        if (arguments.size != 3) {
            return null
        }
        var scale = arguments[0]!!.toDouble()
        var min = arguments[1]!!.toDouble()
        var max = arguments[2]!!.toDouble()
        scale = 1.0 / max(1.0, scale)
        min = (min - 50.0) / 50.0
        max = (max - 50.0) / 50.0
        return VastMask(scale, min, max)
    }
}