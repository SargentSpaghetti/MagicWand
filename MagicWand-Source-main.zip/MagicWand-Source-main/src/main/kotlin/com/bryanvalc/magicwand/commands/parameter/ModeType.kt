package com.bryanvalc.magicwand.commands.parameter

import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.ModeManager
import revxrsal.commands.autocomplete.SuggestionProvider
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.exception.CommandErrorException
import revxrsal.commands.node.ExecutionContext
import revxrsal.commands.parameter.ParameterType
import revxrsal.commands.stream.MutableStringStream

class ModeType(private val modeManager: ModeManager) : ParameterType<BukkitCommandActor, Mode> {

    override fun parse(input: MutableStringStream, context: ExecutionContext<BukkitCommandActor>): Mode {
        val name = input.readString()
        val mode = modeManager.getFromName((name).replace("_", " "))
            ?: throw CommandErrorException("No such brush: $name")
        return mode
    }

    override fun defaultSuggestions(): SuggestionProvider<BukkitCommandActor> {
        return SuggestionProvider { _ -> modeManager.modes.map { (it.name).replace(" ", "_") } }
    }
}