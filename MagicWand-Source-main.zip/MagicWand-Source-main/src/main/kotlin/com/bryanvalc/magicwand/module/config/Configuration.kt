package com.bryanvalc.magicwand.module.config

import kotlinx.serialization.Serializable

@Serializable
data class Welcome(
    val enabled: Boolean,
    val applyWhen: String
)

@Serializable
data class UpdateNotify(
    val enabled: Boolean,
    val channel: String,
    val permissions: List<String>
)

@Serializable
data class TextureFile(
    val link: String,
    val hash: String
)

@Serializable
data class TexturePack(
    val enabled: Boolean,
    val force: Boolean,
    val legacy: TextureFile,
    val modern: TextureFile
)

@Serializable
data class Defaults(
    val bound: Int,
    val reach: Int,
    val previewLimit: Long,
    val placingLimit: Long,
    val interval: Int,
    val brushSize: Int
)

@Serializable
data class Storage(
    val method: String,
    val address: String,
    val database: String,
    val username: String,
    val password: String,
    val tablePrefix: String,
    val args: String,
    val maximumPoolSize: Int
)

@Serializable
data class License(
    val key: String
)

@Serializable
data class Language(
    val consoleWarnings: Boolean,
    val fallback: String
)

@Serializable
data class Configuration(
    var welcome: Welcome,
    var texturePack: TexturePack,
    var useGlowing: Boolean,
    var maxDistance: Int,
    var maxBound: Int,
    var defaults: Defaults,
    var license: License,
    var storage: Storage,
    var language: Language,
    var updateNotify: UpdateNotify
)