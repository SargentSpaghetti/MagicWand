package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission
import java.util.UUID

class QuotaReset: KoinComponent {

    val plugin: JavaPlugin by inject()
    val players: MutableMap<UUID, PlayerData> by inject()

    @Command("quotareset")
    @CommandPermission("magicwand.quotareset")
    fun reset(actor: BukkitCommandActor, target: Player){
        val uuid = target.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return

        playerDataOriginal.placedNow = 0
        playerDataOriginal.previewedNow = 0

        val message = target.getLanguagePack()?.reset ?: "Your quota has been reset"
        target.sendParsed(message)
    }

}