package com.bryanvalc.magicwand.context.process


import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player
import java.util.stream.Collectors

object AntiTrolling {

    fun isTrolling(player: Player, newShape: List<Pair<BlockVector3, WrappedBlockState>>): Boolean {

        // avoid trolling and getting yourself stuck altogether
        val closeByPlayers =
            player.world.players.asSequence().filter{ p: Player -> p.location.distance(player.location) <= 128 }.toList()

        val playerLocations: MutableList<BlockVector3> = ArrayList()

        for (player1 in closeByPlayers) {
            playerLocations.add(
                BlockVector3.at(
                    player1.location.x,
                    player1.location.y,
                    player1.location.z
                )
            )
            playerLocations.add(
                BlockVector3.at(
                    player1.eyeLocation.x,
                    player1.eyeLocation.y,
                    player1.eyeLocation.z
                )
            )
        }

        val result = newShape.stream().parallel()
            .filter { p: Pair<BlockVector3, WrappedBlockState> -> playerLocations.contains(p.first) }
            .findAny()

        return result.isPresent

    }

}