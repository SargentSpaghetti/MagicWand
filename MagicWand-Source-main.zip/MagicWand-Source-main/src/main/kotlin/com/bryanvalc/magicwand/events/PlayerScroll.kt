package com.bryanvalc.magicwand.events

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.utils.platform.Mediator
import net.kyori.adventure.text.Component
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerItemHeldEvent
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID
import kotlin.math.abs

class PlayerScroll : Listener, KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()

    @EventHandler
    fun scrollInventory(event: PlayerItemHeldEvent) {
        val player = event.player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]

        if (playerDataOriginal == null) return

        val playerData = playerDataOriginal.clone()


        if (!player.isSneaking) { // the opposite way of scrolling
            return
        }

        val previous = event.previousSlot
        val next = event.newSlot

        if (abs((next - previous).toDouble()) > 1) return  //allow for big changes


        val mode = playerData.mode

        if (mode == null) return  //checks

        if (mode !is Scrollable) return

        event.isCancelled = true //lock the item

        if ((next == 0 && previous == 8) || (previous < next)) { //scroll down
            mode.handleScrollDown(player, playerData)
        } else { //scroll up
            mode.handleScrollUp(player, playerData)
        }

        val message: Component? = mode.getScrollTip(player, playerData)
        if(message!=null){
            Mediator.sendActionBar(player, message)
        }

        players[uuid] =playerData
    }
}