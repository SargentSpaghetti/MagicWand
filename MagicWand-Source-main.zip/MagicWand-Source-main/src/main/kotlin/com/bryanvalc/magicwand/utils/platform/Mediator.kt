package com.bryanvalc.magicwand.utils.platform

import com.bryanvalc.magicwand.utils.platform.paper.PaperSpecific
import com.bryanvalc.magicwand.utils.platform.spigot.SpigotSpecific
import net.kyori.adventure.text.Component
import org.bukkit.Sound
import org.bukkit.block.Block
import org.bukkit.entity.Player
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.InventoryHolder
import org.bukkit.inventory.InventoryView
import org.bukkit.inventory.ItemStack
import org.bukkit.inventory.meta.ItemMeta
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

enum class Fork {
    PAPER,
    SPIGOT,
    UNKNOWN
}

object Mediator: KoinComponent, PlatformImplementation {

    val plugin: JavaPlugin by inject()
    var fork = Fork.UNKNOWN
    var implementation: PlatformImplementation = PaperSpecific

    fun isPaper(): Boolean {
        try {
            Class.forName("com.destroystokyo.paper.PaperConfig")
            return true
        } catch (e: ClassNotFoundException) {
            return false
        }
    }

    fun isSpigot(): Boolean {
        try {
            Class.forName("org.spigotmc.SpigotConfig")
            return true
        } catch (e: ClassNotFoundException) {
            return false
        }
    }

    fun defineFork() {
        if (isPaper()) {
            fork = Fork.PAPER
        } else if (isSpigot()) {
            fork = Fork.SPIGOT
            implementation = SpigotSpecific
        }
    }

    override fun getPluginVersion(): String {
        return implementation.getPluginVersion()
    }

    override fun getLanguageForPlayer(player: Player): String {
        return implementation.getLanguageForPlayer(player)
    }

    override fun getProtocolVersionForPlayer(player: Player): Int {
        return implementation.getProtocolVersionForPlayer(player)
    }

    override fun setResourcePack(
        player: Player,
        url: String,
        hash: String,
        required: Boolean,
        prompt: String
    ) {
        implementation.setResourcePack(player, url, hash, required, prompt)
    }

    override fun sendActionBar(player: Player, message: Component) {
        implementation.sendActionBar(player, message)
    }

    override fun sendMessage(player: Player, message: Component) {
        implementation.sendMessage(player, message)
    }

    override fun displayName(itemMeta: ItemMeta, name: String) {
        implementation.displayName(itemMeta, name)
    }

    override fun displayName(itemMeta: ItemMeta, name: Component) {
        implementation.displayName(itemMeta, name)
    }

    override fun createInventory(
        owner: InventoryHolder?,
        size: Int,
        title: String
    ): Inventory {
        return implementation.createInventory(owner, size, title)
    }

    override fun lore(
        itemMeta: ItemMeta,
        lore: List<Component>
    ) {
        implementation.lore(itemMeta, lore)
    }

    override fun getTitle(inventoryView: InventoryView): String {
        return implementation.getTitle(inventoryView)
    }

    override fun getDisplayName(itemStack: ItemStack): String? {
        return implementation.getDisplayName(itemStack)
    }

    override fun getLore(itemStack: ItemStack): List<String>? {
        return implementation.getLore(itemStack)
    }

    override fun playSound(player: Player, sound: Sound) {
        implementation.playSound(player, sound)
    }

    override fun isEmpty(block: Block): Boolean {
        return implementation.isEmpty(block)
    }

    override fun isSolid(block: Block): Boolean {
        return implementation.isSolid(block)
    }

    override fun isLiquid(block: Block): Boolean {
        return implementation.isLiquid(block)
    }

    override fun kick(player: Player) {
        implementation.kick(player)
    }


}