package com.bryanvalc.magicwand.context.process.check

import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.plotsquared.core.location.Location
import com.plotsquared.core.plot.Plot
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.entity.Player

object PlotSquaredCheck: Protect {

    override fun process(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        val uuid = player.uniqueId
        val bukkitWorld = player.world.name

        val buffer: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList()
        for (row in originalMesh) {
            val loc: BlockVector3 = row.first

            val location = Location.at(
                bukkitWorld,
                loc.x(),
                loc.y(),
                loc.z()
            )

            var canBuild = true
            if (location.isPlotArea) {
                val plot = Plot.getPlot(location)
                canBuild = plot?.isAdded(uuid) == true
            } else if (location.isPlotRoad) {
                canBuild = false
            } else {
                return originalMesh.toMutableList() //not a plotworld, so save time on this
            }

            if (canBuild) buffer.add(row)
        }

        return buffer
    }

}