package com.bryanvalc.magicwand.modes

interface AutoSwitch {
    fun switch(): String
}