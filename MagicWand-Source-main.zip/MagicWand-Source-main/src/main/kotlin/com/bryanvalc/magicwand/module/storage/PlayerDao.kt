package com.bryanvalc.magicwand.module.storage

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.ModeManager
import com.bryanvalc.magicwand.module.config.Configuration
import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import com.github.shynixn.mccoroutine.bukkit.asyncDispatcher
import com.github.shynixn.mccoroutine.bukkit.launch
import com.github.shynixn.mccoroutine.bukkit.minecraftDispatcher
import org.bukkit.Material
import org.bukkit.inventory.ItemStack
import org.bukkit.plugin.java.JavaPlugin
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

object PlayerDao: KoinComponent {

    private val database: Database? by inject()
    private val modeManager: ModeManager by inject()
    private val config: Configuration by inject()
    private val plugin: JavaPlugin by inject()

    fun save(playerData: PlayerData){
        if(database==null) return

        transaction(db = database) {
            var playerReg = Players.selectAll().where { Players.uuid eq playerData.uuid }.toList()
            if (playerReg.isEmpty()) {
                Players.insert {
                    it[uuid] = playerData.uuid
                    it[previewedNow] = playerData.previewedNow
                    it[placedNow] = playerData.placedNow
                    it[allTimePlaced] = playerData.allTimePlaced
                    it[reach] = playerData.reach
                    it[boundLimit] = playerData.boundLimit
                    it[falloffStrength] = playerData.falloffStrength
                    it[mixingStrength] = playerData.mixingStrength
                    it[brushSize] = playerData.brushSize
                    it[replaceAir] = playerData.replaceAir
                    it[replaceSolid] = playerData.replaceSolid
                    it[replaceSoft] = playerData.replaceSoft
                    it[replaceLiquid] = playerData.replaceLiquid
                    it[smartPaint] = playerData.smartPaint
                    it[glowing] = playerData.glowing
                    it[ruler] = playerData.ruler
                    it[tutorial] = playerData.tutorial
                    it[snap] = playerData.snap
                    it[brushMode] = playerData.brushMode
                    it[centerOrigin] = playerData.centerOrigin
                    it[chatFeedback] = playerData.chatFeedback
                    val currentMode = playerData.mode
                    it[mode] = currentMode?.name ?: ""

                    val currentModes = playerData.favoriteModes
                    it[favoriteModes] = if (currentModes.isEmpty()) {
                        ""
                    } else {
                        currentModes.joinToString(separator = ",")
                    }

                }
            } else {
                Players.update({ Players.uuid eq playerData.uuid }) {
                    it[previewedNow] = playerData.previewedNow
                    it[placedNow] = playerData.placedNow
                    it[allTimePlaced] = playerData.allTimePlaced
                    it[reach] = playerData.reach
                    it[boundLimit] = playerData.boundLimit
                    it[falloffStrength] = playerData.falloffStrength
                    it[mixingStrength] = playerData.mixingStrength
                    it[brushSize] = playerData.brushSize
                    it[replaceAir] = playerData.replaceAir
                    it[replaceSolid] = playerData.replaceSolid
                    it[replaceSoft] = playerData.replaceSoft
                    it[replaceLiquid] = playerData.replaceLiquid
                    it[smartPaint] = playerData.smartPaint
                    it[glowing] = playerData.glowing
                    it[ruler] = playerData.ruler
                    it[tutorial] = playerData.tutorial
                    it[snap] = playerData.snap
                    it[brushMode] = playerData.brushMode
                    it[centerOrigin] = playerData.centerOrigin
                    it[chatFeedback] = playerData.chatFeedback
                    val currentMode = playerData.mode
                    it[mode] = currentMode?.name ?: ""

                    val currentModes = playerData.favoriteModes
                    it[favoriteModes] = if (currentModes.isEmpty()) {
                        ""
                    } else {
                        currentModes.joinToString(separator = ",")
                    }
                }
            }
        }

    }


    fun load(playerDataOriginal : PlayerData): PlayerData {
        if(database==null) return playerDataOriginal

        val playerData = playerDataOriginal.clone()
        transaction(db = database) {
            val playerList = Players.selectAll().where { Players.uuid eq playerData.uuid }.toList()
            if (playerList.isEmpty()) {

                if (config.welcome.enabled && config.welcome.applyWhen == "newToMagicWand") {
                    plugin.launch(context = plugin.minecraftDispatcher) {
                        val bukkitPlayer = plugin.server.onlinePlayers.firstOrNull { it.uniqueId == playerData.uuid }
                        if (bukkitPlayer == null) return@launch

                        var stack = ItemStack(Material.NETHER_STAR)
                        var meta = stack.itemMeta
                        meta.setCustomModelData(1)
                        stack.itemMeta = meta
                        bukkitPlayer.inventory.addItem(stack)

                        val content = "<gradient:#a64d8c:#7a4da6:#4d62a6:#4d99a6>MagicWand Wiki:</gradient>\n" +
                                "<a:https://magicwand.gitbook.io/magicwand-wiki>https://magicwand.gitbook.io/magicwand-wiki</a>"

                        bukkitPlayer.sendParsed(content)
                    }
                }
                return@transaction
            }

            var playerReg = Players.selectAll().where { Players.uuid eq playerData.uuid }.single()

            playerData.previewedNow = playerReg[Players.previewedNow]
            playerData.placedNow = playerReg[Players.placedNow]
            playerData.allTimePlaced = playerReg[Players.allTimePlaced]
            playerData.reach = playerReg[Players.reach]
            playerData.boundLimit = playerReg[Players.boundLimit]
            playerData.falloffStrength = playerReg[Players.falloffStrength]
            playerData.mixingStrength = playerReg[Players.mixingStrength]
            playerData.brushSize = playerReg[Players.brushSize]
            playerData.replaceAir = playerReg[Players.replaceAir]
            playerData.replaceSolid = playerReg[Players.replaceSolid]
            playerData.replaceSoft = playerReg[Players.replaceSoft]
            playerData.replaceLiquid = playerReg[Players.replaceLiquid]
            playerData.smartPaint = playerReg[Players.smartPaint]
            playerData.glowing = playerReg[Players.glowing]
            playerData.ruler = playerReg[Players.ruler]
            playerData.tutorial = playerReg[Players.tutorial]
            playerData.snap = playerReg[Players.snap]
            playerData.brushMode = playerReg[Players.brushMode]
            playerData.centerOrigin = playerReg[Players.centerOrigin]
            playerData.chatFeedback = playerReg[Players.chatFeedback]

            val currentModeString = playerReg[Players.mode]
            playerData.mode = modeManager.getFromName(currentModeString)

            val currentModesString = playerReg[Players.favoriteModes]
            playerData.favoriteModes = if (currentModesString.isEmpty() || currentModesString == "") {
                arrayListOf<Mode>()
            } else {
                val favoriteModesList = currentModesString.split(",")
                var favoriteModesConverted = mutableListOf<Mode>()
                for (modeStr in favoriteModesList) {
                    val itemMode = modeManager.getFromName(modeStr)
                    if (itemMode != null) {
                        favoriteModesConverted.add(itemMode)
                    }

                }
                favoriteModesConverted
            }

        }

        return playerData

    }
}