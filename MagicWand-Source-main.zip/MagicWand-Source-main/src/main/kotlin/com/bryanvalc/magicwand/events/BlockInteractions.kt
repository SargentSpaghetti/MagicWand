package com.bryanvalc.magicwand.events

import com.bryanvalc.magicwand.data.PlayerData
import org.bukkit.Material
import org.bukkit.event.EventHandler
import org.bukkit.event.EventPriority
import org.bukkit.event.Listener
import org.bukkit.event.block.BlockBreakEvent
import org.bukkit.event.block.BlockPlaceEvent
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID

class BlockInteractions : Listener, KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()

    @EventHandler(priority = EventPriority.LOWEST)
    fun onBlockBreakEvent(evt: BlockBreakEvent) {
        val player = evt.player
        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        val itemStack = evt.player.inventory.itemInMainHand
        if(playerData.brushMode){
            if(itemStack.type!= Material.NETHER_STAR) return
        }

        playerData.lastInteraction = System.currentTimeMillis()
        if(playerData.mode!=null){
            evt.isCancelled = true
        }
        if(itemStack.type== Material.NETHER_STAR) {
            evt.isCancelled = true
        }

        players[uuid] = playerData
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    fun onBlockPlaceEvent(evt: BlockPlaceEvent) {
        val player = evt.player
        val uuid = player.uniqueId

//        val xMat = XMaterial.matchXMaterial(evt.blockReplacedState.type)
//        XMaterial.matchXMaterial()


        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        if(playerData.brushMode){
            val itemStack = evt.player.inventory.itemInMainHand

            if(itemStack.type!= Material.NETHER_STAR) return
        }

        playerData.lastInteraction = System.currentTimeMillis()
        if(playerData.mode!=null){
            evt.isCancelled = true
        }

        players[uuid] = playerData
    }



}