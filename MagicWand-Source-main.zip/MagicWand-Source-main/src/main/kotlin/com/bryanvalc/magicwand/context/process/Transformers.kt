package com.bryanvalc.magicwand.context.process

import com.bryanvalc.magicwand.context.BlockVectorUtils
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.bukkit.BukkitAdapter
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.transform.AffineTransform
import com.sk89q.worldedit.regions.CuboidRegion
import com.sk89q.worldedit.world.block.BlockState
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.block.data.Directional
import org.bukkit.block.structure.StructureRotation
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import kotlin.math.roundToInt

object Transformers: KoinComponent {

    val plugin: JavaPlugin by inject()

    fun fuzzyPaintB(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        val buffer: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(originalMesh.size)

        val domain: MutableList<BlockVector3> = ObjectArrayList(originalMesh.size)
        for (item in originalMesh) {
            domain.add(item.first)
        }

        val mode = playerData.mode
        if(mode==null){
            return  originalMesh.toMutableList()
        }
        val origin= mode.getOrigin(player, playerData)
        if(origin==null){
            return  originalMesh.toMutableList()
        }
        val depth = playerData.boundLimit * 3

        val visited: MutableSet<BlockVector3> = ObjectOpenHashSet(
            BlockVectorUtils.breadthFirstSearch(domain, BlockVectorUtils.defaultDirections, origin, depth)
        )
        visited.add(origin)

        for (item in originalMesh) {
            if (visited.contains(item.first)) {
                buffer.add(item)
            }
        }

        return buffer
    }

    fun fuzzyPaintD(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        val buffer: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(originalMesh.size)

        val domain: MutableList<BlockVector3> = ObjectArrayList(originalMesh.size)
        for (item in originalMesh) {
            domain.add(item.first)
        }

        val mode = playerData.mode
        if(mode==null){
            return originalMesh.toMutableList()
        }
        val origin = mode.getOrigin(player, playerData)
        val depth = playerData.boundLimit * 5
        if(origin==null){
            return originalMesh.toMutableList()
        }

        val visited: MutableSet<BlockVector3> = ObjectOpenHashSet<BlockVector3>(
            BlockVectorUtils.depthFirstSearch(domain, BlockVectorUtils.defaultDirections, origin, depth)
        )
        visited.add(origin)

        for (item in originalMesh) {
            if (visited.contains(item.first)) {
                buffer.add(item)
            }
        }

        return buffer
    }


    fun rotateY(
        shape: List<Pair<BlockVector3, WrappedBlockState>>,
        around: BlockVector3,
        degrees: Double,
        forPlayer: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        if (degrees == 0.0 || shape.isEmpty()) {
            return ReferenceArrayList(shape)
        }

        val replaceAir: Boolean = playerData.replaceAir
        val replaceSolid: Boolean = playerData.replaceSolid
        val replaceSoft: Boolean = playerData.replaceSoft
        val replaceLiquid: Boolean = playerData.replaceLiquid
        val action = playerData.action
        val world = forPlayer.world

        val area: MutableList<BlockVector3> = ReferenceArrayList<BlockVector3>(shape.size)
        for (item in shape) {
            area.add(item.first)
        }

        val newCubeMin: BlockVector3 = BlockVectorUtils.minBlockVector(*area.toTypedArray())
        val newCubeMax: BlockVector3 = BlockVectorUtils.maxBlockVector(*area.toTypedArray())

        val region = CuboidRegion(newCubeMin, newCubeMax)
        val clipboard = BlockArrayClipboard(region)
        clipboard.origin = around

        for (item in shape) {
            val blockData =
                SpigotConversionUtil.toBukkitBlockData(item.second)
            val weBlockState = BukkitAdapter.adapt(blockData)
            clipboard.setBlock<BlockState>(item.first, weBlockState)
        }

        val transform = AffineTransform()
            .rotateY(degrees)

        val buffer: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(shape.size)

        for (item in shape) { //quicker than iterating through the region

            val block: BlockVector3 = item.first
            val blockState = clipboard.getBlock(block)
            val blockData = BukkitAdapter.adapt(blockState)

            val clone = blockData.clone()

            if(action!=null && blockData.material.isAir && action.isRightClick) continue  //skip air bubbles


            if (blockData is Directional) {
                if (degrees >= 315 || degrees < 45) {
                    clone.rotate(StructureRotation.NONE)
                } else if (degrees >= 45 && degrees < 135) {
                    clone.rotate(StructureRotation.COUNTERCLOCKWISE_90)
                } else if (degrees >= 135 && degrees < 225) {
                    clone.rotate(StructureRotation.CLOCKWISE_180)
                } else if (degrees >= 225) {
                    clone.rotate(StructureRotation.CLOCKWISE_90)
                }
            }
            val wrappedBlockState = SpigotConversionUtil.fromBukkitBlockData(clone)

            val relativePos = block.subtract(around)
            val rotatedVec = transform.apply(relativePos.toVector3())
            val transformed = around.add(
                BlockVector3.at(
                    rotatedVec.x().roundToInt().toDouble(),
                    rotatedVec.y().roundToInt().toDouble(),
                    rotatedVec.z().roundToInt().toDouble()
                )
            )

            // so it respects masks? don't know
            Mode.Companion.putBlock(buffer, transformed, wrappedBlockState, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
        }

        return buffer
    }
}