package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.data.PortableSchem
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Refreshable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.utils.ItemConverter
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.bukkit.BukkitAdapter
import com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.transform.AffineTransform
import io.github.retrooper.packetevents.util.SpigotConversionUtil
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.block.BlockFace
import org.bukkit.entity.Player
import java.io.ByteArrayInputStream
import java.io.FileNotFoundException
import java.io.IOException

class Paste : Mode(), Refreshable {
    init {
        name = "paste"
        permission = "mode.paste"
        materialMenu = Material.FILLED_MAP
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/paste"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        val pivot = playerData.pivot
        if(pivot!=null){
            clickLocations.add(pivot)
        }

        val clickLocation = clickLocations.lastOrNull()
        if(clickLocation==null) return null

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList<Pair<BlockVector3, WrappedBlockState>>()

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        val item = player.inventory.itemInMainHand
        if (item.type == Material.AIR) {
            return shape
        }

        val portableSchem = ItemConverter.read<PortableSchem>(item)
        if (portableSchem == null) return shape

        val previousPlayerFacing = portableSchem.playerFacing
        val schemBin = portableSchem.bin

        if (schemBin.isEmpty()) {
            return shape
        }

        val format: ClipboardFormat = BuiltInClipboardFormat.SPONGE_V3_SCHEMATIC

        try {
            format.getReader(ByteArrayInputStream(schemBin)).use { reader ->
                val clipboard = reader.read()

                val region = clipboard.region
                val origin = clipboard.origin

                // Calculate rotation
                val originalFacing = BlockFace.valueOf(previousPlayerFacing)
                val currentFacing = player.facing

                val rotationAngle =
                    ((getDegreesFromBlockFace(originalFacing) + 360) - getDegreesFromBlockFace(currentFacing)) % 360

                val transform = AffineTransform()
                    .rotateY(rotationAngle.toDouble())


                val virtualClipboard = clipboard.transform(transform)

                for (block in virtualClipboard.region) {
                    val blockState = virtualClipboard.getBlock(block)
                    val blockData = BukkitAdapter.adapt(blockState)
                    if (blockData.material.isAir) continue

                    val wrappedBlockState = SpigotConversionUtil.fromBukkitBlockData(blockData)

                    // Calculate relative position and apply rotation
                    val relativePos = block.subtract(origin)
                    val transformed = clickLocation.add(relativePos)

                    putBlock(
                        shape,
                        transformed,
                        wrappedBlockState,
                        world,
                        replaceAir,
                        replaceSolid,
                        replaceSoft,
                        replaceLiquid
                    )
                }
            }
        } catch (e: FileNotFoundException) {
            throw RuntimeException(e)
        } catch (e: IOException) {
            throw RuntimeException(e)
        }

        return shape
    }


    private fun getDegreesFromBlockFace(face: BlockFace): Int {
        return when (face) {
            BlockFace.NORTH ->  0
            BlockFace.EAST ->  90
            BlockFace.SOUTH ->  180
            BlockFace.WEST ->  270
            else ->  0
        }
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList<Target>(listOf(Block()))
    }

}