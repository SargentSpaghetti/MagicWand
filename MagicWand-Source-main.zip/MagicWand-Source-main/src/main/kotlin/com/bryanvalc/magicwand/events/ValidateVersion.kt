package com.bryanvalc.magicwand.events

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.MaterialRegistry
import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.Messaging.getParsed
import org.bukkit.Sound
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerItemHeldEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID


class ValidateVersion : Listener, KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()
    private val materialRegistry: MaterialRegistry by inject()
    private val plugin: JavaPlugin by inject()

    @EventHandler
    fun onSlotChange(event: PlayerItemHeldEvent) {
        val player: Player = event.getPlayer()
        val newItem: ItemStack? = player.inventory.getItem(event.newSlot)
        if(newItem==null) return

        val uuid = player.uniqueId
        val playerDataOriginal: PlayerData? = players[uuid]
        if (playerDataOriginal == null) return
        val playerData = playerDataOriginal.clone()

        val versionLock = playerData.versionLock
        if(versionLock==null) return

        val material = newItem.type
        val key = material.key.toString()

        val validMaterials = materialRegistry.registries[versionLock]

        if(validMaterials==null) return

        if(validMaterials.materialList.contains(key)) return

        val message = player.getLanguagePack()?.unsupportedMaterial ?: "§cThe material \$material isn't supported by your version lock \$version"
        player.sendActionBar(player.getParsed(message.replace("\$version", versionLock).replace("\$material", key)))

        var warn: Sound = Sound.BLOCK_ANVIL_LAND
        player.playSound(player.eyeLocation, warn, 1f, 1f)


    }

}