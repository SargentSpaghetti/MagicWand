package com.bryanvalc.magicwand.utils.platform

import net.kyori.adventure.text.Component
import org.bukkit.Sound
import org.bukkit.block.Block
import org.bukkit.entity.Player
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.InventoryHolder
import org.bukkit.inventory.InventoryView
import org.bukkit.inventory.ItemStack
import org.bukkit.inventory.meta.ItemMeta

interface PlatformImplementation {

    fun getPluginVersion(): String
    fun getLanguageForPlayer(player: Player): String
    fun getProtocolVersionForPlayer(player: Player): Int
    fun setResourcePack(player: Player, url: String, hash: String, required: Boolean, prompt: String)
    fun sendActionBar(player: Player, message: Component)
    fun sendMessage(player: Player, message: Component)
    fun displayName(itemMeta: ItemMeta, name: String)
    fun displayName(itemMeta: ItemMeta, name: Component)
    fun createInventory(owner: InventoryHolder?, size: Int, title: String): Inventory
    fun lore(itemMeta: ItemMeta, lore: List<Component>)
    fun getTitle(inventoryView: InventoryView): String
    fun getDisplayName(itemStack: ItemStack): String?
    fun getLore(itemStack: ItemStack): List<String>?
    fun playSound(player: Player, sound: Sound)
    fun isEmpty(block: Block): Boolean
    fun isSolid(block: Block): Boolean
    fun isLiquid(block: Block): Boolean
    fun kick(player: Player)

}