package com.bryanvalc.magicwand.module

import com.bryanvalc.magicwand.module.config.Configuration
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.locales.LangManager
import com.bryanvalc.magicwand.modes.ModeManager
import com.bryanvalc.magicwand.modes.implementations.*
import com.bryanvalc.magicwand.module.storage.Storage
import com.bryanvalc.magicwand.utils.ConfLoader
import org.bukkit.plugin.java.JavaPlugin
import org.jetbrains.exposed.sql.Database
import org.koin.dsl.module
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.logging.Logger

val configurationModule = module {
    single<Configuration> {
        val plugin = get<JavaPlugin>()
        val configFile = File(plugin.dataFolder, "config.conf")
        ConfLoader.loadAndOrUpdate<Configuration>(configFile, "config.conf")!!
    }
}

val consoleModule = module {
    single<Logger> {
        val plugin = get<JavaPlugin>()
        plugin.logger
    }
}

val pluginRepositoryModule = module {
    single<PluginRepository> {
        val plugin = get<JavaPlugin>()
        val pluginRepository = PluginRepository(plugin)
        pluginRepository.setup()
        pluginRepository
    }
}

val storageModule = module {
    single<Storage> {
        val configuration = get<Configuration>()
        val plugin = get<JavaPlugin>()
        Storage(configuration, plugin)
    }

    single<Database?> {
        get<Storage>().setup()
    }

}

val licenseModule = module {
    single<License> {
        val configuration = get<Configuration>()
        License(configuration)
    }
}


val loaderModule = module {
    single<Loader> {
        val plugin = get<JavaPlugin>()
        Loader(plugin)
    }
}


val langManagerModule = module {
    single<LangManager> {
        val plugin = get<JavaPlugin>()
        val localesFolder = File(plugin.dataFolder, "locales/")
        val config = get<Configuration>()
        LangManager(localesFolder, config, plugin)
    }
}

val materialRegistryModule = module {
    single<MaterialRegistry> {
        val plugin = get<JavaPlugin>()
        val materialRegistry = MaterialRegistry(plugin)
        materialRegistry.load()
        materialRegistry
    }
}

val playersModule = module {
    single<MutableMap<UUID, PlayerData>> {
        ConcurrentHashMap<UUID, PlayerData>()
    }
}

val ktPluginModule = module {
    single<KtPlugin> {
        KtPlugin(
            24573,
            "<dark_gray>(<u><gradient:#3792d4:#8968d3:#8d4ca9><a:https://magicwand.voxeldart.com/download>MagicWand</a></gradient></u><dark_gray>) <gray>",
            "https://raw.githubusercontent.com/BryanValc/MagicWand-Releases/refs/heads/main/version.txt",
            "For all features, <u><gradient:#3792d4:#8968d3:#8d4ca9><a:https://www.patreon.com/c/BryanValc>get lifetime access here, updates free</a></gradient></u>, continued support is appreciated if you believe in this."
        )
    }
}

val modesModule = module {
    single<ModeManager> {
        val modeManager = ModeManager()
        modeManager.registerModes(
            Circle(), FreeCircle(), Cyl(), Sphere(),            Single(), Line(), Plane(), Cube(),
            PerfectSphere(), Bucketfill(), Metaball(), Mesh(),  Line3D(), Slope(), ExtendedSlope(), Triangle(),
            Curve(), Vine(), Coat(), Voronoi(),                 Command(), Copy(), Paste(), Stack()
        )
        //TriangleCast()
        //, Cliff()
        modeManager
    }
}

val appModules = listOf(
    configurationModule,
    consoleModule,
    pluginRepositoryModule,
    storageModule,
    licenseModule,
    loaderModule,
    langManagerModule,
    materialRegistryModule,
    playersModule,
    ktPluginModule,
    modesModule
)
