package com.bryanvalc.magicwand.commands

import com.bryanvalc.magicwand.utils.Messaging.sendParsed
import org.bukkit.entity.Player
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import revxrsal.commands.annotation.Command
import revxrsal.commands.bukkit.actor.BukkitCommandActor
import revxrsal.commands.bukkit.annotation.CommandPermission

class Wiki: KoinComponent {

    val plugin: JavaPlugin by inject()

    @Command("wiki")
    @CommandPermission("magicwand.wiki")
    fun wiki(actor: BukkitCommandActor) {
        val sender = actor.sender()
        if (sender is Player) {
            val player = sender as Player
            val content = "<gradient:#a64d8c:#7a4da6:#4d62a6:#4d99a6>MagicWand Wiki:</gradient>\n" +
                    "<a:https://magicwand.gitbook.io/magicwand-wiki>https://magicwand.gitbook.io/magicwand-wiki</a>"

            player.sendParsed(content)
        }

    }

}