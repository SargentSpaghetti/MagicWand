package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.bresenham3D
import com.bryanvalc.magicwand.context.BlockVectorUtils.stacker
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.gui.menu.Menu
import com.bryanvalc.magicwand.gui.properties.EnumProperty
import com.bryanvalc.magicwand.gui.properties.Property
import com.bryanvalc.magicwand.modes.Configurable
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.ExtendAny
import com.bryanvalc.magicwand.targets.implementations.HitWall
import com.bryanvalc.magicwand.targets.implementations.HitY
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import it.unimi.dsi.fastutil.objects.ReferenceArrayList
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*

class Slope : Mode(), Configurable {
    init {
        name = "slope"
        permission = "mode.slope"
        materialMenu = Material.PRISMARINE_SHARD
        premium = false
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/structures/slope"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        val clicks: MutableList<ClickData> = playerData.clicks

        if (clicks.isEmpty()) return null

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        if (clickLocations.size == 1 || clickLocations.size == 2) {
            val pivot = playerData.pivot
            if(pivot!=null){
                clickLocations.add(pivot)
            }
        }

        if (clickLocations.isEmpty()) {
            return null
        }

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        if (clickLocations.size == 1) {
            val location = clickLocations[0]
            putBlock(shape, location, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
        } else if (clickLocations.size == 2) {
            val firstBlock = clickLocations[0]
            val lastBlock = clickLocations[1]

            val prediction: MutableList<BlockVector3> = bresenham3D(firstBlock, lastBlock)
            for (block in prediction) {
                putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
            }
        } else if (clickLocations.size == 3) {
            val firstBlock = clickLocations[0]
            val secondBlock = clickLocations[1]
            val thirdBlock = clickLocations[2]

            val firstLine: MutableList<BlockVector3> = bresenham3D(firstBlock, secondBlock)

            val menu = forPlayer(playerData)
            val filling = (menu?.propertyByName("filling") as EnumProperty?)?.value?:"full"


            var secondPrediction: MutableList<BlockVector3> =
                ReferenceArrayList(16 + ((playerData.newBlocks.size * 1.25).toInt()))

            when(filling) {
                "skeleton" -> {
                    val offsetToSecond = secondBlock.subtract(firstBlock)
                    val virtualFourthPosition = thirdBlock.subtract(offsetToSecond)
                    val secondLine = bresenham3D(secondBlock, thirdBlock)
                    val thirdLine = bresenham3D(thirdBlock, virtualFourthPosition)
                    val fourthLine = bresenham3D(firstBlock, virtualFourthPosition)
                    secondPrediction.addAll(firstLine)
                    secondPrediction.addAll(secondLine)
                    secondPrediction.addAll(thirdLine)
                    secondPrediction.addAll(fourthLine)
                }
                else -> {
                    secondPrediction = stacker(firstLine, secondBlock, thirdBlock)
                }
            }


            for (block in secondPrediction) {
                putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
            }
        }

        return shape
    }

    override fun defaultMenu(): Menu {
        return Menu(
            "options.$name",
            setOf<Property>(
                EnumProperty(
                    row = 1, column = 1, name = "facing",
                    material = Material.QUARTZ,
                    lore = "facing.lore",
                    model = null,
                    value = "floor", options = listOf("any", "floor", "wall"),
                    models = mapOf(
                        "any" to 1,
                        "floor" to 2,
                        "wall" to 3
                    )
                ),
                EnumProperty(
                    row = 1, column = 3, name = "filling",
                    material = Material.BUCKET,
                    lore = "filling.lore",
                    model = null,
                    value = "full", options = listOf("full", "skeleton"),
                    models = mapOf(
                        "full" to 1,
                        "skeleton" to 4
                    )
                )
            ),
            3
        )
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        val menu = forPlayer(playerData)
        val lock = (menu?.propertyByName("facing") as EnumProperty?)?.value?:"floor"

        val order = when(lock) {
            "floor" -> ArrayList(listOf(Block(), HitY(), ExtendAny()))
            "wall" -> ArrayList(listOf(Block(), HitWall(), ExtendAny()))
            else -> ArrayList(listOf(Block(), Block(), ExtendAny()))
        }

        return order
    }

}