package com.bryanvalc.magicwand.module

import com.bryanvalc.magicwand.utils.ConfLoader
import org.bukkit.plugin.java.JavaPlugin
import java.io.File

class MaterialRegistry(
    private val plugin: JavaPlugin
) {
    var registries = mutableMapOf<String, MaterialList>()

    fun load() {
        registries.clear()
        val directory = File(plugin.dataFolder, "material_registry/")

        for(file in directory.listFiles()){
            val materialList = ConfLoader.load<MaterialList>(file)
            if(materialList==null) continue

            registries[file.name.replace(".conf", "")] = materialList
            plugin.logger.info("Loaded ${file.name} material registry containing ${materialList.materialList.size} materials.")
        }

    }

}