package com.bryanvalc.magicwand.targets

import com.bryanvalc.magicwand.data.PlayerData
import com.sk89q.worldedit.math.BlockVector3
import org.bukkit.entity.Player

abstract class Target {
    abstract fun isResolved(player: Player, playerData: PlayerData): Boolean

    abstract fun predict(player: Player, playerData: PlayerData): BlockVector3?

    abstract fun hologramTip(player: Player, playerData: PlayerData): MutableMap<Int, MutableSet<BlockVector3>>?
}