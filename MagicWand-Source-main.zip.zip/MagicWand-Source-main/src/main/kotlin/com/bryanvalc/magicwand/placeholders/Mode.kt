package com.bryanvalc.magicwand.placeholders

import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.module.storage.PlayerDao
import me.clip.placeholderapi.expansion.PlaceholderExpansion
import org.bukkit.OfflinePlayer
import org.bukkit.entity.Player
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.UUID
import kotlin.text.equals

class Mode : PlaceholderExpansion(), KoinComponent {

    private val players: MutableMap<UUID, PlayerData> by inject()

    override fun getAuthor(): String {
        return "BryanValc" //
    }

    override fun getIdentifier(): String {
        return "mode"
    }

    override fun getVersion(): String {
        return "1.0.0"
    }

    override fun onRequest(player: OfflinePlayer, params: String): String? {
        val uuid = player.uniqueId
        var playerData: PlayerData? = players[uuid]
        if (playerData == null) { playerData = PlayerData(uuid) }
        val player1 = player.player
        if (player1 == null) { playerData = PlayerDao.load(playerData) }

        if (params.equals("current", ignoreCase = true)) {
            val mode = playerData.mode
            return mode?.name ?: "default"
        }

        if (params.equals("favorites", ignoreCase = true)) {
            val modes = playerData.favoriteModes
            return if (modes.isEmpty()) {
                "default"
            } else {
                modes.joinToString(separator = "\n")
            }
        }
        return null
    }

    override fun onPlaceholderRequest(player: Player, params: String): String? {
        val uuid = player.uniqueId
        var playerData: PlayerData? = players[uuid]
        if (playerData == null) { playerData = PlayerData(uuid) }
        val player1 = player.player
        if (player1 == null) { playerData = PlayerDao.load(playerData) }

        if (params.equals("current", ignoreCase = true)) {
            val mode = playerData.mode
            return mode?.name ?: "default"
        }

        if (params.equals("favorites", ignoreCase = true)) {
            val modes = playerData.favoriteModes
            return if (modes.isEmpty()) {
                "default"
            } else {
                modes.joinToString(separator = "\n")
            }
        }
        return null
    }
}