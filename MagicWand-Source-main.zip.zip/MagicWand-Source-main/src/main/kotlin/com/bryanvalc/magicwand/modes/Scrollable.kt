package com.bryanvalc.magicwand.modes

import com.bryanvalc.magicwand.data.PlayerData
import net.kyori.adventure.text.Component
import org.bukkit.entity.Player

interface Scrollable {
    fun handleScrollUp(player: Player, playerData: PlayerData)

    fun handleScrollDown(player: Player, playerData: PlayerData)

    fun getScrollTip(player: Player, playerData: PlayerData): Component?
}