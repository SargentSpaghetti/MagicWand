package com.bryanvalc.magicwand.modes.implementations

import com.bryanvalc.magicwand.context.BlockVectorUtils.equalsByTolerance
import com.bryanvalc.magicwand.context.BlockVectorUtils.removeTailingClick
import com.bryanvalc.magicwand.context.BlockVectorUtils.isInsideSphere
import com.bryanvalc.magicwand.context.BlockVectorUtils.getCleanSphereVector
import com.bryanvalc.magicwand.context.fakeToBlockPoint
import com.bryanvalc.magicwand.data.ClickData
import com.bryanvalc.magicwand.data.PlayerData
import com.bryanvalc.magicwand.modes.Mode
import com.bryanvalc.magicwand.modes.Multicolor
import com.bryanvalc.magicwand.modes.Scrollable
import com.bryanvalc.magicwand.targets.Target
import com.bryanvalc.magicwand.targets.implementations.Block
import com.bryanvalc.magicwand.targets.implementations.ContinuousDistance
import com.bryanvalc.magicwand.utils.Coloring
import com.github.retrooper.packetevents.protocol.world.states.WrappedBlockState
import com.sk89q.worldedit.math.BlockVector3
import com.sk89q.worldedit.math.Vector3
import com.sk89q.worldedit.math.interpolation.KochanekBartelsInterpolation
import com.sk89q.worldedit.math.interpolation.Node
import it.unimi.dsi.fastutil.objects.ObjectArrayList
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Location
import org.bukkit.Material
import org.bukkit.entity.Player
import java.util.*

class Curve : Mode(), Scrollable, Multicolor {
    init {
        name = "curve"
        permission = "mode.curve"
        materialMenu = Material.STRING
        wiki = "https://magicwand.gitbook.io/magicwand-wiki/for-builders/brushes/organics/curve"
    }

    override fun draw(
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>>? {

        var clicks: MutableList<ClickData> = playerData.clicks

        val clickLocations: MutableList<BlockVector3> = ArrayList<BlockVector3>()
        for (click in clicks) {
            clickLocations.add(click.location)
        }
        val pivot = playerData.pivot
        if(pivot!=null){
            clickLocations.add(pivot)
        }
        if (clickLocations.isEmpty()) {
            return null
        }

        val shape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ArrayList<Pair<BlockVector3, WrappedBlockState>>(16 + ((playerData.newBlocks.size * 1.25).toInt()))
        val blockData = playerData.blockData
        if(blockData == null) return null

        val replaceAir = playerData.replaceAir
        val replaceSolid = playerData.replaceSolid
        val replaceSoft = playerData.replaceSoft
        val replaceLiquid = playerData.replaceLiquid
        val world = player.world

        val lastSize = playerData.brushSize
        if (clickLocations.size == 1) {
            val location = clickLocations[0]

            val locMin = Location(
                world,
                location.x() - lastSize - 0.5,
                location.y() - lastSize - 0.5,
                location.z() - lastSize - 0.5
            )
            val locMax = Location(
                world,
                location.x() + lastSize + 0.5,
                location.y() + lastSize + 0.5,
                location.z() + lastSize + 0.5
            )

            for (x in locMin.blockX..locMax.blockX) {
                for (y in locMin.blockY..locMax.blockY) {
                    for (z in locMin.blockZ..locMax.blockZ) {
                        val evaluated = BlockVector3.at(x, y, z)

                        if (isInsideSphere(locMin, locMax, evaluated)) {
                            putBlock(
                                shape,
                                evaluated,
                                blockData,
                                world,
                                replaceAir,
                                replaceSolid,
                                replaceSoft,
                                replaceLiquid
                            )
                        }
                    }
                }
            }
        } else if (clickLocations.size >= 2) {
            clicks = removeTailingClick(clicks, 2)

            var maxSize = 0

            var curvesResolution = 1.0 //cannot be zero, gotta make sure it isn't zero so below it doesn't infinite loop

            var previousLoc: BlockVector3? = null
            for (clickData in clicks) {
                if (previousLoc == null) {
                    previousLoc = clickData.location
                    curvesResolution += previousLoc.distance(pivot)
                } else {
                    curvesResolution += clickData.location.distance(previousLoc)
                }

                if (clickData.brushSize > maxSize) {
                    maxSize = clickData.brushSize
                }
            }
            if (lastSize > maxSize) {
                maxSize = lastSize
            }

            curvesResolution = 0.33 / curvesResolution //0.33 to give some more allowance


            val bigSphere: MutableList<Vector3>? = getCleanSphereVector(world, maxSize)
            if (bigSphere==null) return null

            for (relativeLocation in bigSphere) {
                val nodeGroup: MutableList<Node> = ArrayList<Node>()

                for (click in clicks) {
                    val block = clamp(
                        click.brushSize,
                        maxSize,
                        relativeLocation,
                        Vector3.at(
                            click.location.x().toDouble(),
                            click.location.y().toDouble(),
                            click.location.z().toDouble()
                        )
                    )
                    val vector = Vector3.at(block.x() + 0.5, block.y() + 0.5, block.z() + 0.5)
                    val newNode = Node(vector)
                    newNode.tension = -1.0
                    nodeGroup.add(newNode)
                }

                val lastClick = pivot
                if(lastClick==null) return null

                val clicksLast = clicks.lastOrNull()
                if(clicksLast==null) return null

                if (!equalsByTolerance(lastClick, clicksLast.location, 3.0)) {
                    val lastBlock = clamp(
                        lastSize,
                        maxSize,
                        relativeLocation,
                        Vector3.at(
                            lastClick.x().toDouble(),
                            lastClick.y().toDouble(),
                            lastClick.z().toDouble()
                        )
                    )
                    val vector = Vector3.at(lastBlock.x() + 0.5, lastBlock.y() + 0.5, lastBlock.z() + 0.5)
                    val newNode = Node(vector)
                    newNode.tension = -1.0
                    nodeGroup.add(newNode)
                }

                val interpolation = KochanekBartelsInterpolation()
                interpolation.setNodes(nodeGroup)

                val finalPrediction: MutableList<BlockVector3> = ArrayList<BlockVector3>()

                var i = 0.0
                while (i <= 1) {
                    //it has to be dynamic, there is a huge amount of curves to process for big spheres
                    val floatingPoint = interpolation.getPosition(i)
                    finalPrediction.add(floatingPoint.fakeToBlockPoint())
                    i += curvesResolution
                }

                for (block in finalPrediction) {
                    putBlock(shape, block, blockData, world, replaceAir, replaceSolid, replaceSoft, replaceLiquid)
                }
            }
        }

        val reduced: MutableSet<Pair<BlockVector3, WrappedBlockState>> =
            ObjectOpenHashSet<Pair<BlockVector3, WrappedBlockState>>(shape)
        val finalShape: MutableList<Pair<BlockVector3, WrappedBlockState>> =
            ObjectArrayList<Pair<BlockVector3, WrappedBlockState>>(reduced)

        return finalShape
    }


    //gridSize works kind of like the percentage, brushSize is the current node size
    fun clamp(brushSize: Int, gridSize: Int, relativeLocation: Vector3, center: Vector3): Vector3 {
        if (gridSize == 0) {
            return center
        }

        return relativeLocation.divide(gridSize.toDouble()).multiply(brushSize.toDouble()).add(center)
    }

    override fun handleScrollUp(player: Player, playerData: PlayerData) {
        val uuid = player.uniqueId
        val currentSize = playerData.brushSize + 1
        playerData.setBrushSize(uuid, currentSize)
    }

    override fun handleScrollDown(player: Player, playerData: PlayerData) {
        val uuid = player.uniqueId
        val currentSize = playerData.brushSize - 1
        playerData.setBrushSize(uuid, currentSize)
    }

    override fun getScrollTip(player: Player, playerData: PlayerData): Component? {
        val text =
            "<gray> size: <white>" + playerData.brushSize + "<gray>, <white>scroll ▲<gray> to increase size, <white>scroll ▼<gray> to decrease"
        return MiniMessage.miniMessage().deserialize(text)
    }

    override fun genGradient(
        originalMesh: List<Pair<BlockVector3, WrappedBlockState>>,
        player: Player,
        playerData: PlayerData
    ): MutableList<Pair<BlockVector3, WrappedBlockState>> {
        return Coloring.falloffGradient(originalMesh, player, playerData)
    }

    override fun getInteractionOrder(
        player: Player,
        playerData: PlayerData
    ): MutableList<Target>? {
        return ArrayList<Target>(listOf<Target>(Block(), ContinuousDistance()))
    }
}