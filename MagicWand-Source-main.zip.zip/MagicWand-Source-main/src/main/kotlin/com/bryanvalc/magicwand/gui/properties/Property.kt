package com.bryanvalc.magicwand.gui.properties

import org.bukkit.Material
import org.bukkit.Sound
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.inventory.ItemStack


abstract class Property(
    val row: Int,
    val column: Int,
    var name: String,
    var material: Material,
    var lore: String,
    var model: Int?,
    val leftClickSound: Sound? = Sound.UI_BUTTON_CLICK,
    val rightClickSound: Sound? = Sound.UI_BUTTON_CLICK
) {

    abstract fun handleLeftClick(event: InventoryClickEvent)
    abstract fun handleRightClick(event: InventoryClickEvent)
    abstract fun printableValue(): String
    abstract fun updateMaterial(): Material?
    abstract fun updateModel(): Int?
    abstract fun getItem(player: Player): ItemStack

    fun position() = (row*9)+column
    override fun hashCode() = (row*9)+column

    override fun equals(other: Any?): Boolean {
        val otherProperty = other as Property
        return otherProperty.hashCode() == this.hashCode()
    }
}