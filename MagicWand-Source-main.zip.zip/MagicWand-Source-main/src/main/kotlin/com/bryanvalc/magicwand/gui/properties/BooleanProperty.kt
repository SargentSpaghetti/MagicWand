package com.bryanvalc.magicwand.gui.properties

import com.bryanvalc.magicwand.utils.Messaging.getLanguagePack
import com.bryanvalc.magicwand.utils.TextFormatter
import com.bryanvalc.magicwand.utils.platform.Mediator
import net.kyori.adventure.text.minimessage.MiniMessage
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.inventory.ItemStack

class BooleanProperty(row: Int, column: Int, name: String, material: Material, lore: String, model: Int?,
                      var value: Boolean = true,
                      var overrideDisplays: Map<Boolean, String>? = null,
                      var materials: Map<Boolean, Material>? = null,
                      var models: Map<Boolean, Int>? = null
):
    Property(row, column, name, material, lore, model)
    {
    fun toggle() {
        value = !value
    }

    override fun handleLeftClick(event: InventoryClickEvent) {
        toggle()
    }

    override fun handleRightClick(event: InventoryClickEvent) {
        toggle()
    }

    override fun printableValue(): String {
        val locked = overrideDisplays
        if(locked.isNullOrEmpty()) {
            return if(value == true) {
                "yes"
            } else {
                "no"
            }
        } else {
            return locked[value==true]?:"no"
        }

    }

    override fun updateMaterial(): Material? {
        val locked = materials

        if(locked.isNullOrEmpty()) return material

        val newMaterial = locked[value == true]
        if(newMaterial!=null) {
            material = newMaterial
        }
        return material
    }

    override fun updateModel(): Int? {
        val locked = models

        if(locked.isNullOrEmpty()) return model

        val newModel = locked[value == true]
        if(newModel!=null) {
            model = newModel
        }

        return model
    }

    override fun getItem(player: Player): ItemStack {
        updateModel()
        updateMaterial()

        var itemStack = ItemStack(material)
        var meta = itemStack.itemMeta

        var nameStr = "No translation found for $name"
        var loreStr = "No translation found for $lore"
        var printableStr = "No translation found for ${printableValue()}"
        val languagePack = player.getLanguagePack()
        languagePack?.let {
            nameStr = it.subMenus[name] ?: nameStr
            loreStr = it.subMenus[lore] ?: loreStr
            printableStr = it.subMenus[printableValue()] ?: printableStr
        }

        val displayName = "<#4d65b4>$nameStr: <#f57d4a>$printableStr"
        Mediator.displayName(meta, displayName)
        val baseLore = TextFormatter.createComponents(loreStr, 30, "<#6b3e75>")
        Mediator.lore(meta, baseLore)
        meta.setCustomModelData(model)

        itemStack.setItemMeta(meta)

        return itemStack
    }


}

